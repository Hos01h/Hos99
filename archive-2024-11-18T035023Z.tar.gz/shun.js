
process.on('uncaughtException', console.error)

require('./lib/shun-list')
require('./setting')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageContent, generateWAMessage, downloadContentFromMessage, areJidsSameUser, getContentType } = global.baileys
const { getId } = require('nekopoi-scraper')
const samp = require("samp-query")
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys")
const { translate } = require("@vitalets/google-translate-api");

const Tiktok = require("@tobyg74/tiktok-api-dl")
const path = require('path');
const maker = require('mumaker');
const nekobocc = require('nekobocc');
const { createCanvas, loadImage } = require('canvas');
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const { lyrics, lyricsv2, mediafiredl } = require ('@bochilteam/scraper')
const http = require('http')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const { join } = require('path');

const speed = require('performance-now')
const axios = require('axios')
const fsx = require('fs-extra')
const FormData = require('form-data')
const ytdl = require("@distube/ytdl-core")

const cheerio = require('cheerio');
const ms = require("ms");

const crypto = require('crypto')
const fg = require('api-dylux')
const https = require('https')
const yts = require("yt-search")
const Kaa = require("hxz-api")
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const moment = require('moment-timezone')
//==================================================//
const Func = require('./lib/functions')
const uploadFile = require("./lib/uploadFile")

const { UploadFileUgu, webp2mp4File, TelegraPh } = require('./lib/uploader')
const { stickQC } = require('./lib/qc-stick')
const { sswebDesktop, sswebTablet, sswebPhone } = require('./lib/ssweb')
const { getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, formatp, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const { jadibot, stopjadibot, listjadibot } = require('./lib/jadibot')
const { addExif } = require('./lib/exif')
const NeoxrApi = require('@neoxr/api')
const Api = new NeoxrApi('https://api.neoxr.my.id/api', 'KaaKangSatir')
const pickRandom = (arr) => {

return arr[Math.floor(Math.random() * arr.length)]

}



// global.Fn = function functionCallBack(fn, ...args) { return fn.call(global.conn, ...args) }
//==================================================//


global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({ ...query, ...(apikeyqueryname ? { [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name] } : {}) })) : '')

// global.Fn = function functionCallBack(fn, ...args) { return fn.call(global.conn, ...args) }
// Fungsi untuk menghasilkan URL API

global.db.data = JSON.parse(fs.readFileSync('./ShunAi/database/database.json'))

if (global.db.data) global.db.data = {

users: {},

chats: {},

game: {},

database: {},

settings: {},

stickercmd: {},

...(global.db.data || {})

}
//==================================================//
let tebaklagu = db.data.game.tebaklagu = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakbendera = db.data.game.tebakbendera = []
let tebakkata = db.data.game.tebakkata = []
let ttebakan = db.data.game.ttebakan = []
let tebakkimia = db.data.game.tebakkimia = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let asahotak = db.data.game.asahotak = []
let siapaaku = db.data.game.siapaaku = []
let susunkata = db.data.game.susunkata = []
let _family100 = db.data.game.family100 = []
//==================================================//
const warnstick = {}
const warnlink = {}
const warnfoto = {}
const warnvid = {}
const warnnsfw = {}
const SessionsAi = {}
const trxpending = {}
//==================================================//
module.exports = KaaKangSatir = async (KaaKangSatir, m, chatUpdate, store) => {
 try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.msg.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''

var budy = (typeof m.text == 'string' ? m.text : '')
const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
//=================================================//

const ctext = (text, style = 1) => {
  var abc = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var xyz = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  abc.map((v, i) =>
    replacer.push({
      original: v,
      convert: xyz[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

const pushname = m.pushName || "No Name"

    
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

function formatIDR(number) {
    return number.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' });
}
//=================================================//
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''//Kalau mau Single prefix Lu ganti pake ini = const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const botNumber = global.bottz.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const groupMetadata = m.isGroup ? await KaaKangSatir.groupMetadata(from).catch(e => {}) : ''
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const content = JSON.stringify(m.message)
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')  
if(time2 < "23:59:00"){
var stime = ctext(`Good Night`)
 }
 if(time2 < "19:00:00"){
var stime = ctext(`Good Evening`)
 }
 if(time2 < "18:00:00"){
var stime = ctext(`Good Evening`)
 }
 if(time2 < "15:00:00"){
var stime = ctext(`Good Afternoon`)
 }
 if(time2 < "11:00:00"){
var stime = ctext(`Good Morning`)
 }
 if(time2 < "05:00:00"){
var stime = ctext(`Good Morning`)
 }
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const tanggal2 = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const qtod = m.quoted? "true":"false"
//=================================================//
// FUNCTION
const ProfileUsers = await KaaKangSatir.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png');

const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [sender]}

const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}

const Shun = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Shun,;;;\nFN: Shun Ai\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': ProfileUsers,
                    thumbnail: ProfileUsers,
                    sendEphemeral: true
                }   
            }
        }

const floc = {
			key: {
				participant : '0@s.whatsapp.net',
				...(m.chat ? { 
					remoteJid: `status@broadcast`
				} : {})
			},
			message: {
				locationMessage: {
					name: `Shun Ai ${versions}`,
					thumbnailUrl: ProfileUsers
								 }
					 }
			}

async function reply(teks) {
            if (typereply === 'v1') {
                KaaKangSatir.sendMessage(from, { text : teks }, { quoted : m })
            } else if (typereply === 'v2') {
                KaaKangSatir.sendMessage(from, { text: teks, mentions: await ments(teks)}, {quoted:fcall})
            } else if (typereply === 'v3') {
                KaaKangSatir.sendMessage(from, { 
        text: teks, 
        contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: saluran,
                newsletterJid: idsal,
                serverMessageId: -1
            },
            forwardingScore: 256,
            externalAdReply: {
                showAdAttribution: true,
                title: `${botname} ${versions}`,
                body: hariini, // Menambahkan waktu saat ini di zona Asia/Jakarta ke dalam pesan
                thumbnailUrl: 'https://telegra.ph/file/80b0870f072b8be902d76.jpg',
                sourceUrl: "",
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }}, 
        { quoted: Shun });
            }
        }

async function msToTime(duration) {
    const milliseconds = parseInt((duration % 1000) / 100)
    const seconds = Math.floor((duration / 1000) % 60)
    const minutes = Math.floor((duration / (1000 * 60)) % 60)
    const hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    return `${hours}h ${minutes}m ${seconds}s ${milliseconds}ms`
}

async function formatBytes(sizeInBytes) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    let size = sizeInBytes, unitIndex = 0
    while (size >= 1024 && unitIndex < units.length - 1) size /= 1024, unitIndex++
    return size.toFixed(2) + " " + units[unitIndex]
}

async function random_mail() {
    const link = "https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1"

    try {
        let response = await fetch(link)
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
        }
        let data = await response.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

async function get_mails(id, domain) {
    const link = `https://www.1secmail.com/api/v1/?action=getMessages&login=${id}&domain=${domain}`

    try {
        let response = await fetch(link)
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
        }
        let data = await response.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

async function Telesticker(url) {
    return new Promise(async (resolve, reject) => {
        if (!url.match(/(https:\/\/t.me\/addstickers\/)/gi)) return reply('Enther your url telegram sticker link')
        packName = url.replace("https://t.me/addstickers/", "")
        data = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getStickerSet?name=${encodeURIComponent(packName)}`, {method: "GET",headers: {"User-Agent": "GoogleBot"}})
        const telestik = []
        for (let i = 0; i < data.data.result.stickers.length; i++) {
            fileId = data.data.result.stickers[i].thumb.file_id
            data2 = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getFile?file_id=${fileId}`)
            result = {
            status: 200,
            author: 'DGHuTao',
            url: "https://api.telegram.org/file/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/" + data2.data.result.file_path
            }
            telestik.push(result)
        }
    resolve(telestik)
    })
}


KaaKangSatir.autoshalat = KaaKangSatir.autoshalat ? KaaKangSatir.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? KaaKangSatir.user.id : m.sender
	let id = m.chat 
    if(id in KaaKangSatir.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Jakarta dan sekitarnya._`
    KaaKangSatir.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete KaaKangSatir.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }

const totalFitur = () =>{
            var mytext = fs.readFileSync("./shun.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
      

async function dellCase(filePath, caseNameToRemove) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan:', err);
            return;
        }

        const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
        const modifiedData = data.replace(regex, '');

        fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err);
                return;
            }

            console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
        });
    });
}

const randomReduction = Math.floor(Math.random() * 5) + 1;

const mimeTypes = [
    "application/vnd.ms-excel", // XLS
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // XLSX
    "application/pdf",           // PDF
    "application/msword",        // DOC
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // DOCX
    "application/vnd.ms-powerpoint" // PPT
];

// Menambahkan tipe MIME yang dihasilkan secara acak
mimeTypes.push(mimeTypes[Math.floor(Math.random() * mimeTypes.length)]);
const randomMimeType = mimeTypes.pop();

const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await KaaKangSatir.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: fcall })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await KaaKangSatir.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}

async function igdl2(url) {
            let res = await axios("https://indown.io/");
            let _$ = cheerio.load(res.data);
            let referer = _$("input[name=referer]").val();
            let locale = _$("input[name=locale]").val();
            let _token = _$("input[name=_token]").val();
            let { data } = await axios.post(
              "https://indown.io/download",
              new URLSearchParams({
                link: url,
                referer,
                locale,
                _token,
              }),
              {
                headers: {
                  cookie: res.headers["set-cookie"].join("; "),
                },
              }
            );
            let $ = cheerio.load(data);
            let result = [];
            let __$ = cheerio.load($("#result").html());
            __$("video").each(function () {
              let $$ = $(this);
              result.push({
                type: "video",
                thumbnail: $$.attr("poster"),
                url: $$.find("source").attr("src"),
              });
            });
            __$("img").each(function () {
              let $$ = $(this);
              result.push({
                type: "image",
                url: $$.attr("src"),
              });
            });
          
            return result;
          }
          
//==================================================//

if (('family100' + m.chat in _family100) && isCmd) {
    kuis = true
    let room = _family100['family100' + m.chat]
    let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
    let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
    if (!isSurender) {
        let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
        if (room.terjawab[index]) return !0
        room.terjawab[index] = m.sender
    }
    let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
    let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
    return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
}).filter(v => v).join('\n')}
${isSurender ? '' : `Perfect Player`}`.trim()
    KaaKangSatir.sendText(m.chat, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100' + m.chat].pesan = mes }).catch(_ => _)
    
    if (isWin || isSurender) {
        clearTimeout(room.timeout) // clear the timeout if the game ends early
        delete _family100['family100' + m.chat]
    }
}
        
//==================================================//
        
if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebaklagu[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
   //KaaKangSatir.sendMessage(m.chat, { image: { url: ProfileUsers }, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
   const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
   let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak lagu"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
   KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete tebaklagu[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebakgambar[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
  const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
   let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak gambar"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})

 //KaaKangSatir.sendMessage(m.chat, { image: { url: ProfileUsers }, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete tebakgambar[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebakbendera.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakbendera[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebakbendera[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
  const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
   let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Bendera 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak bendera"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})

 //KaaKangSatir.sendMessage(m.chat, { image: { url: ProfileUsers }, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete tebakbendera[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebakkata[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak kata"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)

 delete tebakkata[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (ttebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = ttebakan[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete ttebakan[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak tebakan"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)

 delete ttebakan[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebakkimia.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkimia[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebakkimia[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
// KaaKangSatir.sendMessage(m.chat, { image: { url: ProfileUsers }, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kata`}, {quoted:m})  

    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Kimia 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak kimia"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete tebakkimia[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebaklirk[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak lirik"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 
 delete tebaklirik[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

//==================================================//

if (siapaaku.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = siapaaku[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete siapaaku[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Siapakah Aku 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}siapakahaku"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 
 delete siapaaku[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

//==================================================//

if (susunkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = susunkata[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete susunkata[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Susun Kata 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}susunkata"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete susunkata[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

//==================================================//

if (asahotak.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = asahotak[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete asahotak[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Asah Otak 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}asahotak"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete asahotak[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

//==================================================//

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete caklontong[m.sender.split('@')[0]]
    delete caklontong_desk[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Cak Lontong 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}caklontong"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (new RegExp('^((me)?nyerah|surr?ender)$', 'i').test(budy)) {
    await reply('Permainan dihentikan.');
    delete tebakkalimat[m.sender.split('@')[0]]
  } else if (budy.toLowerCase() == jawaban) {
    const randomReward = Math.floor(Math.random() * 300) + 50;

// Memformat saldo
    let formattedSaldo = formatIDR(randomReward);
    global.db.data.users[m.sender].saldo += randomReward;
    let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\nKamu Mendapatkan Saldo ${formattedSaldo}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak kalimat"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  
 KaaKangSatir.sendReact(m.chat, '✔️', m.key)
 delete tebakkalimat[m.sender.split('@')[0]]
} else KaaKangSatir.sendReact(m.chat, '❌', m.key), reply('*Jawaban Salah!*')
}


if (!KaaKangSatir.public) {
if (!m.key.fromMe) return
}
function getRandomColor() {
  return Math.floor(Math.random() * 256); // Menghasilkan warna acak dari 0-255
}
const randomColor1 = getRandomColor(); // Warna acak untuk botname
const randomColor2 = getRandomColor(); // Warna acak untuk pushname
const randomColor3 = getRandomColor(); // Warna acak untuk groupName | Private Chat
const randomBgColor1 = getRandomColor(); // Warna acak untuk latar belakang ShunAi
const randomBgColor2 = getRandomColor(); // Warna acak untuk latar belakang Time
const randomBgColor3 = getRandomColor(); // Warna acak untuk latar belakang Cmd
const randomBgColor4 = getRandomColor(); // Warna acak untuk latar belakang From
const randomBgColor5 = getRandomColor(); // Warna acak untuk latar belakang In

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
KaaKangSatir.sendPresenceUpdate('available', m.chat)
console.log(
  `\x1b[48;5;${randomBgColor1}m|\x1b[1;37m${botname}\x1b[0m|\n` +  // Latar belakang acak untuk ShunAi dengan teks putih tebal di dalam tanda | |
  `\x1b[48;5;${randomBgColor2}m\x1b[1;37m|Time| ${time}\x1b[0m\n` +  // Latar belakang acak untuk |Time| dengan teks putih tebal
  `\x1b[48;5;${randomBgColor3}m\x1b[1;36m|Cmd| \x1b[38;5;${randomColor1}m${budy || m.mtype}\x1b[0m\n` +  // Latar belakang acak untuk |Cmd| dengan warna cyan untuk teks, warna acak untuk budy || m.mtype
  `\x1b[48;5;${randomBgColor4}m\x1b[38;5;${randomColor2}m|From| ${pushname}\x1b[0m\n` +  // Latar belakang acak untuk |From| dengan warna acak untuk teks pushname
  `\x1b[48;5;${randomBgColor5}m${groupName ? `\x1b[38;5;${randomColor3}m|In| ${groupName}` : `\x1b[38;5;${randomColor3}m|In| Private Chat`}\x1b[0m`  // Latar belakang acak untuk |In| dengan warna acak untuk teks groupName atau Private Chat
);
}
         
//=================================================//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.stickercmd)) {
let hash = global.db.data.stickercmd[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: KaaKangSatir.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, KaaKangSatir.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
KaaKangSatir.ev.emit('messages.upsert', msg)
}
//=================================================//
if (budy.startsWith('!')) {
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(mess.error)
}
}
//==================================================//
try {
    let isNumber = x => typeof x === 'number' && !isNaN(x);
    let defaultLimit = 999999999999999999999999999999999999999999999999999999999999;
    let premiumLimit = 9999999999999999;
    let saldoUser = 0;
    let orderAmount = 0;
    let orderPrice = 0;
    let user = global.db.data.users[m.sender];
    
    if (typeof user !== 'object') global.db.data.users[m.sender] = {};

    if (user !== undefined) {
        if (!isNumber(user.afkTime)) user.afkTime = -1;
        if (!('afkReason' in user)) user.afkReason = '';
        if (!isNumber(user.limit)) user.limit = user.premium ? premiumLimit : defaultLimit;
        if (!isNumber(user.saldo)) user.saldo = saldoUser;
        if (!isNumber(user.orderamount)) user.orderamount = orderAmount;
        if (!isNumber(user.orderprice)) user.orderprice = orderPrice;
        if (!('orderid' in user)) user.orderid = undefined;
        if (!('pasangan' in user)) user.pasangan = ''
        if (!('banned' in user)) user.banned = false;
        if (!('owner' in user)) user.owner = false;
        if (!('premium' in user)) user.premium = false;
        if (!isNumber(user.premiumExpiry)) user.premiumExpiry = 0;

        // Check if premium has expired
        if (user.premium && user.premiumExpiry <= Date.now()) {
            user.premium = false;
            user.limit = defaultLimit;
        }
    } else {
        global.db.data.users[m.sender] = {
            afkTime: -1,
            afkReason: '',
            limit: defaultLimit,
            saldo: saldoUser,
            orderamount: orderAmount,
            orderprice: orderPrice,
            orderid: undefined,
            banned: false,
            owner: false,
            premium: false,
            premiumExpiry: 0
        };
    }
    
    let chats = global.db.data.chats[m.chat];
    if (typeof chats !== 'object') global.db.data.chats[m.chat] = {};
    if (chats) {    
        
  
        if (!('autoresspvn' in chats)) chats.autoresspvn = false;
        if (!('mute' in chats)) chats.mute = false;
        if (!('antilink' in chats)) chats.antilink = false;
        if (!('antistick' in chats)) chats.antistick = false;
        if (!('antifoto' in chats)) chats.antifoto = false;
        if (!('antivid' in chats)) chats.antivid = false;
        if (!('antispam' in chats)) chats.antispam = false;
        if (!('spamTracker' in chats)) chats.spamTracker = {};
        if (!('antinsfw' in chats)) chats.antinsfw = false;
    } else {
        global.db.data.chats[m.chat] = {
              
            autoresspvn: false,
            mute: false,
            antilink: false,
            antistick: false,
            antifoto: false,
            antivid: false,
            antispam: false,
            spamTracker: {},
            antinsfw: false
        };
    }
} catch (err) {
    console.log(err);
}

     
     let autoResetLimit = true;

if (autoResetLimit) {

var cron = require("node-cron")

cron.schedule("10 00 * * *", () => {

var ussr = Object.keys(db.data.users)

for (let jid of ussr) db.data.users[jid].limit = 99999999999999

console.log("Reseted Limit")

}, {

sceduled: true,

timezone: "Asia/Jakarta"

})

}
let isBan = global.db.data.users[m.sender].banned

let isNumber = x => typeof x === 'number' && !isNaN(x)
let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (autobio) {
        let _uptime = process.uptime() * 1000
		let uptime = clockString(_uptime)
		await KaaKangSatir.updateProfileStatus(`I am ${botname} | Aktif Selama ${uptime} ⏳ | Mode : ${KaaKangSatir.public ? 'Public-Mode' : 'Self-Mode'}`).catch(_ => _)
        }


if (autoread) {
KaaKangSatir.readMessages([m.key])
        }
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: false
            }

function pickMoji(list) {
     return list[Math.floor(Math.random() * list.length)]
  }

async function falseR () {
KaaKangSatir.sendReact(m.chat, '❌', m.key)
}

async function loading () {
var KaaKangSatir = [
`${pickMoji(['🙄','🤯','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`,
`${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','♻️','〽️','⚠️'])}`,
`${pickMoji(['😨','😅','😂','😳','💭','🗯','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`,
`${pickMoji(['😳','💭','🗯','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`,
`${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','💣','😔','👀','👎','🥶','💯','💤','💨','🔥','👍','❓️','⏳️','💥','🤙'])}`,
]
let { key } = await KaaKangSatir.sendReact(m.chat, `${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','👍','❓️','⏳️','💥','🤙'])}`, m.key)//Pengalih isu

for (let i = 0; i < KaaKangSatir.length; i++) {
await sleep(65)
await KaaKangSatir.sendReact(m.chat, KaaKangSatir[i], m.key)
//PESAN LEPAS
}
}

let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
for (let jid of mentionUser) {
    let user = db.data.users[jid];
    if (!user) continue;
    let afkTime = user.afkTime;
    if (!afkTime || afkTime < 0) continue;
    let reason = user.afkReason || '';
    if (!isShunBottz(m.sender)) { // Jika yang ngetag bukan ShunBottz
        reply(`🚫 *Jangan tag dia!*
        ❏  *Dia sedang AFK* ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
        ❏  *Selama* ${clockString(new Date - afkTime)}
        `.trim());
        return; // Hentikan proses lebih lanjut karena yang ngetag bukan ShunBottz
    }
}

if (db.data.users[m.sender].afkTime > -1) {
    let user = db.data.users[m.sender];
    reply(`
    👻 ${pushname} Telah Kembali Dari Afk\n\n ❏ ${user.afkReason ? ' *Dengan Alasan* : ' + user.afkReason : ''}\n\n ❏  *Selama* : ${clockString(new Date - user.afkTime)}
    `.trim());
    user.afkTime = -1;
    user.afkReason = '';
}

// Auto Resspon VN
if (db.data.chats[m.chat].autoresspvn) {
    if (m.message?.audioMessage) {
        const ressp = ['Apasih', 'Iyee', 'Yaudah', 'Yaudahsih', 'Iyakah?', 'Ngapain?', 'Kapan?', 'Dimana?', 'Siapa?', 'Sama Siapa?', 'Kamu?', 'Siapa ya'];
        const vnress = ressp[Math.floor(Math.random() * ressp.length)];
        await KaaKangSatir.sendText(m.chat, vnress, m);
    }
}

function isShunBottz(jid) {
    // Cek apakah jid adalah ShunBottz
    return jid === `${global.bottz}@s.whatsapp.net`;
}

if (db.data.chats[m.chat].antilink) {
    if (budy.match(`chat.whatsapp.com`)) {
        const user = m.sender;

        let gclink = (`https://chat.whatsapp.com/` + await KaaKangSatir.groupInviteCode(m.chat));
        let isLinkThisGc = new RegExp(gclink, 'i');
        let isgclink = isLinkThisGc.test(m.text);

        if (isgclink) return;
        if (isAdmins) return;
        if (isCreator) return;

        // Inisialisasi peringatan pengguna jika belum ada
        if (!warnlink[user]) {
            warnlink[user] = 0;
        }
        
        // Hapus pesan link grup
        await KaaKangSatir.sendMessage(m.chat, {delete: {remoteJid: m.chat,fromMe: false,id: mek.key.id,participant: mek.key.participant}})
        
        // Tingkatkan jumlah peringatan
        warnlink[user]++;

        // Beri peringatan kepada pengguna
        await reply(`${gris}</> ANTI LINK WHATSAPP </>${gris}\n\nKamu Terdeteksi Mengirim Link Group, Maaf Link Akan Saya Hapus ! (Peringatan ${warnlink[user]}/3)`);
        if (!isBotAdmins) return await reply(`Ehh Bot Gak Admin T_T`);

        // Jika peringatan lebih dari 3, keluarkan pengguna dari grup
        if (warnlink[user] >= 3) {
            await KaaKangSatir.groupParticipantsUpdate(m.chat, [user], 'remove');
            delete warnlink[user]; // Reset peringatan setelah mengeluarkan pengguna
        }
    }
}

if (db.data.chats[m.chat].antistick) {
    if (/webp/.test(mime)) {
        const user = m.sender;
        
        if (isAdmins) return;
        if (isCreator) return;

        // Inisialisasi peringatan pengguna jika belum ada
        if (!warnstick[user]) {
            warnstick[user] = 0;
        }
        
        // Hapus pesan stiker
        await KaaKangSatir.sendMessage(m.chat, {delete: {remoteJid: m.chat,fromMe: false,id: mek.key.id,participant: mek.key.participant}})

        // Tingkatkan jumlah peringatan
        warnstick[user]++;

        // Beri peringatan kepada pengguna
        await reply(`${gris}</> ANTI STICKER </>${gris}\n\nKamu Terdeteksi Mengirim Sticker, Maaf Sticker Akan Saya Hapus ! (Peringatan ${warnstick[user]}/3)`);
        if (!isBotAdmins) return await reply(`Ehh Bot Gak Admin T_T`);
        
        // Jika peringatan lebih dari 3, keluarkan pengguna dari grup
        if (warnstick[user] >= 3) {
            await KaaKangSatir.groupParticipantsUpdate(m.chat, [user], 'remove');
            delete warnstick[user]; // Reset peringatan setelah mengeluarkan pengguna
        }
    }
}

if (db.data.chats[m.chat].antifoto) {
    if (/image/.test(mime)) {
        const user = m.sender;
        
        if (isAdmins) return;
        if (isCreator) return;

        // Inisialisasi peringatan pengguna jika belum ada
        if (!warnfoto[user]) {
            warnfoto[user] = 0;
        }
        
        // Hapus pesan foto
        await KaaKangSatir.sendMessage(m.chat, {delete: {remoteJid: m.chat,fromMe: false,id: mek.key.id,participant: mek.key.participant}})

        // Tingkatkan jumlah peringatan
        warnfoto[user]++;

        // Beri peringatan kepada pengguna
        await reply(`${gris}</> ANTI FOTO </>${gris}\n\nKamu Terdeteksi Mengirim Foto, Maaf Foto Akan Saya Hapus ! (Peringatan ${warnfoto[user]}/3)`);     
        if (!isBotAdmins) return await reply(`Ehh Bot Gak Admin T_T`);
        
        // Jika peringatan lebih dari 3, keluarkan pengguna dari grup
        if (warnfoto[user] >= 3) {
            await KaaKangSatir.groupParticipantsUpdate(m.chat, [user], 'remove');
            delete warnfoto[user]; // Reset peringatan setelah mengeluarkan pengguna
        }
    }
}

if (db.data.chats[m.chat].antivid) {
    if (/video/.test(mime)) {
        const user = m.sender;
        
        if (isAdmins) return;
        if (isCreator) return;

        // Inisialisasi peringatan pengguna jika belum ada
        if (!warnvid[user]) {
            warnvid[user] = 0;
        }
        
        // Hapus pesan video
        await KaaKangSatir.sendMessage(m.chat, {delete: {remoteJid: m.chat,fromMe: false,id: mek.key.id,participant: mek.key.participant}})

        // Tingkatkan jumlah peringatan
        warnvid[user]++;

        // Beri peringatan kepada pengguna
        await reply(`${gris}</> ANTI VIDEO </>${gris}\n\nKamu Terdeteksi Mengirim Video, Maaf Video Akan Saya Hapus ! (Peringatan ${warnvid[user]}/3)`);
        if (!isBotAdmins) return await reply(`Ehh Bot Gak Admin T_T`);
        
        // Jika peringatan lebih dari 3, keluarkan pengguna dari grup
        if (warnvid[user] >= 3) {
            await KaaKangSatir.groupParticipantsUpdate(m.chat, [user], 'remove');
            delete warnvid[user]; // Reset peringatan setelah mengeluarkan pengguna
        }
    }
}

if (global.db.data.chats[m.chat].antispam) {
    if (!global.db.data.chats[m.chat].spamTracker) {
        global.db.data.chats[m.chat].spamTracker = {};
    }

    if (!global.db.data.chats[m.chat].spamTracker[m.sender]) {
        global.db.data.chats[m.chat].spamTracker[m.sender] = {
            messages: [],
            warnings: 0
        };
    }

    const chatSpamTracker = global.db.data.chats[m.chat].spamTracker[m.sender];
    chatSpamTracker.messages.push(Date.now());
    chatSpamTracker.messages = chatSpamTracker.messages.filter(time => Date.now() - time <= 5000);

    if (chatSpamTracker.messages.length > 5) {
        chatSpamTracker.warnings++;
        await reply(`${gris}</> ANTI SPAM </>${gris}\n\nKamu Terdeteksi Mengirim Pesan Terlalu Banyak dalam Waktu Singkat! (Peringatan ${chatSpamTracker.warnings}/3)`);

        if (chatSpamTracker.warnings >= 3) {
            await KaaKangSatir.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            delete global.db.data.chats[m.chat].spamTracker[m.sender];
        }
    }
}

if (db.data.chats[m.chat].antinsfw) {
    if (/image/.test(mime)) {
        const user = m.sender;
        
        if (isAdmins) return;
        if (isCreator) return;

        // Inisialisasi peringatan pengguna jika belum ada
        if (!warnnsfw[user]) {
            warnnsfw[user] = 0;
        }
        
        try {
            let media = await KaaKangSatir.downloadAndSaveMediaMessage(m);
            let anu = await TelegraPh(media);
            let cekk = await fetchJson(`https://itzpire.com/tools/nsfwcheck?url=${anu}`);

            // Cek hasil dari API
            if (cekk.status === "success" && cekk.code === 200) {
                let nsfwLabel = cekk.data.find(d => d.label === "nsfw");
                if (nsfwLabel && nsfwLabel.score > 0.5) {
                    // Hapus pesan gambar
                    await KaaKangSatir.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });

                    // Tingkatkan jumlah peringatan
                    warnnsfw[user]++;

                    // Beri peringatan kepada pengguna
                    await reply(`${gris}</> ANTI NSFW </>${gris}\n\nKamu Terdeteksi Mengirim NSFW, Maaf Akan Saya Hapus ! (Peringatan ${warnnsfw[user]}/3)`);
                    if (!isBotAdmins) return await reply(`Ehh Bot Gak Admin T_T`);

                    // Jika peringatan lebih dari 3, keluarkan pengguna dari grup
                    if (warnnsfw[user] >= 3) {
                        await KaaKangSatir.groupParticipantsUpdate(m.chat, [user], 'remove');
                        delete warnnsfw[user]; // Reset peringatan setelah mengeluarkan pengguna
                    }
                }
            }
        } catch (err) {
            console.error(err);
            await reply(`Terjadi kesalahan saat memeriksa konten NSFW. Coba lagi nanti.`);
        }
    }
}

if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
            return
        }
        
//==================================================//
switch(command) {
//—————「 MAIN MENU 」—————//


case "menu": {
let owned = `${global.owner}`
let statususer;
    if (db.data.users[m.sender].owner) {
        statususer = 'Owner 🎐';
    } else if (db.data.users[m.sender].premium) {
        statususer = 'Premium 💎';
    } else {
        statususer = 'User 🐱';
    }
let limitz = db.data.users[m.sender].limit;
let saldoo = db.data.users[m.sender].saldo;

// Fungsi untuk memformat angka ke dalam format IDR

// Memformat saldo
let formattedSaldo = formatIDR(saldoo);

wek = `${gris}「 I N F O  B O T 」${gris}
    
   𖦹 ᴄʀᴇᴀᴛᴏʀ : *@${owned.split("@")[0]}*
   𖦹 ʀᴜɴᴛɪᴍᴇ : *${runtime(process.uptime())}*
   𖦹 ᴍᴏᴅᴇ ʙᴏᴛ : *${KaaKangSatir.public ? `ᴘᴜʙʟɪᴄ` : `sᴇʟғ`}*

${gris}「 I N F O  U S E R 」${gris}

   𖦹 ɴᴀᴍᴇ : *${pushname}*
   𖦹 ɴᴜᴍʙᴇʀ : *${m.sender.split('@')[0]}*
   𖦹 sᴛᴀᴛᴜs : *${statususer}*
   𖦹 ʟɪᴍɪᴛ : *${limitz}*
   𖦹 sᴀʟᴅᴏ : *${formattedSaldo}*`
const caption = `${wek}\n\n\n${menushun(prefix)}`;
let sections = [
{
title: 'All Menu',
highlight_label: 'All Menu List',
rows: [{
title: 'Menu All',
description: `Displays All Menu`, 
id: `${prefix}menu all`
}]},
{
title: 'List Menu',
rows: [{
title: 'Menu Ai',
description: `Displays Ai Menu`, 
id: `${prefix}menu ai`
},
{
title: 'Menu Anime',
description: `Displays Anime Menu`, 
id: `${prefix}menu anime`
},
{
title: 'Menu Audio',
description: `Displays Audio Menu`, 
id: `${prefix}menu audio`
},
{
title: 'Menu Database',
description: `Displays Database Menu`, 
id: `${prefix}menu database`
},
{
title: 'Menu Download',
description: `Displays Download Menu`, 
id: `${prefix}menu download`
},
{
title: 'Menu Fun',
description: `Displays Fun Menu`, 
id: `${prefix}menu fun`
},
{
title: 'Menu Game',
description: `Displays Game Menu`, 
id: `${prefix}menu game`
},
{
title: 'Menu Group',
description: `Displays Group Menu`, 
id: `${prefix}menu group`
},
{
title: 'Menu Other', 
description: "Displays the Other Menu", 
id: `${prefix}menu other`
},
{
title: 'Menu Owner', 
description: "Displays the Owner Menu", 
id: `${prefix}menu owner`
},
{
title: 'Menu Search', 
description: "Displays the Search Menu", 
id: `${prefix}menu search`
},
{
title: 'Menu Store', 
description: "Displays the Store Menu", 
id: `${prefix}menu store`
},
{
title: 'Menu Tools', 
description: "Displays the Tools Menu", 
id: `${prefix}menu tools`
}]
}]

let listMessage = {
    title: 'List Menu', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://kaakangsatir.github.io/IMG-20240630-WA0234.png" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 },
 ],
 })
 })
 }
 }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
if (args[0] === "all") {
    
    let owned = `${global.owner}`
    let statususer;
    if (db.data.users[m.sender].owner) {
        statususer = 'Owner 🎐';
    } else if (db.data.users[m.sender].premium) {
        statususer = 'Premium 💎';
    } else {
        statususer = 'User 🐱';
    }
    let limitz = db.data.users[m.sender].limit;
    let saldoo = db.data.users[m.sender].saldo;

// Fungsi untuk memformat angka ke dalam format IDR

// Memformat saldo
    let formattedSaldo = formatIDR(saldoo);

    wek = `${gris}「 I N F O  B O T 」${gris}
    
   𖦹 ᴄʀᴇᴀᴛᴏʀ : *@${owned.split("@")[0]}*
   𖦹 ʀᴜɴᴛɪᴍᴇ : *${runtime(process.uptime())}*
   𖦹 ᴍᴏᴅᴇ ʙᴏᴛ : *${KaaKangSatir.public ? `ᴘᴜʙʟɪᴄ` : `sᴇʟғ`}*

${gris}「 I N F O  U S E R 」${gris}

   𖦹 ɴᴀᴍᴇ : *${pushname}*
   𖦹 ɴᴜᴍʙᴇʀ : *${m.sender.split('@')[0]}*
   𖦹 sᴛᴀᴛᴜs : *${statususer}*
   𖦹 ʟɪᴍɪᴛ : *${limitz}*
   𖦹 sᴀʟᴅᴏ : *${formattedSaldo}*`
 const caption = `${wek}\n\n${readmore}\n\n${menuai(prefix)}\n\n\n${menuanime(prefix)}\n\n\n${menuaudio(prefix)}\n\n\n${menudatabase(prefix)}\n\n\n${menudownload(prefix)}\n\n\n${menufun(prefix)}\n\n\n${menugame(prefix)}\n\n\n${menugroup(prefix)}\n\n\n${menuother(prefix)}\n\n\n${menuowner(prefix)}\n\n\n${menusearch(prefix)}\n\n\n${menustore(prefix)}\n\n\n${menustickanim(prefix)}\n\n\n${menutools(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 
 } else if (args[0] === 'ai') {
await sleep(1000)
    
 const caption = `${menuai(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'anime') {
await sleep(1000)
    
 const caption = `${menuanime(prefix)}\n\n${menustickanim(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'audio') {
await sleep(1000)
    
 const caption = `${menuaudio(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'database') {
await sleep(1000)
    
 const caption = `${menudatabase(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'download') {
await sleep(1000)
    
 const caption = `${menudownload(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'fun') {
await sleep(1000)
    
 const caption = `${menufun(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'game') {
await sleep(1000)
    
 const caption = `${menugame(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'group') {
await sleep(1000)
    
 const caption = `${menugroup(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'other') {
await sleep(1000)
    
 const caption = `${menuother(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'ai') {
await sleep(1000)
    
 const caption = `${menuai(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'owner') {
await sleep(1000)
    
 const caption = `${menuowner(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'search') {
await sleep(1000)
    
 const caption = `${menusearch(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'store') {
await sleep(1000)
    
 const caption = `${menustore(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: randomMimeType,
            fileLength: 1000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 } else if (args[0] === 'tools') {
await sleep(1000)
    
 const caption = `${menutools(prefix)}`;

KaaKangSatir.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
            fileName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ KaaKangSatir`,
            mimetype: "application/docs",
            fileLength: 10000000000000,
            pageCount: 2024,
			caption: caption,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
	 newsletterName: saluran,
 newsletterJid: idsal,
		},
		externalAdReply: {  
title: `${hariini}`, 
body: `Library: Whiskeysockets/Baileys ${baileysVersion}`,
thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
sourceUrl: '', 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: floc})
 }
}
break

//—————「 AI MENU 」—————//


case 'bingimg': {
  if (!text) return reply(`*Example :* ${prefix + command} promt`);

  // Menghasilkan pengurangan acak antara 1 dan 5
  
  
  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }

  await m.reply(mess.wait);

  try {
    let bing = await fetch(`https://anabot.my.id/api/ai/bingAi?prompt=${text}&apikey=${ana}`);
    let hasil = await bing.json();

    if (hasil.image && hasil.image.length > 0) {
      let push = [];
      let i = 1;

      for (let imageUrl of hasil.image) {
        const mediaMessage = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: KaaKangSatir.waUploadToServer });

        push.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `Image ke - ${i++}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Hasil`,
            subtitle: "",
            hasMediaAttachment: true,
            ...mediaMessage
          }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      buttons: [
            {
              name: "cta_url",
              buttonParamsJson: `{"display_text":"url","url":"${imageUrl}","merchant_url":"${imageUrl}"}`
            }
         ]
      })
        });
      }

      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: mess.success
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: wm
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [
                  ...push
                ]
              })
            })
          }
        }
      }, {});

      await KaaKangSatir.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      });
      global.db.data.users[m.sender].limit -= randomReduction;
    } else {
      reply('No image found');
    }
  } catch (e) {
    console.error(e);
    reply('An error occurred');
  }
}
break

case 'letmegpt': {
      if (isBan) return reply(mess.ban);
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
  let { fetchTextFromURL } = require('./lib/letmegpt');
  if (!text) return reply(`*Example :* ${prefix + command} halo`);
  const query = `${text}`;
  reply(mess.wait)
  fetchTextFromURL(query).then(result => {
    reply(result || 'No result found.');
  }).catch(error => {
    console.error(error);
    reply('An error occurred while fetching the data.');
  });
  global.db.data.users[m.sender].limit -= randomReduction;
}
break;
        
async function fbdown(url) {

    try {

        const postOptions = {

            method: 'POST',

            body: new URLSearchParams({

                URLz: url

            }),

        };

        const response = await fetch('https://fdown.net/download.php', postOptions);

        const html = await response.text();

        const $ = cheerio.load(html);

        return {

            title: $('.lib-row.lib-header').text().trim(),

            description: $('.lib-row.lib-desc').text().trim(),

            sdLink: $('#sdlink').attr('href'),

            hdLink: $('#hdlink').attr('href'),

        };

    } catch (error) {

        console.error('Error:', error.message);

        return null;

    }

};

   

case 'leptonai': {
      if (isBan) return reply(mess.ban);
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
  if (!text) return reply(`*Example :* ${prefix + command} halo`);
  const leptonAi = require('./lib/leptonai');
  reply(mess.wait)
  leptonAi(text)
    .then(response => reply(response))
    .catch(error => reply('Error: ' + error.message));
  global.db.data.users[m.sender].limit -= randomReduction;
}
break;

case 'thinkany': {
      if (isBan) return reply(mess.ban);
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
  let { thinkany } = require('./lib/thinkany');
  if (!text) return reply(`*Example :* ${prefix + command} halo`);
  reply(mess.wait)
  thinkany(`${text}`).then(result => {
    reply(result || 'No result found.');
  }).catch(error => {
    console.error(error);
    reply('An error occurred while fetching the data.');
  });
  global.db.data.users[m.sender].limit -= randomReduction;
}
break;

case 'aoyo': {
  let { postData } = require('./lib/aoyo');
  if (!text) return reply(`*Example :* ${prefix + command} halo`);
    if (isBan) return reply(mess.ban);
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
 reply(mess.wait)
  postData(`${text}`).then(result => {
    if (result.error) {
      reply('An error occurred: ' + result.error);
    } else {
      reply(result);
    }
  }).catch(error => {
    console.error(error);
    reply('An error occurred while fetching the data.');
  });
  global.db.data.users[m.sender].limit -= randomReduction;
}
break;

case 'palm': {
if (isBan) return reply(mess.bann)
  
  
  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }
if (!text) return reply(`*Example :* ${prefix + command} Hai siapa kamu`)
let palm = await fetchJson(`https://api.neoxr.eu/api/palm?q=${text}&apikey=${neoxr}`)
reply(palm.data.message)
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'llma': {
if (isBan) return reply(mess.bann)
  
  
  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }
if (!text) return reply(`*Example :* ${prefix + command} Hai siapa kamu`)
let llma = await fetchJson(`https://rammpntxxx-llma.hf.space/generate?text=${text}&prompt=nama+kamu+adalah+shun,+creator+kamu+adalah+KaaKangSatir`)
reply(llma.content)
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'whois': {
  const { whois } = require('./lib/whois');
  if(!text) return reply(`*Example :* ${prefix + command} link`)
  
  
  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }

  reply(mess.wait);

  whois(text).then(result => {
    if (!result) {
      reply('Failed to fetch WHOIS data.');
    } else {
      const { domains, whoisInfo, expiresOn, registeredOn, updatedOn } = result;
      let response = `THIS WHOIS Information for ${text}:\n\n`;

      if (domains.length > 0) {
        response += 'Domains:\n';
        domains.forEach((domain, index) => {
          response += `${index + 1}. Domain: ${domain.domain}, IP: ${domain.ip}\n`;
        });
      }

      response += `\nWhois Info:\n${whoisInfo}\n`;
      response += `\nExpires On: ${expiresOn}\n`;
      response += `Registered On: ${registeredOn}\n`;
      response += `Updated On: ${updatedOn}\n`;

      reply(response);
    }

    global.db.data.users[m.sender].limit -= randomReduction;
  }).catch(error => {
    console.error(error);
    reply('An error occurred while fetching the data.');
  });
}
break;



case 'dalle': {
      if (isBan) return reply(mess.ban);

    // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    reply(mess.wait);

    if (text && text.length >= 10) { // Memeriksa apakah teks ada dan panjangnya minimal 10 karakter
        const finalUrl = await fetchJson(`https://skizo.tech/api/dalle3?apikey=shun&prompt=${text}`);
        await sleep(500);
        KaaKangSatir.sendMessage(m.chat, { image: { url: finalUrl.url }, caption: `${mess.success}` });
        
        // Mengurangi limit pengguna setelah berhasil memproses teks
        global.db.data.users[m.sender].limit -= randomReduction;
    } else {
        reply(`*Example :* ${prefix + command} cute cat in galaxy. Minimal 10 karakter.`);
    }
}
break;

case 'tozombie':
case 'jadizombie': {
  if (!quoted) return reply(`Where is the picture?`)
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
  reply(mess.wait)
  let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
  let anu = await TelegraPh(media)
let zombie = await fetchJson(`https://api.neoxr.eu/api/tozombie?image=${anu}&apikey=${neoxr}`)
 KaaKangSatir.sendMessage(m.chat,{image: { url: zombie.data.url}, caption: mess.success},{quoted: m})
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'toanime':
case 'jadianime': {
    if (isBan) return reply(mess.ban);
  if (!/image/.test(mime)) return reply(`*Send/Reply the Image With Caption* ${prefix + command}`);
  if (!quoted) return reply(`*Send/Reply the Image Caption* ${prefix + command}`);
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  reply(mess.wait);
  
  try {
    let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
    let anu = await TelegraPh(media)
    let result = `https://skizo.tech/api/toanime?apikey=shun&url=${util.format(anu)}`
    await KaaKangSatir.sendMessage(m.chat, { image: { url: result }, caption: mess.success }, { quoted: m });
    global.db.data.users[m.sender].limit -= randomReduction;

    // Schedule deletion of the file after a few minutes (e.g., 1 or 2 minutes)
    setTimeout(() => {
      fs.unlink(media, (err) => {
        if (err) console.error('Error deleting file:', err);
      });
    }, 60000); // 60000 ms = 1 minute
  } catch (err) {
    console.error(err);
    reply(mess.error);
  }
}
break;

case 'voicevox': {
  if (!text) throw `*Example :* ${prefix + command} *Good Night*`;
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  m.reply(mess.wait);
  try {
    let txt = await (
      await translate(text, { to: "ja", autoCorrect: true }).catch((_) => null)
    ).text.toString();
    let bufferURL = `https://onesytex.my.id/api/voicevox-synthesis?text=${txt}&speaker=20`;
    console.log(`Buffer URL: ${bufferURL}`);
    
    // Unduh audio dari URL
    let response = await fetch(bufferURL);
    if (!response.ok) throw new Error(`Failed to fetch audio: ${response.statusText}`);
    let buffer = await response.buffer();
    
    // Kirim audio
    await KaaKangSatir.sendMessage(m.chat, { audio: buffer, fileName: `${text}.mp3`, mimetype: 'audio/mp4'});
    global.db.data.users[m.sender].limit -= randomReduction;
  } catch (e) {
    console.error(e);
    await reply(mess.error);
  }
}
break

case 'say': {
    if (isBan) return reply(mess.bann)
    if (!text) return reply(`*Example :* ${prefix + command} haloo`)
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    reply(mess.wait)
    sayy = await fetchJson(`https://skizo.tech/api/tts?apikey=shun&text=${text}&voice=`)
    KaaKangSatir.sendMessage(m.chat, { audio: { url: sayy.url }, fileName: `${text}.mp3`, mimetype: 'audio/mp4', caption: mess.success });
    global.db.data.users[m.sender].limit -= randomReduction;
    }
break

case 'tts': {
  if (isBan) return reply(mess.bann)
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (!text) return reply(`*Example :* ${prefix + command} KaaKangSatir Bukan Sepuh`)
  // Check if the version is between 1 and 6
  const validCharacters = ['paimon', 'ayaka', 'raiden', 'miko', 'nilou', 'hutao', 'ganyu', 'nahida', 'keqing', 'layla', 'fishl'];
  
  // Extract the character from the arguments and the text to be converted
  const character = args[0];
  const ttsText = args.slice(1).join(' ');
  
  // Check if the first argument is a valid character
  if (args[0] && validCharacters.includes(args[0])) {
  if (!ttsText) return reply(`*Example :*: ${prefix + command} ${character} halo`);
      
    reply(mess.wait)
    let cap = `${mess.success}`
    let tts;

    switch (args[0]) {
      case 'paimon':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=paimon&speed=Number&symbol=`)
        break;
      case 'ayaka':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=komisato_ayaka&speed=Number&symbol=`)
        break;
      case 'raiden':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=raiden_shogun&speed=Number&symbol=`)
        break
      case 'miko':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=yae_miko&speed=Number&symbol=`)
        break
      case 'nilou':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=nilou&speed=Number&symbol=`)
        break
      case 'hutao':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=hu_tao&speed=Number&symbol=`)
        break
      case 'ganyu':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=ganyu&speed=Number&symbol=`)
        break
      case 'nahida':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=nahida&speed=Number&symbol=`)
        break
      case 'keqing':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=keqing&speed=Number&symbol=`)
        break
      case 'layla':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=layla&speed=Number&symbol=`)
        break
      case 'fishl':
      reply(mess.wait)
        tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=shun&text=${ttsText}&lang=&voice=fishl&speed=Number&symbol=`)
        break;
    }

   // KaaKangSatir.sendMessage(from, { image: { url: imgg }, caption: cap }, { quoted: m });
    KaaKangSatir.sendMessage(m.chat, { audio: { url: tts.data.url_voice }, fileName: `${character}.mp3`, mimetype: 'audio/mp4', caption: cap });
    global.db.data.users[m.sender].limit -= randomReduction;
    return;
  }

  let sections = [
    {
      title: 'Text To Speech',
      rows: [
        { title: 'Paimon', description: `Text To Speech Paimon`, id: `${prefix}tts paimon ${text}` },
        { title: 'Ayaka', description: `Text To Speech Ayaka`, id: `${prefix}tts ayaka ${text}` },
        { title: 'Raiden', description: `Text To Speech Raiden`, id: `${prefix}tts raiden ${text}` },
        { title: 'Miko', description: `Text To Speech Miko`, id: `${prefix}tts miko ${text}` },
        { title: 'Nilou', description: `Text To Speech Nilou`, id: `${prefix}tts nilou ${text}` },
        { title: 'HuTao', description: `Text To Speech HuTao`, id: `${prefix}tts hutao ${text}` },
        { title: 'Ganyu', description: `Text To Speech Ganyu`, id: `${prefix}tts ganyu ${text}` },
        { title: 'Nahida', description: `Text To Speech Nahida`, id: `${prefix}tts nahida ${text}` },
        { title: 'Keqing', description: `Text To Speech Keqing`, id: `${prefix}tts keqing ${text}` },
        { title: 'Layla', description: `Text To Speech Layla`, id: `${prefix}tts layla ${text}` },
        { title: 'Fishl', description: `Text To Speech fishl`, id: `${prefix}tts fishl ${text}` },
      ]
    }
  ];

  let listMessage = {
    title: 'List Menu',
    sections
  };

  let msg = generateWAMessageFromContent(from, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Silahkan pilih *option* di bawah ini`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            gifPlayback: true,
            subtitle: ownername,
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              }
            ],
          }),
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: saluran,
              newsletterJid: idsal,
              serverMessageId: 143
            }
          }
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });
}
break

case 'text2anime':
case 'texttoanime': {
  if (!text) return reply(`*Example :*\n${prefix + command} a teenager with purple hair`);
  
  reply(mess.wait);

  try {
    const imageUrls = [];

    // Membuat 4 permintaan terpisah
    for (let i = 0; i < 4; i++) {
      const res = await fetchJson(`https://api.elxyz.me/ai/texttoanime?apikey=KC-df2284199a80349c&prompt=${text}`);
      imageUrls.push(res.result.imageUrl);
    }

    const push = [];

    // Memproses setiap URL gambar
    for (let i = 0; i < imageUrls.length; i++) {
      const mediaMessage = await prepareWAMessageMedia({ image: { url: imageUrls[i] } }, { upload: KaaKangSatir.waUploadToServer });

      push.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `Image ke - ${i + 1}`
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: wm
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: `Hasil`,
          subtitle: `Generated anime image ${i + 1}`,
          hasMediaAttachment: true,
          ...mediaMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      buttons: [
            {
              name: "cta_url",
              buttonParamsJson: `{"display_text":"url","url":"${imageUrls[i]}","merchant_url":"${imageUrls[i]}"}`
            }
         ]
      })
      });
    }

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: mess.success
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: wm
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: [
                ...push
              ]
            })
          })
        }
      }
    }, {});

    await KaaKangSatir.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id
    });

  } catch (e) {
    console.error(e);
    await reply(mess.error);
  }
}
break;

case 'text2img':
case 'texttoimg': {
  if (isBan) return reply(mess.bann)
  if (!text) return reply(`*Example :*: ${prefix + command} Cat`)
  // Check if the version is between 1 and 7
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  const versionRegex = /^v[1-7]$/;
  if (args[0] && versionRegex.test(args[0])) {
    reply(mess.wait)
    let cap = `${mess.success}`
    let imgg;

    switch (args[0]) {
      case 'v1':
        imgg = `https://aemt.me/ai/text2img?text=${text}`;
        break;
      case 'v2':
        imgg = `https://aemt.me/v1/text2img?text=${text}`;
        break;
      case 'v3':
        imgg = `https://aemt.me/v2/text2img?text=${text}`;
        break;
      case 'v4':
        imgg = `https://aemt.me/v3/text2img?text=${text}`;
        break;
      case 'v5':
        imgg = `https://aemt.me/v4/text2img?text=${text}`;
        break;
      case 'v6':
        imgg = `https://aemt.me/v5/text2img?text=${text}`;
        break;
      case 'v7':
        imgg = `https://aemt.me/v6/text2img?text=${text}`;
        break;
    }

    KaaKangSatir.sendMessage(from, { image: { url: imgg }, caption: cap }, { quoted: m });
    global.db.data.users[m.sender].limit -= randomReduction;
    return;
  }

  let sections = [
    {
      title: 'Text To Image',
      rows: [
        { title: 'Version 1', description: `Text To Image Version 1`, id: `${prefix}text2img v1 ${text}` },
        { title: 'Version 2', description: `Text To Image Version 2`, id: `${prefix}text2img v2 ${text}` },
        { title: 'Version 3', description: `Text To Image Version 3`, id: `${prefix}text2img v3 ${text}` },
        { title: 'Version 4', description: `Text To Image Version 4`, id: `${prefix}text2img v4 ${text}` },
        { title: 'Version 5', description: `Text To Image Version 5`, id: `${prefix}text2img v5 ${text}` },
        { title: 'Version 6', description: `Text To Image Version 6`, id: `${prefix}text2img v6 ${text}` },
        { title: 'Version 7', description: `Text To Image Version 7`, id: `${prefix}text2img v7 ${text}` },
      ]
    }
  ];

  let listMessage = {
    title: 'List Menu',
    sections
  };

  let msg = generateWAMessageFromContent(from, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Silahkan pilih *option* di bawah ini`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: ``,
            gifPlayback: true,
            subtitle: ownername,
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              }
            ],
          }),
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: saluran,
              newsletterJid: idsal,
              serverMessageId: 143
            }
          }
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });
}
break

case 'openai':
case 'gpt4':{
if (!text) return reply(`*Example :* ${command} Halo ai`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
            reply(mess.wait)
            let gpt4 = await fetchJson(`https://aemt.me/v2/gpt4?text=${text}`)
KaaKangSatir.sendMessage(m.chat, { text: gpt4.result }, { quoted: Shun })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'blackbox':
case 'bbox':{
if (!text) return reply(`*Example :* ${command} Text`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
            reply(mess.wait)
            let blackbox = await fetchJson(`https://aemt.me/blackbox?text=${text}`)
KaaKangSatir.sendMessage(m.chat, { text: blackbox.result }, { quoted: Shun })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break



case 'simisimi': 
//—————「 AI MENU 」—————//



//—————「 ANIME MENU 」—————//
case 'searchanime': 
case 'animesearch':
case 'sanime': {
  if (!text) return reply(`*Example :* ${prefix + command} boruto`)
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (text.length > 50) return reply(`*Maksimal 50 Huruf*`)
  var epn = await fetch(`https://dikaardnt.com/api/search/otakudesu?q=${text}`)
  var json = await epn.json()
  var scap = `🎬 *SEARCH ANIME*\n\n📁 *Cloud :* otakudesu.cloud\n📄 *Judul :* ${json[0].title}\n🔖 *Genre :* ${json[0].genres}\n📈 *Status :* ${json[0].status}\n📋 *Nilai :* ${json[0].rating}\n📎 *Streaming :* ${json[0].url}`;
  await KaaKangSatir.sendMessage(m.chat, { image: { url: json[0].image }, caption: scap }, { quoted: m })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'loli': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
reply(mess.wait)
let cap = `${mess.success}`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: cap
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : { url : `https://skizo.tech/api/loli?apikey=shun` }}, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
    global.db.data.users[m.sender].limit -= randomReduction;
}
break
        
        function nekopoisearch(query) {

    return new Promise((resolve, reject) => {

    axios.get(`https://nekopoi.care/search/${query}`)

        .then(({

           data

        }) => {

            const $ = cheerio.load(data)

            const result = [];

            $('#content > div.postsbody > div.result > ul > li').each(function(a, b) {

            result = {

            status: 200,

            author: '@lui',            

            title: $(b).find('> div > h2 > a').text(),

            thumb: $(b).find('> div > div.limitnjg > img').attr('src'),

            info: $(b).find('> div > div.desc').text(),

            url: $(b).find('> div > h2 > a').attr('href')

            }

            hasil.push(result)

            })

            resolve(hasil)

         })

         .catch(reject)

       })

}


//—————「 ANIME MENU 」—————//



//—————「 AUDIO MENU 」—————//
case 'bass': 
case 'blown': 
case 'deep': 
case 'earrape': 
case 'fast': 
case 'fat': 
case 'nightcore': 
case 'reverse': 
case 'robot': 
case 'slow': 
case 'smooth': 
case 'tupai':{
if (!/audio/.test(mime)) return reply(`*Example :* Reply audio dengan caption ${prefix + command}`)
if (!quoted) reply(`*Example :* Reply audio dengan caption ${prefix + command}`)
reply(mess.wait)
try {
let set
if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
if (/earrape/.test(command)) set = '-af volume=12'
if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
if (/reverse/.test(command)) set = '-filter_complex "areverse"'
if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
if (/audio/.test(mime)) {
media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
let ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return m?.reply(mess.error)
let buff = fs.readFileSync(ran)
KaaKangSatir.sendMessage(m?.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
fs.unlinkSync(ran)
})
} else reply(`*Example :* Reply audio dengan caption ${prefix + command}`)
} catch (e) {
console.log(e)
reply('error')
}}
break
//—————「 AUDIO MENU 」—————//



//—————「 DATABASE MENU 」—————//
case 'setcmd': {
      if (isBan) return reply(mess.ban);

    // Menghasilkan pengurangan acak antara 1 dan 5
    

    // Mengecek apakah limit pengguna cukup
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    if (!m.quoted) return reply('Reply Pesan!');
    if (!m.quoted.fileSha256) return reply('SHA256 Hash Missing');
    if (!text) return reply(`Untuk Command Apa?`);

    let hash = m.quoted.fileSha256.toString('base64');

    if (global.db.data.stickercmd[hash] && global.db.data.stickercmd[hash].locked) {
        return reply('You have no permission to change this sticker command');
    }

    global.db.data.stickercmd[hash] = {
        text,
        mentionedJid: m.mentionedJid || [], // Pastikan mentionedJid diinisialisasi
        creator: m.sender,
        at: +new Date(),
        locked: false,
    };

    reply(mess.success);

    // Mengurangi limit pengguna setelah berhasil menambahkan command
    global.db.data.users[m.sender].limit -= randomReduction;
}
break;

case 'delcmd': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!m.quoted) throw reply('Reply Pesan!')
let hash = m.quoted.fileSha256.toString('base64')
if (!hash) reply `Tidak ada hash`
if (global.db.data.stickercmd[hash] && global.db.data.stickercmd[hash].locked) throw reply('You have no permission to delete this sticker command')
delete global.db.data.stickercmd[hash]
reply(mess.success)
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'listcmd': {
      if (isBan) return reply(mess.ban);
    reply(mess.wait);
    await sleep(200);

    let teks = `List of Commands:\n\n`;

    // Mengambil semua perintah dan menyusun teks untuk ditampilkan
    Object.keys(global.db.data.stickercmd).forEach((key, index) => {
        let cmd = global.db.data.stickercmd[key];
        teks += `*No ${index + 1}.*\n`
        teks += `- Command: ${cmd.text}\n`;
        teks += `- Creator: ${cmd.creator}\n`;
        teks += `- Created At: ${new Date(cmd.at).toLocaleString()}\n`;
        teks += `- Locked: ${cmd.locked ? 'Yes' : 'No'}\n\n`;
    });

    KaaKangSatir.sendText(from, teks, m);
}
break;

case 'setreply':{
               if (!isCreator) return reply(mess.owner)
               let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'Silahkan pilih *option* di bawah ini'
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"V1","id":"${prefix + command} v1"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"V2","id":"${prefix + command} v2"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"V3","id":"${prefix + command} v3"}`
              },
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
               if (text.startsWith('v')) {
                  typereply = text
                  reply(mess.success)
               } else {
                  reply(`v1, v2, v3`)
               }
            }
break
//—————「 DATABASE MENU 」—————//



//—————「 DOWNLOAD MENU 」—————//
case 'play': {
                if (!text) return reply(`*Example :* ${prefix + command} Drunk Text`)
                 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
                let search = await yts(text)
                let linknya = search.all[0].url
                let bodytextnya = `ᴛɪᴛʟᴇ : *${search.all[0].title}*\nᴠɪᴇᴡs : *${search.all[0].views}*\nᴅᴜʀᴀᴛɪᴏɴ : *${search.all[0].timestamp}*\nᴜᴘʟᴏᴀᴅᴇᴅ : *${search.all[0].ago}*\nᴜʀʟ : *${linknya}*`
               // KaaKangSatir.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
                
            let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: bodytextnya
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : { url : search.all[0].thumbnail }}, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Video 🎬","id":"${prefix}ytmp4 ${linknya}"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Audio 🎵","id":"${prefix}ytmp3 ${linknya}"}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
            









//—————「 DOWNLOAD MENU 」—————//



//—————「 OTHER MENU 」—————//
case 'picre': {
if (isBan) return reply(mess.bann)
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
    
 global.db.data.users[m.sender].limit -= randomReduction;
  async function sendPicreCards() {
    try {
      const imageUrl = 'https://pic.re/image';
      const cards = [];

      for (let i = 1; i <= 5; i++) {
        // Membuat pesan media untuk gambar
        const mediaMessage = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: KaaKangSatir.waUploadToServer });

        // Menyiapkan card dengan gambar dan caption
        const card = {
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: ""
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Gambar ke - ${i}`,
            hasMediaAttachment: true,
            ...mediaMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Url","url":"${imageUrl}","merchant_url":"${imageUrl}"}`
              }
            ]
          })
        };

        cards.push(card);
      }

      // Membuat pesan interaktif dengan beberapa cards
      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: 'Berikut adalah 5 gambar dari pic.re'
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: wm
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: cards
              })
            })
          }
        }
      }, {});

      // Mengirim pesan interaktif
      await KaaKangSatir.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      });
    } catch (e) {
      console.error(e);
      await reply('Terjadi kesalahan saat mengirim gambar.');
    }
  }

  sendPicreCards().catch(console.error);
}
  break;
  
  ;

case 'rule34': {
if (isBan) return reply(mess.bann)
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
    
 global.db.data.users[m.sender].limit -= randomReduction;
  // Menghasilkan pengurangan acak antara 1 dan 5
  

  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }

  await m.reply(mess.wait);

  async function rule34Random() {
    try {
      let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1');
      let results = response.data;

      if (!Array.isArray(results) || results.length === 0) {
        throw new Error('Tidak ada gambar ditemukan');
      }

      return results;
    } catch (error) {
      console.error('Error:', error);
      return { status: 500, error: error.message };
    }
  }

  async function sendRandomRule34Images(m) {
    try {
      let results = await rule34Random();
      if (results.status === 500) {
        throw new Error(results.error);
      }

      // Memilih 5 gambar acak dari hasil
      let selectedImages = [];
      for (let i = 0; i < 5; i++) {
        selectedImages.push(results[Math.floor(Math.random() * results.length)]);
      }

      let cards = [];
      let i = 1;
      for (let image of selectedImages) {
        let imageUrl = image.file_url;
        let cap = `*Author :* ${image.owner ?? 'Tidak diketahui'}`;

        const mediaMessage = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: KaaKangSatir.waUploadToServer });

        cards.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: cap
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Gambar ke - ${i++}`,
            hasMediaAttachment: true,
            ...mediaMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Url","url":"${imageUrl}","merchant_url":"${imageUrl}"}`
              }
            ]
          })
        });
      }

      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: mess.success
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: wm
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: cards
              })
            })
          }
        }
      }, {});

      await KaaKangSatir.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      });

      // Mengurangi limit pengguna
      global.db.data.users[m.sender].limit -= randomReduction;
    } catch (e) {
      console.error(e);
      await reply(mess.error);
    }
  }

  sendRandomRule34Images(m).catch(console.error);
}
break

case 'cosplay': {
if (isBan) return reply(mess.bann)
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    
    
 global.db.data.users[m.sender].limit -= randomReduction;
  async function sendCosplayCards() {
    try {
      const apiUrl = 'https://fantox-cosplay-api.onrender.com/';
      const cards = [];

      for (let i = 1; i <= 5; i++) {
        // Membuat pesan media untuk gambar
        const mediaMessage = await prepareWAMessageMedia({ image: { url: apiUrl } }, { upload: KaaKangSatir.waUploadToServer });

        // Menyiapkan card dengan gambar dan caption
        const card = {
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: ""
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Gambar Cosplay ke - ${i}`,
            hasMediaAttachment: true,
            ...mediaMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Url","url":"${apiUrl}","merchant_url":"${apiUrl}"}`
              }
            ]
          })
        };

        cards.push(card);
      }

      // Membuat pesan interaktif dengan beberapa cards
      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: 'Berikut adalah 5 gambar cosplay'
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: wm
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: cards
              })
            })
          }
        }
      }, {});

      // Mengirim pesan interaktif
      await KaaKangSatir.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      });
    } catch (e) {
      console.error(e);
      await reply('Terjadi kesalahan saat mengirim gambar.');
    }
  }

  sendCosplayCards().catch(console.error);
}
break;

case 'ocr': {
  if (!quoted) return reply(`Where is the picture?`)
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
  reply(mess.wait)
  let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
  let anu = await TelegraPh(media)
let ocr = await fetchJson(`https://api.neoxr.eu/api/ocr?image=${anu}&apikey=${neoxr}`)
 reply(ocr.data.text)
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'nulis': {
if (!text) return reply(`*Example :* ${prefix + command} Java Or Jawa`)
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
reply(mess.wait)
let nulis = await fetchJson(`https://api.neoxr.eu/api/nulis?text=${text}&apikey=${neoxr}`)
 KaaKangSatir.sendMessage(m.chat,{image: { url: nulis.data.url}, caption: mess.success},{quoted: m})
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

    case 'leaderboard':
    case 'top': {
        function formatIDR(amount) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(amount);
        }

        function generateLeaderboard(users) {
            // Mengonversi objek pengguna menjadi array untuk diurutkan
            let usersArray = Object.keys(users).map(userID => {
                return { userID: userID.replace('@s.whatsapp.net', ''), saldo: users[userID].saldo };
            });

            // Mengurutkan array berdasarkan saldo dari yang terbesar ke yang terkecil
            usersArray.sort((a, b) => b.saldo - a.saldo);

            // Membuat string leaderboard
            let leaderboard = '🏆 *Leaderboard* 🏆\n\n';
            usersArray.slice(0, 25).forEach((user, index) => {
                leaderboard += `- *No :* ${index + 1}\n- *Id :* ${user.userID}\n- *Saldo :* ${formatIDR(user.saldo)}\n\n`;
                leaderboard += '──────────────────────\n';
            });

            return leaderboard;
        }

        try {
            let users = global.db.data.users;

            // Menghasilkan leaderboard
            let leaderboard = generateLeaderboard(users);

            // Mengirim balasan dengan leaderboard
            reply(leaderboard);
        } catch (err) {
            console.log(err);
            reply('Terjadi kesalahan saat membuat leaderboard.');
        }
    }
    break;
    
case 'd': 

case 'tr':
case 'translate':{
  	if (!q) return reply(`*Where is the text*\n\n*Example usage*\n*${prefix + command} <language id> <text>*\n*${prefix + command} ja yo wassup*`)
  	 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  	const defaultLang = 'en'
const tld = 'cn'
    let err = `
 *Example:*

*${prefix + command}* <id> [text]
*${prefix + command}* en Hello World

${gris}List of supported languages${gris}
https://cloud.google.com/translate/docs/languages
`.trim()
    let lang = args[0]
    let text = args.slice(1).join(' ')
    if ((args[0] || '').length !== 2) {
        lang = defaultLang
        text = args.join(' ')
    }
    if (!text && m.quoted && m.quoted.text) text = m.quoted.text
    try {
       let result = await translate(text, { to: lang, autoCorrect: true }).catch(_ => null) 
       reply(result.text)
    global.db.data.users[m.sender].limit -= randomReduction;
    } catch (e) {
        return reply(mess.error)
    } 
    }
    break
 
 
 case 'ytkomen':
 case 'ytcmd':
 case 'ytcomment':       
 case 'ytcommand': {
    if (isBan) return m.reply(mess.bann);

    // Menghasilkan pengurangan acak antara 1 dan 5
    let randomReduction = Math.floor(Math.random() * 5) + 1;

    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    reply(mess.wait);

    if (!text) {
        reply(`*Example :* ${prefix + command} Dontol`);
        return;
    }

    try {
        let ytcmnt = await getBuffer(`https://itzpire.com/maker/yt-comment?username=${pushname}&pp_user=${ProfileUsers}&comment=${text}`);
        
        if (!ytcmnt) {
            reply('Gagal mendapatkan gambar. Coba lagi nanti.');
            return;
        }

        const cap = `${mess.success}`;
        await KaaKangSatir.sendMessage(m.chat, { image: ytcmnt, caption: cap }, { quoted: m });
        
        // Mengurangi limit pengguna
        global.db.data.users[m.sender].limit -= randomReduction;
    } catch (err) {
        console.log(err);
        reply('Terjadi kesalahan saat mengirim gambar.');
    }
}
break;

case 'carbon':{
if (isBan) return m.reply(mess.bann)
if (!text) return reply(`*Example :* ${prefix + command} textnya`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
reply(mess.wait)
let res = await fetch(`https://aemt.me/carbon?text=${text}`)
let carbon = await res.json()
let cap = `${mess.success}`
KaaKangSatir.sendMessage(from, {image: { url: carbon.result },caption: cap},{ quoted:m })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'sc':
case 'script': {
    function generateReferenceId(length = 11) {
        return crypto.randomBytes(length).toString('hex').toUpperCase().slice(0, length);
    }

    let caption = `Tertarik? hubungi kontak di bawah\n\n- WA: _https://wa.link/owd53i_\n`;
    const referenceId = generateReferenceId();

    let msg = await generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: caption,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: wm,
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: true,
                            ...(await prepareWAMessageMedia(
                                { image: { url: `https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg` } },
                                { upload: KaaKangSatir.waUploadToServer },
                            )),
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                "name": "review_and_pay",
                                "buttonParamsJson": `{
                                    "currency": "IDR",
                                    "payment_configuration": "",
                                    "payment_type": "",
                                    "total_amount": {
                                        "value": 3000661,
                                        "offset": 100
                                    },
                                    "reference_id": "${referenceId}",
                                    "type": "physical-goods",
                                    "order": {
                                        "status": "payment_requested",
                                        "description": "",
                                        "subtotal": {
                                            "value": 5000000,
                                            "offset": 100
                                        },
                                        "tax": {
                                            "value": 661,
                                            "offset": 100
                                        },
                                        "discount": {
                                            "value": 2000000,
                                            "offset": 100
                                        },
                                        "order_type": "ORDER",
                                        "items": [
                                            {
                                                "retailer_id": "7537631592926009",
                                                "product_id": "7538731592926009",
                                                "name": "${botname}",
                                                "amount": {
                                                    "value": 450510,
                                                    "offset": 1000
                                                },
                                                "quantity": ${totalFitur()}
                                            }
                                        ]
                                    },
                                    "additional_note": "━──────────────────────━\n\n- Button\n- No Enc\n- Free Apikey\n- Free Update SC Forever\n\n━──────────────────────━",
                                    "native_payment_methods": []
                                }`
                            }],
                        }),
                        contextInfo: {
                            stanzaId: m.key.id,
                            remoteJid: m.isGroup ? m.sender : m.key.remoteJid,
                            participant: m.key.participant || m.sender,
                            fromMe: m.key.fromMe,
                            quotedMessage: m.message,
                        },
                    }),
                },
            },
        },
        {},
    );

   if (!m.isGroup) return KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
    
   if (m.isGroup) return KaaKangSatir.relayMessage(m.chat, {
        "requestPaymentMessage": {
            amount: {
                value: 30006610,
                offset: 100,
                currencyCode: 'IDR'
            },
            amount1000: 30006610,
            background: null,
            currencyCodeIso4217: 'IDR',
            expiryTimestamp: 1000000,
            noteMessage: {
                extendedTextMessage: {
                    text: '━────────────────────━\n\n- Button\n- No Enc\n- Free Apikey\n- Free Update SC Forever\n\n━────────────────────━',
                }
            },
            requestFrom: m.sender
        }
    }, {});
}
break



case 'limit':{
reply(`*Your Limit:* ${(db.data.users[m.sender].limit)}\nWant to buy limits? type ${gris}${prefix}buylimit${gris}`)
}
break

case 'saldo':{
let saldoo = db.data.users[m.sender].saldo;
// Memformat saldo
let formattedSaldo = formatIDR(saldoo);
reply(`*Your Saldo:* ${formattedSaldo}`)
}
break

;
        case "getsw": {
          if (m.quoted?.chat != "status@broadcast")
            return reply(`Reply Status WhatsApp !`);
          let buffer = await m.quoted.download();
          await KaaKangSatir.sendFile(
            m.chat,
            buffer,
            "",
            m.quoted.text || "",
            null,
            false,
            { quoted: m },
          ).catch((_) => reply(m.quoted.text || ""));
        }
        break;



case 'runtime': {
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
rin = `*Runtime :* _${runtime(process.uptime())}_\n*Response Speed :* _${latensi.toFixed(4)} Second_\n*Ram :* _${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}_`
await KaaKangSatir.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ctext(rin),
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break



case 'listcase': {
let { listCase } = require('./lib/scrapelistCase.js')
reply(listCase())
}
break

//—————「 OTHER MENU 」—————//



//—————「 FUN MENU 」—————//
case 'apakah': {
if (!text) {
        return reply(`Penggunaan ${command} text\n\n*Example :* ${command} saya wibu`)
    }
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
const kah = apa[Math.floor(Math.random() * apa.length)]
reply(`Pertanyaan : Apakah ${text}\nJawaban : ${kah}`)
}
break
case 'pedocek': {
if (!text) {
 return reply(`Penggunaan ${command} Nama\n\n*Example :* ${command} Rifky`)
 }
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }

 global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
reply(`Nama : ${text}\nJawaban : *${sange}%*`)
}
break
case 'bisakah': {
if (!text) {
        return reply(`Penggunaan ${command} text\n\n*Example :* ${command} saya menjadi presiden`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
const ga = bisa[Math.floor(Math.random() * bisa.length)]
reply(`Pertanyaan : Apakah ${text}\nJawaban : ${ga}`)
}
break
case 'bagaimanakah': {
if (!text) {
        return reply(`Penggunaan ${command} text\n\n*Example :* ${command} cara mengatasi sakit hati`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Gimana yeee']
const ya = gimana[Math.floor(Math.random() * gimana.length)]
reply(`Pertanyaan : Bagaimanakah ${text}\nJawaban : ${ya}`)
}
break
case 'rate': {
    if (!text) {
        return reply(`Penggunaan ${command} text\n\n*Example :* ${command} Gambar aku`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
    reply(mess.wait)
    await sleep(500)
    const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
    const te = ra[Math.floor(Math.random() * ra.length)]
    reply(`Rating : ${text}\nJawaban : *${te}%*`)
}
break
case 'gantengcek': case 'cekganteng': {
if (!text) {
        return reply(`Penggunaan ${command} Nama\n\n*Example :* ${command} KaaKangSatir`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62% Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
const teng = gan[Math.floor(Math.random() * gan.length)]
reply(`Nama : ${text}\nJawaban : *${teng}*`)
}
break           
case 'cantikcek': case 'cekcantik': {
if (!text) {
        return reply(`Penggunaan ${command} Nama\n\n*Example :* ${command} Shun`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const can = ['10% banyak" perawatan ya kak:v\nCanda Perawatan:v','30% Semangat Kaka Merawat Dirinya><','20% Semangat Ya Kaka👍','40% Wahh Kaka><','50% kaka cantik deh><','60% Hai Cantik🐊','70% Hai Ukhty🐊','62% Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97% Assalamualaikum Ukhty🐊','100% Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94% Hai Cantik><','75% Hai Kakak Cantik','82% wihh Kakak Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
const tik = can[Math.floor(Math.random() * can.length)]
reply(`Nama : ${text}\nJawaban : *${tik}*`)
}
break
case 'sangecek': case 'ceksange': case 'gaycek': case 'cekgay': case 'lesbicek': case 'ceklesbi': {
if (!text) {
        return reply(`Penggunaan ${command} Nama\n\n*Example :* ${command} Rifky`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
reply(`Nama : ${text}\nJawaban : *${sange}%*`)
}
break
case 'kapankah': {
if (!text) {
        return reply(`Penggunaan ${command} Pertanyaan\n\n*Example :* ${command} Saya Pintar`)
    }
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
reply(`Pertanyaan : ${text}\nJawaban : *${kapankah}*`)
}
break
//—————「 FUN MENU 」—————//



//—————「 GAME MENU 」—————//
case 'wwpc':
case 'ww':
case 'werewolf': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

let {
    emoji_role,
    sesi,
    playerOnGame,
    playerOnRoom,
    playerExit,
    dataPlayer,
    dataPlayerById,
    getPlayerById,
    getPlayerById2,
    killWerewolf,
    killww,
    dreamySeer,
    sorcerer,
    protectGuardian,
    roleShuffle,
    roleChanger,
    roleAmount,
    roleGenerator,
    addTimer,
    startGame,
    playerHidup,
    playerMati,
    vote,
    voteResult,
    clearAllVote,
    getWinner,
    win,
    pagi,
    malam,
    skill,
    voteStart,
    voteDone,
    voting,
    run,
    run_vote,
    run_malam,
    runprefixagi
} = require('./lib/werewolf.js')

// [ Thumbnail ] 
let thumb =
    "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";

    const {
        sender,
        chat
    } = m;
    KaaKangSatir.werewolf = KaaKangSatir.werewolf ? KaaKangSatir.werewolf : {};
    const ww = KaaKangSatir.werewolf ? KaaKangSatir.werewolf : {};
    const data = ww[chat];
    const value = args[0];
    const target = args[1];
let byId = getPlayerById2(sender, parseInt(target), ww); 
    // [ Membuat Room ]
    if (value === "create") {
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
        if (chat in ww) return reply("Group masih dalam sesi permainan");
        if (playerOnGame(sender, ww) === true)
            return reply("Kamu masih dalam sesi game");
        ww[chat] = {
            room: chat,
            owner: sender,
            status: false,
            iswin: null,
            cooldown: null,
            day: 0,
            time: "malem",
            player: [],
            dead: [],
            voting: false,
            seer: false,
            guardian: [],
        };
        await reply("Room berhasil dibuat, ketik *.ww join* untuk bergabung");
         // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;

        // [ Join sesi permainan ]
    } else if (value === "join") {
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
        if (!ww[chat]) return reply("Belum ada sesi permainan");
        if (ww[chat].status === true)
            return reply("Sesi permainan sudah dimulai");
        if (ww[chat].player.length > 16)
            return reply("Maaf jumlah player telah penuh");
        if (playerOnRoom(sender, chat, ww) === true)
            return reply("Kamu sudah join dalam room ini");
        if (playerOnGame(sender, ww) === true)
            return reply("Kamu masih dalam sesi game");
        let data = {
            id: sender,
            number: ww[chat].player.length + 1,
            sesi: chat,
            status: false,
            role: false,
            effect: [],
            vote: 0,
            isdead: false,
            isvote: false,
        };
        ww[chat].player.push(data);
        let player = [];
        let text = `\n*⌂ W E R E W O L F - P L A Y E R*\n\n`;
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )}\n`;
            player.push(ww[chat].player[i].id);
        }
        text += "\nJumlah player minimal adalah 5 dan maximal 15";
         // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;
        KaaKangSatir.sendMessage(
            m.chat, {
                text: text.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: "https://whatsapp.com/channel/0029Va9scP6CxoAqmRtHG73T",
                        mediaUrl: thumb,
                    },
                    mentionedJid: player,
                },
            }, {
                quoted: m
            }
        );

        // [ Game Play ]
    } else if (value === "start") {
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
        if (!ww[chat]) return reply("Belum ada sesi permainan");
        if (ww[chat].player.length === 0)
            return reply("Room belum memiliki player");
        if (ww[chat].player.length < 5)
            return reply("Maaf jumlah player belum memenuhi syarat");
        if (playerOnRoom(sender, chat, ww) === false)
            return reply("Kamu belum join dalam room ini");
        if (ww[chat].cooldown > 0) {
            if (ww[chat].time === "voting") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_vote(KaaKangSatir. chat, ww);
            } else if (ww[chat].time === "malem") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_malam(KaaKangSatir. chat, ww);
            } else if (ww[chat].time === "pagi") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await runprefixagi(KaaKangSatir. chat, ww);
            }
        }
        if (ww[chat].status === true)
    global.db.data.users[m.sender].limit -= randomReduction;
            return reply("Sesi permainan telah dimulai");
        if (ww[chat].owner !== sender)
            return reply(
                `Hanya @${ww[chat].owner.split("@")[0]} yang dapat memulai permainan`
            );
        let list1 = "";
        let list2 = "";
        let player = [];
        roleGenerator(chat, ww);
        addTimer(chat, ww);
        startGame(chat, ww);
        for (let i = 0; i < ww[chat].player.length; i++) {
            list1 += `(${ww[chat].player[i].number}) @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")}\n`;
            player.push(ww[chat].player[i].id);
        }
        for (let i = 0; i < ww[chat].player.length; i++) {
            list2 += `(${ww[chat].player[i].number}) @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")} ${
          ww[chat].player[i].role === "werewolf" ||
          ww[chat].player[i].role === "sorcerer"
            ? `[${ww[chat].player[i].role}]`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        for (let i = 0; i < ww[chat].player.length; i++) {
            // [ Werewolf ]
            if (ww[chat].player[i].role === "werewolf") {
                if (ww[chat].player[i].isdead != true) {
                    var textt = `Hai ${KaaKangSatir.getName(
              ww[chat].player[i].id
            )}, Kamu telah dipilih untuk memerankan *Werewolf* ${emoji_role(
              "werewolf"
            )} pada permainan kali ini, silahkan pilih salah satu player yang ingin kamu makan pada malam hari ini\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc kill nomor* untuk membunuh player`;
                    await KaaKangSatir.sendMessage(ww[chat].player[i].id, {
                        text: textt,
                        mentions: player,
                    });
                }
                        // [ villager ]
            } else if (ww[chat].player[i].role === "warga") {
                if (ww[chat].player[i].isdead != true) {
                    let texttt = `*⌂ W E R E W O L F - G A M E*\n\nHai ${KaaKangSatir.getName(
              ww[chat].player[i].id
            )} Peran kamu adalah *Warga Desa* ${emoji_role(
              "warga"
            )}, tetap waspada, mungkin *Werewolf* akan memakanmu malam ini, silakan masuk kerumah masing masing.\n*LIST PLAYER*:\n${list1}`;
                    await KaaKangSatir.sendMessage(ww[chat].player[i].id, {
                        text: texttt,
                        mentions: player,
                    });
                }

                // [ Penerawangan ]
            } else if (ww[chat].player[i].role === "seer") {
                if (ww[chat].player[i].isdead != true) {
                    let texxt = `Hai ${KaaKangSatir.getName(
              ww[chat].player[i].id
            )} Kamu telah terpilih  untuk menjadi *Penerawang* ${emoji_role(
              "seer"
            )}. Dengan sihir yang kamu punya, kamu bisa mengetahui peran pemain pilihanmu.\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc dreamy nomor* untuk melihat role player`;

                    await KaaKangSatir.sendMessage(ww[chat].player[i].id, {
                        text: texxt,
                        mentions: player,
                    });
                }

                // [ Guardian ]
            } else if (ww[chat].player[i].role === "guardian") {
                if (ww[chat].player[i].isdead != true) {
                    let teext = `Hai ${KaaKangSatir.getName(
              ww[chat].player[i].id
            )} Kamu terpilih untuk memerankan *Malaikat Pelindung* ${emoji_role(
              "guardian"
            )}, dengan kekuatan yang kamu miliki, kamu bisa melindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n*LIST PLAYER*:\n${list1}\n\nKetik *.wwpc deff nomor* untuk melindungi player`;
  
                    await KaaKangSatir.sendMessage(ww[chat].player[i].id, {
                        text: teext,
                        mentions: player,
                    });
                }

                // [ Sorcerer ]
            } else if (ww[chat].player[i].role === "sorcerer") {
                if (ww[chat].player[i].isdead != true) {
                    let textu = `Hai ${KaaKangSatir.getName(
              ww[chat].player[i].id
            )} Kamu terpilih sebagai Penyihir ${emoji_role(
              "sorcerer"
            )}, dengan kekuasaan yang kamu punya, kamu bisa membuka identitas para player, silakan pilih 1 orang yang ingin kamu buka identitasnya\n*LIST PLAYER*:\n${list2}\n\nKetik *.wwpc sorcerer nomor* untuk melihat role player`;

                    await KaaKangSatir.sendMessage(ww[chat].player[i].id, {
                        text: textu,
                        mentions: player,
                    });
                }
            }
        }
        await KaaKangSatir.sendMessage(m.chat, {
            text: "*⌂ W E R E W O L F - G A M E*\n\nGame telah dimulai, para player akan memerankan perannya masing masing, silahkan cek chat pribadi untuk melihat role kalian. Berhati-hatilah para warga, mungkin malam ini adalah malah terakhir untukmu",
            contextInfo: {
                externalAdReply: {
                    title: "W E R E W O L F",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnail: await resize(thumb, 300, 175),
                    sourceUrl: "https://whatsapp.com/channel/0029Va9scP6CxoAqmRtHG73T",
                    mediaUrl: thumb,
                },
                mentionedJid: player,
            },
        });
        await run(KaaKangSatir. chat, ww);
    } else if (value === "kill") {
       if (byId.db.role === "sorcerer") 
         if (dataPlayer(sender, ww).role !== "werewolf") 
             return m.reply("Peran ini bukan untuk kamu"); 
             return m.reply("Tidak bisa menggunakan skill untuk teman"); 
                  if (playerOnGame(sender, ww) === false)
        return reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return reply(`Masukan nomor player \n*Example :* \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return reply("Player sudah mati")
    if (byId.db.id === sender)
        return reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return reply("Player tidak terdaftar")
      reply("Berhasil membunuh player " + parseInt(target)) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
                 killWerewolf(sender, parseInt(target), ww); 
             }); 
     } else if (value === "dreamy") { 
         if (dataPlayer(sender, ww).role !== "seer") 
             return m.reply("Peran ini bukan untuk kamu"); 
                  if (playerOnGame(sender, ww) === false)
        return reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return reply(`Masukan nomor player \n*Example :* \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return reply("Player sudah mati")
    if (byId.db.id === sender)
        return reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return reply("Player tidak terdaftar")
         let dreamy = dreamySeer(m.sender, parseInt(target), ww); 
         reply(`Berhasil membuka identitas player ${target} adalah ${dreamy}`) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
             }); 
     } else if (value === "deff") { 
         if (dataPlayer(sender, ww).role !== "guardian") 
             return m.reply("Peran ini bukan untuk kamu"); 
                  if (playerOnGame(sender, ww) === false)
        return reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return reply(`Masukan nomor player \n*Example :* \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return reply("Player sudah mati")
    if (byId.db.id === sender)
        return reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return reply("Player tidak terdaftar")
         reply(`Berhasil melindungi player ${target}`).then(() => { 
             protectGuardian(m.sender, parseInt(target), ww); 
             dataPlayer(sender, ww).status = true; 
         }); 
     } else if (value === "sorcerer") { 
         if (dataPlayer(sender, ww).role !== "sorcerer") 
             return m.reply("Peran ini bukan untuk kamu"); 
             if (playerOnGame(sender, ww) === false)
        return reply("Kamu tidak dalam sesi game")
    if (dataPlayer(sender, ww).status === true)
        return reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam")
    if (dataPlayer(sender, ww).isdead === true)
        return reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return reply(`Masukan nomor player \n*Example :* \n${prefix + command} kill 1`)
    if (isNaN(target)) 
        return reply("Gunakan hanya nomor")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return reply("Player sudah mati")
    if (byId.db.id === sender)
        return reply("Tidak bisa menggunakan skill untuk diri sendiri")
    if (byId === false) 
        return reply("Player tidak terdaftar")
         let sorker = sorcerer(sesi(m.sender), target); 
          reply(`Berhasil membuka identitas player ${player} adalah ${sorker}`) 
             .then(() => { 
                 dataPlayer(sender, ww).status = true; 
             }); 
     } else if (value === "vote") {
        if (!ww[chat]) return reply("Belum ada sesi permainan");
        if (ww[chat].status === false)
            return reply("Sesi permainan belum dimulai");
        if (ww[chat].time !== "voting")
            return reply("Sesi voting belum dimulai");
        if (playerOnRoom(sender, chat, ww) === false)
            return reply("Kamu bukan player");
        if (dataPlayer(sender, ww).isdead === true)
            return reply("Kamu sudah mati");
        if (!target || target.length < 1)
            return reply("Masukan nomor player");
        if (isNaN(target)) return reply("Gunakan hanya nomor");
        if (dataPlayer(sender, ww).isvote === true)
            return reply("Kamu sudah melakukan voting");
        b = getPlayerById(chat, sender, parseInt(target), ww);
        if (b.db.isdead === true)
            return reply(`Player ${target} sudah mati.`);
        if (ww[chat].player.length < parseInt(target))
            return reply("Invalid");
        if (getPlayerById(chat, sender, parseInt(target), ww) === false)
            return reply("Player tidak terdaftar!");
        vote(chat, parseInt(target), sender, ww);
        return reply("✅ Vote");
    } else if (value == "exit") {
        if (!ww[chat]) return reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].status === true)
            return reply("Permainan sudah dimulai, kamu tidak bisa keluar");
        let exitww = `${sender.split("@")[0]} Keluar dari permainan`
                KaaKangSatir.sendMessage(
            m.chat, {
                text: exitww,
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: "https://whatsapp.com/channel/0029Va9scP6CxoAqmRtHG73T",
                        mediaUrl: thumb,
                    },
                    mentionedJid: sender,
                },
            }, {
                quoted: m
            }
        );  
        playerExit(chat, sender, ww);
    } else if (value === "delete") {
        if (!ww[chat]) return reply("Tidak ada sesi permainan");
        if (ww[chat].owner !== sender)
            return reply(
                `Hanya @${
            ww[chat].owner.split("@")[0]
          } yang dapat menghapus sesi permainan ini`
            );
        reply("Sesi permainan berhasil dihapus").then(() => {
            delete ww[chat];
        });
    } else if (value === "player") {
        if (!ww[chat]) return reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].player.length === 0)
            return reply("Sesi permainan belum memiliki player");
        let player = [];
        let text = "\n*⌂ W E R E W O L F - G A M E*\n\nLIST PLAYER:\n";
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `(${ww[chat].player[i].number}) @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )} ${
          ww[chat].player[i].isdead === true
            ? `☠️ ${ww[chat].player[i].role}`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        KaaKangSatir.sendMessage(
            m.chat, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: "https://whatsapp.com/channel/0029Va9scP6CxoAqmRtHG73T",
                        mediaUrl: thumb,
                    },
                    mentionedJid: player,
                },
            }, {
                quoted: m
            }
        );
    } else {
        let text = `\n*⌂ W E R E W O L F - G A M E*\n\nPermainan Sosial Yang Berlangsung Dalam Beberapa Putaran/ronde. Para Pemain Dituntut Untuk Mencari Seorang Penjahat Yang Ada Dipermainan. Para Pemain Diberi Waktu, Peran, Serta Kemampuannya Masing-masing Untuk Bermain Permainan Ini\n\n*⌂ C O M M A N D*\n`;
        text += ` ww create\n`;
        text += ` ww join\n`;
        text += ` ww start\n`;
        text += ` ww exit\n`;
        text += ` ww delete\n`;
        text += ` ww player\n`;
        text += `\nPermainan ini dapat dimainkan oleh 5 sampai 15 orang.`;
        KaaKangSatir.sendMessage(
            m.chat, {
                text: text.trim(),
                contextInfo: {
                    externalAdReply: {
                        title: "W E R E W O L F",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: await resize(thumb, 300, 175),
                        sourceUrl: `${global.saluran}`,
                        mediaUrl: thumb,
                    },
                },
            }, {
                quoted: m
            }
        );
    }
}
break

case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
 let TicTacToe = require("./lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw reply('Kamu masih didalam game')
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
reply('Partner ditemukan!')
    global.db.data.users[m.sender].limit -= randomReduction;
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await KaaKangSatir.sendText(room.x, str, m, { mentions: parseMention(str) } )
await KaaKangSatir.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break

case 'delttc': case 'delttt': {
if (isBan) return reply(mess.bann)
 let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
if (!roomnya) reply(`Kamu sedang tidak berada di room tictactoe !`)
delete this.game[roomnya.id]
reply(`Berhasil delete session room tictactoe !`)
}
break

case 'suitpvp': case 'suit': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
this.suit = this.suit ? this.suit : {}
let poin = 10
let poin_lose = 10
let timeout = 60000
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) reply(`Selesaikan suit mu yang sebelumnya`)
if (m.mentionedJid[0] === m.sender) return reply(`Tidak bisa bermain dengan diri sendiri !`)
if (!m.mentionedJid[0]) return reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\n*Example :* ${prefix}suit @${owner[1]}`, from, { mentions: [owner[1] + '@s.whatsapp.net'] })
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) reply(`Orang yang kamu tantang sedang bermain suit bersama orang lain :(`)
let id = 'suit_' + new Date() * 1
let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
 // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;
this.suit[id] = {
chat: await KaaKangSatir.sendText(from, caption, m, { mentions: parseMention(caption) }),
id: id,
p: m.sender,
p2: m.mentionedJid[0],
status: 'wait',
waktu: setTimeout(() => {
if (this.suit[id]) KaaKangSatir.sendText(from, `_Waktu suit habis_`, m)
delete this.suit[id]
}, 60000), poin, poin_lose, timeout
}
}
break

case 'family100': {
    if (!m.isGroup) return reply(mess.group)
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
    if ('family100' + m.chat in _family100) {
        m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
        throw false
    }
    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
    let random = anu[Math.floor(Math.random() * anu.length)]
    reply(mess.wait)
    let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}\n\nWaktu : 3m\n\nKetik *nyerah* untuk menyerah`.trim()
    _family100['family100' + m.chat] = {
        id: 'family100' + m.chat,
        pesan: await KaaKangSatir.sendText(m.chat, hasil, m),
        ...random,
        terjawab: Array.from(random.jawaban, () => false),
        hadiah: 6,
    }

    // Set timeout for 3 minutes (180000 ms)
    _family100['family100' + m.chat].timeout = setTimeout(() => {
        let room = _family100['family100' + m.chat]
        if (room) {
            let finalCaption = `
Waktu Habis!\n\nJawaban Pertanyaan :\n${room.soal}\n\n
${Array.from(room.jawaban, (jawaban, index) => {
                return `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim()
            }).filter(v => v).join('\n')}`.trim()
            KaaKangSatir.sendText(m.chat, finalCaption, m, { contextInfo: { mentionedJid: parseMention(finalCaption) }}).catch(_ => _)
            delete _family100['family100' + m.chat]
        }
    }, 180000) // 3 minutes in milliseconds
}
break

case 'siapakahaku': {
 if (siapaaku.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/siapakahaku.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 siapaaku[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (siapaaku.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${siapaaku[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  delete siapaaku[m.sender.split('@')[0]]
}
}
break

case 'susunkata': {
 if (susunkata.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/susunkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 susunkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (susunkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${susunkata[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  delete susunkata[m.sender.split('@')[0]]
}
}
break

case 'susunkata': {
 if (susunkata.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/susunkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 susunkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (susunkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${susundkata[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  delete susunkata[m.sender.split('@')[0]]
}
}
break
         
case 'asahotak': {
 if (asahotak.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/asahotak.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 asahotak[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (asahotak.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${asahotak[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
  delete asahotak[m.sender.split('@')[0]]
}
}
break

case 'caklontong': {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
}
break

case 'tebak': {
if (isBan) return reply(mess.bann)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `━──「 *O P T I O N* 」──━\n- ${prefix + command} lagu\n- ${prefix + command} gambar\n- ${prefix + command} kata\n- ${prefix + command} kalimat\n- ${prefix + command} lirik\n- ${prefix + command} tebakan\n- ${prefix + command} bendera\n- ${prefix + command} kimia\n━──「 *O P T I O N* 」──━`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaRhL2v8tNF19J7XQPLEVztCM20NsqOPThPg&usqp=CAU' }}, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"List Game\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 if (args[0] === "lagu") {
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebaklagu.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 let msg = await KaaKangSatir.sendMessage(from, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, {quoted:m})
 KaaKangSatir.sendText(from, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, msg).then(() => {
 tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebaklagu[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix} tebak lagu"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 //KaaKangSatir.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/2be1de6c70bec6dbbae83.jpg' }, caption:` Ketik tebak lagu`},{quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'gambar') {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendImage(from, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak gambar"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 //KaaKangSatir.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/2be1de6c70bec6dbbae83.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak gambar`}, {quoted:m}) 
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak katar"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak kalimat"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak lirik"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 //KaaKangSatir.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/2be1de6c70bec6dbbae83.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lirik`} , {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kimia') {
 if (tebakkimia.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebakkimia.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebakkimia[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkimia.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebakkimia[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak tebakan"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
// KaaKangSatir.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/2be1de6c70bec6dbbae83.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kata` }, {quoted:m}) 
 delete tebakkimia[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'tebakan') {
 if (ttebakan.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebaktebakan.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 ttebakan[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (ttebakan.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${ttebakan[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak tebakan"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
// KaaKangSatir.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/2be1de6c70bec6dbbae83.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kata` }, {quoted:m}) 
 delete ttebakan[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'bendera') {
 if (tebakbendera.hasOwnProperty(m.sender.split('@')[0])) throw reply("Masih Ada Sesi Yang Belum Diselesaikan!")
  // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }

    global.db.data.users[m.sender].limit -= randomReduction;
 let anu = await fetchJson('https://raw.githubusercontent.com/H4rdiDev/ShunGame/main/games/tebakbendera.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 KaaKangSatir.sendImage(from, result.img, `Perhatikan Bendera Di Atas\n\nNama Bendera Tersebut Adalah?\nWaktu : 60s\n\nKetik *nyerah* untuk menyerah`, m).then(() => {
 tebakbendera[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakbendera.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Waktu Habis\nJawaban: ${tebakbendera[m.sender.split('@')[0]]}\n\nIngin bermain lagi?`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: ProfileUsers } }, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [ 
                {
                 "name": "single_select",
                 "buttonParamsJson": `{\"title\":\"Game Lainnya\",\"sections\":[{\"title\":\"List Tebak Game\",\"rows\":[{\"title\":\"Tebak Lagu\",\"description\":\"Permainan Tebak Lagu\",\"id\":\"${prefix}tebak lagu\"},{\"title\":\"Tebak Gambar\",\"description\":\"Permainan Tebak Gambar\",\"id\":\"${prefix}tebak gambar\"},{\"title\":\"Tebak Kata\",\"description\":\"Permainan Tebak Kata\",\"id\":\"${prefix}tebak kata\"},{\"title\":\"Tebak Kalimat\",\"description\":\"Permainan Tebak Kalimat\",\"id\":\"${prefix}tebak kalimat\"},{\"title\":\"Tebak Lirik\",\"description\":\"Permainan Tebak Lirik\",\"id\":\"${prefix}tebak lirik\"},{\"title\":\"Tebak Tebakan\",\"description\":\"Permainan Tebak Tebakan\",\"id\":\"${prefix}tebak tebakan\"},{\"title\":\"Tebak Bendera\",\"description\":\"Permainan Tebak Bendera\",\"id\":\"${prefix}tebak bendera\"},{\"title\":\"Tebak Kimia\",\"description\":\"Permainan Tebak Kimia\",\"id\":\"${prefix}tebak kimia\"}]}]}`
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Next","id":"${prefix}tebak bendera"}`
                }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: saluran,
                    newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})
await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id})
 delete tebakbendera[m.sender.split('@')[0]]
 }
 }
}
break
//—————「 GAME MENU 」—————//



//—————「 GROUP MENU 」—————//

case 'settinggc':
case 'setgc': 
case 'settinggroup': 
case 'setgroup':{
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
const caption = `Di Bawah Ini Adalah List Setting Group`;

let sections = [
{
highlight_label: 'Turn On',
rows: [{
title: 'Mute Group ',
id: `${prefix + command} mutegc-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Mute Group',
id: `${prefix + command} mutegc-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti Link',
id: `${prefix + command} antilink-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti Link',
id: `${prefix + command} antilink-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti Sticker',
id: `${prefix + command} antistick-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti Sticker',
id: `${prefix + command} antistick-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti Foto',
id: `${prefix + command} antifoto-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti Foto',
id: `${prefix + command} antifoto-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti Video',
id: `${prefix + command} antivid-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti Video',
id: `${prefix + command} antivid-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti Spam',
id: `${prefix + command} antispam-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti Spam',
id: `${prefix + command} antispam-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Anti NSFW',
id: `${prefix + command} antinsfw-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Anti NSFW',
id: `${prefix + command} antinsfw-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Open Group',
id: `${prefix + command} group-open`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Close Group',
id: `${prefix + command} group-close`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Group Info',
id: `${prefix + command} groupinfo-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Group Info',
id: `${prefix + command} groupinfo-close`
}]
}]

let listMessage = {
    title: 'Setting Bot',
    sections
}

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hii @${m.sender.split("@")[0]}`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDepEscTOq-BHE7HdGW4CkXuu7Fd4MSMuJMoAT_-ybbG6GkMCBSklMoI0&s=10" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})

if (q === 'mutegf-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].mute = true
reply('*_Sukses Turn On Mute Group_*')
} else if (q === 'mutegc-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].mute = false
reply('*_Sukses Turn Off Mute Group_*')
} else if (q === 'antilink-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antilink = true
reply('*_Sukses Turn On Anti Link_*')
} else if (q === 'antilink-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antilink = false
reply('*_Sukses Turn Off Anti Link_*')
} else if (q === 'antistick-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antistick = true
reply('*_Sukses Turn On Anti Sticker_*')
} else if (q === 'antistick-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antistick = false
reply('*_Sukses Turn Off Anti Sticker_*')
} else if (q === 'antifoto-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antifoto = true
reply('*_Sukses Turn On Anti Foto_*')
} else if (q === 'antifoto-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antifoto = false
reply('*_Sukses Turn Off Anti Foto_*')
} else if (q === 'antivid-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antivid = true
reply('*_Sukses Turn On Anti Video_*')
} else if (q === 'antivid-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antivid = false
reply('*_Sukses Turn Off Anti Video_*')
} else if (q === 'antispam-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antispam = true
reply('*_Sukses Turn On Anti Spam_*')
} else if (q === 'antispam-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antispam = false
reply('*_Sukses Turn Off Anti Spam_*')
} else if (q === 'antinsfw-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antinsfw = true
reply('*_Sukses Turn On Anti NSFW_*')
} else if (q === 'antinsfw-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
db.data.chats[m.chat].antinsfw = false
reply('*_Sukses Turn Off Anti NSFW_*')
} else if (q === 'group-open') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
await KaaKangSatir.groupSettingUpdate(from, 'not_announcement').then((res) => reply(`*_Sukses Open Group_*`)).catch((err) => reply(jsonformat(err)))
} else if (q === 'group-close') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
await KaaKangSatir.groupSettingUpdate(from, 'announcement').then((res) => reply(`*_Sukses Closing Group_*`)).catch((err) => reply(jsonformat(err)))
} else if (q === 'groupinfo-on') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
await KaaKangSatir.groupSettingUpdate(from, 'locked').then((res) => reply(`*_Sukses Turn On Group Info_*`)).catch((err) => reply(jsonformat(err)))
} else if (q === 'groupinfo-off') {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
await KaaKangSatir.groupSettingUpdate(from, 'unlocked').then((res) => reply(`*_Sukses Turn Off Group Info_*`)).catch((err) => reply(jsonformat(err)))
}
}
break

case 'opentime': {
    if (!m.isGroup) return reply(mess.group);
    if (!isAdmins) return reply(mess.admin);

    let timeInput = text.trim();
    if (!timeInput) return reply(`Harap masukkan waktu dalam format yang benar (misalnya: 1d untuk 1 detik, 1j untuk 1 jam, 1m untuk 1 menit).`);

    // Function to convert time input to milliseconds
    function convertTimeToMilliseconds(input) {
        let match = input.match(/^(\d+)([djm])$/);
        if (!match) return null;
        let value = parseInt(match[1]);
        let unit = match[2];

        if (isNaN(value)) return null;

        switch (unit) {
            case 'd':
                return value * 1000; // seconds to milliseconds
            case 'j':
                return value * 60 * 60 * 1000; // hours to milliseconds
            case 'm':
                return value * 60 * 1000; // minutes to milliseconds
            default:
                return null;
        }
    }

    let timeInMs = convertTimeToMilliseconds(timeInput);
    if (timeInMs === null) return reply('Format waktu tidak valid. Harap gunakan format yang benar (misalnya: 1d untuk 1 detik, 1j untuk 1 jam, 1m untuk 1 menit).');

    reply(`Grup akan dibuka dalam ${timeInput}.`);

    setTimeout(async () => {
        await KaaKangSatir.groupSettingUpdate(from, 'not_announcement')
            .then((res) => reply(`*_Sukses Open Group_*`))
            .catch((err) => reply(jsonformat(err)));
    }, timeInMs); // Use the converted milliseconds
}
break;

case 'closetime': {
    if (!m.isGroup) return reply(mess.group);
    if (!isAdmins) return reply(mess.admin);

    let timeInput = text.trim();
    if (!timeInput) return reply(`Harap masukkan waktu dalam format yang benar (misalnya: 1d untuk 1 detik, 1j untuk 1 jam, 1m untuk 1 menit).`);

    // Function to convert time input to milliseconds
    function convertTimeToMilliseconds(input) {
        let match = input.match(/^(\d+)([djm])$/);
        if (!match) return null;
        let value = parseInt(match[1]);
        let unit = match[2];

        if (isNaN(value)) return null;

        switch (unit) {
            case 'd':
                return value * 1000; // seconds to milliseconds
            case 'j':
                return value * 60 * 60 * 1000; // hours to milliseconds
            case 'm':
                return value * 60 * 1000; // minutes to milliseconds
            default:
                return null;
        }
    }

    let timeInMs = convertTimeToMilliseconds(timeInput);
    if (timeInMs === null) return reply('Format waktu tidak valid. Harap gunakan format yang benar (misalnya: 1d untuk 1 detik, 1j untuk 1 jam, 1m untuk 1 menit).');

    reply(`Grup akan ditutup dalam ${timeInput}.`);

    setTimeout(async () => {
        await KaaKangSatir.groupSettingUpdate(from, 'announcement')
            .then((res) => reply(`*_Sukses Close Group_*`))
            .catch((err) => reply(jsonformat(err)));
    }, timeInMs); // Use the converted milliseconds
}
break;

case 'getcontact': case 'getcon': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
konstak = await KaaKangSatir.sendMessage(m.chat, {
    text: `Group : *${groupMetadata.subject}*\nMember : *${participants.length}*`
}, {quoted: m, ephemeralExpiration: 86400})
KaaKangSatir.sendContact(m.chat, participants.map(a => a.id), konstak)
}
break
case 'totag': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
if (!isAdmins) return reply(mess.admin)
if (!m.quoted) return `Reply pesan dengan caption ${prefix + command}`
KaaKangSatir.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
}
break

case 'linkgroup': case 'linkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
await loading()
let response = await KaaKangSatir.groupInviteCode(from)
KaaKangSatir.sendText(from, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break

case 'resetlinkgc':
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
await loading()
KaaKangSatir.groupRevokeInvite(from)
break

case 'sendlinkgc': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
await loading()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\n*Example :* ${prefix+command} 628123xxxxxx`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await KaaKangSatir.groupInviteCode(from)
KaaKangSatir.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })

}
break
case 'kick': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await KaaKangSatir.groupParticipantsUpdate(from, [users], 'remove')
reply(mess.success)
}
break
case 'add': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await KaaKangSatir.groupParticipantsUpdate(from, [users], 'add')
reply(mess.success)
}
break
case 'promote': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await KaaKangSatir.groupParticipantsUpdate(from, [users], 'promote')
reply(mess.success)
}
break
case 'demote': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.badm)
if (!isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await KaaKangSatir.groupParticipantsUpdate(from, [users], 'demote')
reply(mess.success)
}
break
case 'hidetag': 
case 'h': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
KaaKangSatir.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted: Shun})
}
break
break
case 'tagall': {
if (!isAdmins) return reply(mess.admin)
if (!m.isGroup) return
await loading()
let teks = `══✪〘 *👥 Tag All* 〙✪══
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
KaaKangSatir.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted:fcall })
}
break

//—————「 GROUP MENU 」—————//



//—————「 OWNER MENU 」—————//
case 'delsampah':
{
 if (!isCreator) return reply(mess.owner);
 reply(mess.wait);
 let directoryPath = './'; // Ganti dengan path yang sesuai di dalam kontainer
 fs.readdir(directoryPath, async function (err, files) {
 if (err) {
 return reply('Tidak dapat memindai direktori: ' + err);
 } 
 let filteredArray = await files.filter(item => item.endsWith("gif") || item.endsWith("png") || item.endsWith("mp3") || item.endsWith("mp4") || item.endsWith("jpg") || item.endsWith("jpeg") || item.endsWith("webp") || item.endsWith("webm")|| item.endsWith("zip")|| item.endsWith("tar.gz"));
 var teks = `Terdeteksi ${filteredArray.length} file sampah\n\n`;
 if (filteredArray.length == 0) return reply(teks);
 for (let i = 0; i < filteredArray.length; i++) {
 console.log("Nama file:", filteredArray[i]); // Tambahkan log untuk memeriksa nama file
 let stats = fs.statSync(path.join(directoryPath, filteredArray[i]));
 console.log("Stats:", stats); // Tambahkan log untuk memeriksa informasi stats
 let fileSizeInBytes = stats.size;
 let fileSize;
 if (fileSizeInBytes < 1024) {
 fileSize = `${fileSizeInBytes} Bytes`;
 } else if (fileSizeInBytes < 1024 * 1024) {
 fileSize = `${(fileSizeInBytes / 1024).toFixed(2)} KB`;
 } else if (fileSizeInBytes < 1024 * 1024 * 1024) {
 fileSize = `${(fileSizeInBytes / (1024 * 1024)).toFixed(2)} MB`;
 } else {
 fileSize = `${(fileSizeInBytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
 }
 teks += `${i+1}. ${filteredArray[i]} - ${fileSize}\n`;
 }
 reply(teks);
 await sleep(2000);
 reply("Menghapus file sampah...");
 await Promise.all(filteredArray.map(async function (file) {
 try {
 await fs.unlinkSync(path.join(directoryPath, file));
 } catch (err) {
 console.error(err);
 }
 }));
 await sleep(2000);
 reply("Berhasil menghapus semua sampah");
 });
}
break



            case 'addlimit': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx 10`);
    
    let [usernya, limitnya] = text.split(' ');
    usernya = usernya.trim();
    limitnya = parseInt(limitnya.trim());
    
    if (isNaN(limitnya)) {
        return reply(`*Error :* Limit harus berupa angka`);
    }
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].limit += limitnya;
    reply(mess.success);
}
break;
            case 'dellimit':{
                if (!isCreator) return reply(mess.owner)
                if (!text) return reply(`*Example :* ${prefix + command} 628xxx 10`)
                usernya = text.split(' ')[0]
                limitnya = text.split(' ')[1]
                if (db.data.users[usernya + '@s.whatsapp.net'].limit < limitnya) return reply(`Batasannya Kurang Dari ${limitnya}`)
                db.data.users[usernya + '@s.whatsapp.net'].limit -= limitnya
                reply(mess.success)
            }
            break
            
            case 'addsaldo': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx 10`);
    
    let [usernya, saldonya] = text.split(' ');
    usernya = usernya.trim();
    saldonya = parseInt(saldonya.trim());
    
    if (isNaN(saldonya)) {
        return reply(`*Error :* Saldo harus berupa angka`);
    }
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].saldo += saldonya;
    reply(mess.success);
}
break;
            case 'delsaldo':{
                if (!isCreator) return reply(mess.owner)
                if (!text) return reply(`*Example :* ${prefix + command} 628xxx 10`)
                usernya = text.split(' ')[0]
                saldonya = text.split(' ')[1]
                if (db.data.users[usernya + '@s.whatsapp.net'].saldo < saldonya) return reply(`Batasannya Kurang Dari ${saldonya}`)
                db.data.users[usernya + '@s.whatsapp.net'].saldo -= saldonya
                reply(mess.success)
            }
            break

case 'pushkontak2':{
if (!isCreator) return reply(mess.owner)
let idgc = text.split("|")[0]
let pesan = text.split("|")[1]
if (!idgc && !pesan) return reply(`*Example :*: ${prefix + command} idgc|pesan`)
let metaDATA = await KaaKangSatir.groupMetadata(idgc).catch((e) => reply(mess.error))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
let count = getDATA.length;
let sentCount = 0;
reply(`*_Sedang Push ID..._*\n*_Mengirim pesan ke ${getDATA.length} orang, waktu selesai ${getDATA.length * 3} detik_*`)
for (let i = 0; i < getDATA.length; i++) {
setTimeout(function() {
KaaKangSatir.sendMessage(getDATA[i], { text: pesan });
count--;
sentCount++;
if (count === 0) {
reply(`*_Semua pesan telah dikirim!:_* *_✓_*\n*_Jumlah pesan terkirim:_* *_${sentCount}_*`);
}
}, i * 3000);
}
}
break

case 'pushkontak':{
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(`di group coy`)
if (!text) return reply(`Teks Nya Kak?`)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik*`)
for (let geek of mem) {
await sleep(3000)
KaaKangSatir.sendMessage(geek, {text: `${teksnye}`}, {quoted:fcall})
}
reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break

case 'getidgc':
if (!m.isGroup) return reply('kusus Group')
ewe = `${m.chat}`
await KaaKangSatir.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 1000000000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: ewe,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
break

case 'join': {
if (!isCreator) return reply(mess.owner)
if (!text) throw 'Masukkan Link Group!'
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
await KaaKangSatir.groupAcceptInvite(result).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
break

case "cekidgc": {
if (!isCreator) return reply(mess.premium)
let getGroups = await KaaKangSatir.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await KaaKangSatir.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas`)
}
break

case 'addgc':

    if (!m.isGroup) return reply(mess.group)         

if (!isCreator) return reply(`khusus Creator`)

ntilink.push(m.chat)
        fs.writeFileSync('./database/idgroup.json', JSON.stringify(ntilink))

reply(`${command} sukses`)

           break
           
case 'delgc':

  if (!isCreator) return reply(`khusus Creator`)

    if (!m.isGroup) return reply(mess.group)

var ini = ntilink.indexOf(m.chat)

ntilink.splice(ini, 1)

fs.writeFileSync('./database/idgruop.json', JSON.stringify(ntilink))

reply(`${command} sukses`)

break

case 'sendsc':
        {
          if (!isCreator) return reply(mess.owner)
          if (!text) return reply(`*Example :* ${prefix + command} tag/number`)
     await reply("Sabar Mas Lagi Di Kirim!!");
          let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
          const { execSync } = require("child_process");
          const ls = (await execSync("ls"))
            .toString()
            .split("\n")
            .filter(
              (pe) =>
                pe != "node_modules" &&
                pe != ".cache" &&
                pe != ".npm" &&
                pe != "yarn.lock" &&
                pe != "session" &&
                pe != "google_vignette"
            );
          const exec = await execSync(`zip -r KaaKangSatir.zip ${ls.join(" ")}`);
          await KaaKangSatir.sendMessage(
            users,
            {
              document: await fs.readFileSync("./KaaKangSatir.zip"),
              mimetype: "application/zip",
              fileName: "ShunAi.zip",
            },
            { quoted: { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: `Jangan Di Jual Yah!!:)`}}} }
          );
          await execSync("rm -rf KaaKangSatir.zip");
        }
break

case 'backup':
        {
          if (!isCreator) return reply(mess.owner)
     await reply("Sabar Mas Lagi Backup!!!");
          const { execSync } = require("child_process");
          const ls = (await execSync("ls"))
            .toString()
            .split("\n")
            .filter(
              (pe) =>
                pe != "node_modules" &&
                pe != ".cache" &&
                pe != ".npm" &&
                pe != "yarn.lock" &&
                pe != "session" &&
                pe != "google_vignette"
            );
          const exec = await execSync(`zip -r KaaKangSatir.zip ${ls.join(" ")}`);
          await KaaKangSatir.sendMessage(
            m.chat,
            {
              document: await fs.readFileSync("./KaaKangSatir.zip"),
              mimetype: "application/zip",
              fileName: "ShunAi.zip",
            },
            { quoted: fcall }
          );
          await execSync("rm -rf KaaKangSatir.zip");
        }
break
        
case 'getcase': {
const getCase = (cases) => {
            return "case "+`'${cases}'`+fs.readFileSync("./shun.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
        }
            try{
                if (!isCreator) return reply('ngapain')
                if (!q) return reply(`*Example :* ${prefix + command} antilink`)
                let nana = await getCase(q)
                reply(nana)
            } catch(err){
            console.log(err)
            reply(`Case ${q} tidak di temukan`)
        }
}
        break 
        
case 'setting':
case 'setbot': 
case 'settingbot': 


case 'addpremium':
case 'addprem': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx 1d`);
    
    let [usernya, waktunya] = text.split(' ');
    usernya = usernya.trim();
    waktunya = waktunya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    let now = new Date();
    let waktuTambahan;
    
    if (waktunya.endsWith('d')) {
        waktuTambahan = parseInt(waktunya.slice(0, -1)) * 24 * 60 * 60 * 1000; // convert days to milliseconds
    } else if (waktunya.endsWith('h')) {
        waktuTambahan = parseInt(waktunya.slice(0, -1)) * 60 * 60 * 1000; // convert hours to milliseconds
    } else if (waktunya.endsWith('m')) {
        waktuTambahan = parseInt(waktunya.slice(0, -1)) * 60 * 1000; // convert minutes to milliseconds
    } else {
        return reply(`*Error :* Format waktu tidak valid. Gunakan format seperti 1d (1 hari), 1h (1 jam), atau 1m (1 menit).`);
    }

    let waktuKadaluarsa = new Date(now.getTime() + waktuTambahan);

    db.data.users[userKey].premium = true;
    db.data.users[userKey].limit = 1000; // Set the limit to 1000 for premium users
    db.data.users[userKey].premiumExpiry = waktuKadaluarsa.getTime(); // Save the expiry time as a timestamp
    reply(mess.success);
}
break;

case 'delprem': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx`);
    
    let [usernya] = text.split(' ');
    usernya = usernya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].premium = false;
    db.data.users[userKey].limit = 100;
    db.data.users[userKey].premiumExpiry = 0; // Optional: Reset premium expiry time
    reply(mess.success);
}
break;

case 'listpremium': {
    if (!isCreator) return reply(mess.owner);

    let users = Object.keys(global.db.data.users);
    let premiumUsers = users.filter(userKey => global.db.data.users[userKey].premium);

    if (premiumUsers.length === 0) {
        return reply('Tidak ada pengguna premium saat ini.');
    }

    let list = 'Daftar Pengguna Premium:\n\n';
    for (let userKey of premiumUsers) {
        let user = global.db.data.users[userKey];
        let phoneNumber = userKey.replace('@s.whatsapp.net', '');
        let expiryDate = new Date(user.premiumExpiry).toLocaleString(); // Convert timestamp to readable date
        list += `Nomor: ${phoneNumber}\nExpiry: ${expiryDate}\n\n`;
    }

    reply(list);
}
break;

case 'ban': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx`);
    
    let [usernya] = text.split(' ');
    usernya = usernya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].banned = true;
    reply(mess.success);
}
break;

case 'unban': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx`);
    
    let [usernya] = text.split(' ');
    usernya = usernya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].banned = false;
    reply(mess.success);
}
break;

case 'listban': {
    let users = Object.keys(global.db.data.users);
    let ownerUsers = users.filter(userKey => global.db.data.users[userKey].owner);

    if (ownerUsers.length === 0) {
        return reply('Tidak ada pengguna owner saat ini.');
    }

    let list = 'Daftar Banned:\n\n';
    for (let userKey of ownerUsers) {
        let user = global.db.data.users[userKey];
        let phoneNumber = userKey.replace('@s.whatsapp.net', '');
        list += `Nomor: ${phoneNumber}\n\n`;
    }

    reply(list);
}
break;


case 'addowner': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx`);
    
    let [usernya] = text.split(' ');
    usernya = usernya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].owner = true;
    reply(mess.success);
}
break;

case 'delowner': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`*Example :* ${prefix + command} 628xxx`);
    
    let [usernya] = text.split(' ');
    usernya = usernya.trim();
    
    let userKey = usernya + '@s.whatsapp.net';
    if (!db.data.users[userKey]) {
        return reply(`*Error :* User tidak ditemukan`);
    }
    
    db.data.users[userKey].owner = false;
    reply(mess.success);
}
break;

case 'listowner': {
    let users = Object.keys(global.db.data.users);
    let ownerUsers = users.filter(userKey => global.db.data.users[userKey].owner);

    if (ownerUsers.length === 0) {
        return reply('Tidak ada pengguna owner saat ini.');
    }

    let list = 'Daftar Pengguna Owner:\n\n';
    for (let userKey of ownerUsers) {
        let user = global.db.data.users[userKey];
        let phoneNumber = userKey.replace('@s.whatsapp.net', '');
        list += `Nomor: ${phoneNumber}\n\n`;
    }

    reply(list);
}
break;

case "bcimg": {
if (!isCreator) return reply(`Lu KaaKangSatir Kah?`)
if (!text) return reply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix+command} teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda Itu Delay Jadi Nominal Jeda Itu 1000 = 1 detik`)
await loading()
let getGroups = await KaaKangSatir.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
for (let xnxx of anu) {
if (/image/.test(mime)) {
media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await KaaKangSatir.sendMessage(xnxx, { image: { url: mem }, caption: text.split('|')[0] })
await sleep(text.split('|')[1])
} else {
await KaaKangSatir.sendMessage(xnxx, { text: text.split('|')[0] })
await sleep(text.split('|')[1])
}}
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break

case 'bcgc': case 'bcgroup': {
if (!isCreator) return reply(mess.owner)
await loading()
if (!text) throw `Text mana?\n\n*Example :* ${prefix + command} fatih-san`
let getGroups = await KaaKangSatir.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
KaaKangSatir.sendMessage(i, {text: `${text}`}, {quoted:fcall})
    }
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break



case 'delcase': {
if (!isCreator) return reply(`*Access Denied ❌*\n\n*Owners only*`)
if (!q) return reply('*Masukan nama case yang akan di hapus*')

dellCase('./shun.js', q)
reply('*Dellcase Successfully*\n\n© Dellcase By KaaKangSatirdev')
}
break




case 'help': {
let desk = `Hai! Nama saya adalah Shun Ai. Saya adalah bot WhatsApp yang dibangun menggunakan library Whiskeysockets/Baileys dengan bahasa pemrograman Node.js. Saya di sini untuk membantu Anda dengan berbagai tugas dan pertanyaan.

- Versi: ${versions}
- Creator: KaaKangSatir 
- Prefix: Multi Prefix 

Untuk melihat fitur-fitur yang tersedia, silakan ketik ${gris}menu${gris}`
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: desk
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://kaakangsatir.github.io/IMG-20240630-WA0234.png" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Menu","id":"${prefix}menu"}`
 },
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 },
 ],
 })
 })
 }
 }
}, {})

KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'del': case 'delete': case 'hapus':
if (!m.isGroup) return reply('apa yg ada lakukan')
if (!isAdmins) return reply('Command ini khusus admin.npc gk diajak')
if (!m.quoted) return reply('Reply pesan yang ingin dihapus!')
KaaKangSatir.sendMessage(from, {delete: {remoteJid: from, id: m.quoted.id, fromMe: m.quoted.fromMe, participant: m.quoted.sender }})
break

























































































































































































































































case 'hapuspesan': 
if (!isCreator) return reply(mess.owner)
if (!m.quoted) return reply('Reply pesan yang ingin dihapus!')
KaaKangSatir.sendMessage(from, {delete: {remoteJid: from, id: m.quoted.id, fromMe: m.quoted.fromMe, participant: m.quoted.sender }})
break

case 'resetlimit': {
if (!isCreator) return reply(mess.owner)
let list = Object.entries(global.db.data.users)
	let lim = !args || !args[0] ? 9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999 : isNumber(args[0]) ? parseInt(args[0]) : 9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999
	lim = Math.max(1, lim)
	list.map(([user, data], i) => (Number(data.limit = lim)))
		KaaKangSatir.sendMessage(m.chat, {text: `*Limit berhasil direset ${lim} / user*`}, { quoted: m })
		}
break







































































































case 'test001': {
if (!text) return reply(`Enter the link!!!`)
if (!isUrl(args[0])) return reply(`Where is the link?`)
await KaaKangSatir.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
reply(mess.wait)
try{
let anu = await fetchJson(`https://aemt.me/download/ytdl?url=${text}`)
KaaKangSatir.sendMessage(m.chat, { video: { url: anu.result.url.urls[0].hd }, caption: 'Ini dia :)' }, { quoted: m })
await KaaKangSatir.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}}) 
}catch (error) {
reply('gagal memproses video')
await KaaKangSatir.sendMessage(m.chat, { react: { text: "✖️",key: m.key,}}) 
}
}
break

























































case 'fbdown': {
 if (!text) throw `Example : ${prefix + command} <url>`; // Error message fixed

 const urlRegex = /^(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.watch)\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/i;
 if (!urlRegex.test(text)) {
 return reply('Url invalid');
 }

 try {
 const result = await fg.fbdl(text);
 const tex = `
 [ FACEBOOK DL ]
 ${themeemoji} Title: ${result.title}`;

 const response = await fetch(result.videoUrl);
 const videoBuffer = await response.buffer(); // Changed from arrayBuffer to buffer

 // Assuming 'KaaKangSatir' is your WhatsApp client instance
 KaaKangSatir.sendMessage(m.chat, { video: videoBuffer, caption: tex }, { quoted: m });
 } catch (error) {
 console.error(error); // Log the error for debugging purposes
 reply('Failed to download video'); // Improved error message
 }
 break;
}



































case 'nekopoisearch': {
if (!text) throw `Masukan query...`
 let res = await nekopoisearch(text)
 let cap = `Hasil Dari ${text}\n\n`
 for (let arf of res.reault) {
 cap += `Title: ${arf.title}
Thumbnail: ${arf.thumb}
Info: ${arf.info}
Url: ${arf.url}`

cap += '\n' + '••••••••••••••••••••••••' + '\n'
 }
m.reply(cap)
}
break

case 'idnekopoi' : {
if (!text) throw `Masukan id...`
let res = await getId(text)
let cap = `Id : ${res.id}
Title : ${res.tile}
Stream : ${res.stream}
Download : ${JSON.stringify(res.download)}`
await KaaKangSatir.sendMessage(m.chat, res.image, 'image.jpg', cap, m)
}
break













case 'speed': {
	const used = process.memoryUsage()
 const cpus = os.cpus().map(cpu => {
 cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			 return cpu
 })
 const cpu = cpus.reduce((last, cpu, _, { length }) => {
 last.total += cpu.total
 last.speed += cpu.speed / length
 last.times.user += cpu.times.user
 last.times.nice += cpu.times.nice
 last.times.sys += cpu.times.sys
 last.times.idle += cpu.times.idle
 last.times.irq += cpu.times.irq
 return last
 }, {
 speed: 0,
 total: 0,
 times: {
			 user: 0,
			 nice: 0,
			 sys: 0,
			 idle: 0,
			 irq: 0
 }
 })
 let timestamp = speed()
 let latensi = speed() - timestamp
 neww = performance.now()
 oldd = performance.now()
 respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
 `.trim()
	KaaKangSatir.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'INR',
 amount1000: 999999999,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: respon,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
 }
	
	break

case 'ping':
case 'botstatus':
case 'statusbot': {
	const disk = require('diskusage')
 const used = process.memoryUsage();
 const cpus = os.cpus().map(cpu => {
 cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
 return cpu;
 });
 let timestamp = speed();
 let latensi = speed() - timestamp;
 neww = performance.now();
 oldd = performance.now();
 
 async function getDiskSpace() {
 try {
 const info = await new Promise((resolve, reject) => {
 disk.check('/', (error, info) => {
 if (error) reject(error);
 else resolve(info);
 });
 });
 console.log('Disk Info:', info);
 
 // Menghitung ruang yang digunakan
 const usedSpace = info.total - info.available;
 
 return { total: info.total, used: usedSpace };
 } catch (error) {
 console.error('Error while getting disk space:', error);
 return { total: 0, used: 0 };
 }
 }
 // Mendapatkan informasi penyimpanan
 const diskSpace = await getDiskSpace();

 const respon = `
 ‣ Kecepatan Respon *${latensi.toFixed(4)} _Second_* \n *${oldd - neww} _miliseconds_*\n\n‣ *Runtime* : ${runtime(process.uptime())}
 
▧「 *INFO SERVER* 」
 ‣ *Sistem Operasi* :
- *Nama* : ${os.type()} ${os.release()}
- *Versi Kernel* : ${os.version()}
- *Host Name* : ${os.hostname()}
- *Arsitektur* : ${os.arch()}
- *Platform* : ${os.platform()}
 ‣ *Jaringan* : 
- *IPv4* : ${os.networkInterfaces().eth0[0].address} (eth0)
- *IPv6* : ${os.networkInterfaces().eth0[1].address} (eth0)
 ‣ *RAM* : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
 ‣ *Penyimpanan* : ${formatp(diskSpace.used)} / ${formatp(diskSpace.total)}
 
${cpus.map((cpu, index) => `▧「 *CPU Core ${index + 1}* 」\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}
 `.trim();
 await KaaKangSatir.sendMessage(m.chat, {
 text: respon,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: 'STATUS SERVER',
 body: `${latensi.toFixed(4)} Second`,
 thumbnailUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5ycLmipE03nJQWELn5Xnbk4oQFB0TuATkSQ&usqp=CAU',
 sourceUrl: 'https://chat.whatsapp.com/I0Q4Od9cRnJ9TPqgChpwlU',
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: Shun
 });
}
break

case 'setting':
case 'setbot': 
case 'settingbot': 
case 'bot':{
if(!isCreator) return reply(`Hayy👋 ${pushname}, ada yang bisa kubantu?`)
const caption = `Di Bawah Ini Adalah List Setting Bot`;
let sections = [
{
highlight_label: 'Turn On',
rows: [{
title: 'Myself ',
id: `${prefix + command} myself-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Myself',
id: `${prefix + command} myself-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Auto Bio',
id: `${prefix + command} autobio-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Auto Bio',
id: `${prefix + command} autobio-off`
}]
},
{
highlight_label: 'Turn On',
rows: [{
title: 'Auto Read',
id: `${prefix + command} autoread-on`
}]
},
{
highlight_label: 'Turn Off',
rows: [{
title: 'Auto Read',
id: `${prefix + command} autoread-off`
}]
}]

let listMessage = {
    title: 'Setting Bot', 
    sections
}


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hii @${m.sender.split("@")[0]}`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/b040c01dbe4f2e32d83d3.png" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})

if (q === 'myself-on') {
if (!isCreator) return reply(mess.owner) 
KaaKangSatir.public = false
reply('*_Sukses Turn On Myself_*')
} else if (q === 'myself-off') {
if (!isCreator) return reply(mess.owner) 
KaaKangSatir.public = true
reply('*_Sukses Turn Off Myself_*')
} else if (q === 'autobio-on') {
if (!isCreator) return reply(mess.owner) 
autobio = true
reply('*_Sukses Turn On Autobio_*')
} else if (q === 'autobio-off') {
if (!isCreator) return reply(mess.owner) 
autobio = false
reply('*_Sukses Turn Off Autobio_*')
} else if (q === 'auroread-On') {
if (!isCreator) return reply(mess.owner) 
autoread = true
reply('*_Sukses Turn On Autoread_*')
} else if (q === 'autoread-off') {
if (!isCreator) return reply(mess.owner) 
autoread = false
reply('*_Sukses Turn Off Autoread*_')
}
}
break

case 'afk': {
if (isBan) return reply(mess.bann)
let user = global.db.data.users[m.sender]
user.afkTime = + new Date
user.afkReason = text
reply(`😓 Yahh, Kak *${pushname}*... Telah Afk\n\n ❏ *Alasan* ${text ? ': ' + text : ''}`)
}
break





case 'readviewonce': {
if (!m?.quoted) return m?.reply('m?.reply gambar/video yang ingin Anda lihat')
if (m?.quoted.mtype !== 'viewOnceMessageV2') return m?.reply('Ini bukan pesan view-once.')
let msg = m?.quoted.message
let type = Object.keys(msg)[0]
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
if (/video/.test(type)) {
return KaaKangSatir.sendFile(m?.chat, buffer, 'media.mp4', msg[type].caption || '', m)
} else if (/image/.test(type)) {
return KaaKangSatir.sendFile(m?.chat, buffer, 'media.jpg', msg[type].caption || '', m)
}
}
break






























case 'gemini':{

if (!text) return reply(`*Example :* ${command} Text`)

 // Menghasilkan pengurangan acak antara 1 dan 5

    

    

    if (global.db.data.users[m.sender].limit < randomReduction) {

        reply(mess.endLimit);

        return; // Menghentikan eksekusi jika batas telah habis

    }

            

try {

        reply(mess.wait);

        let response = await fetchJson(`https://api.neoxr.eu/api/gemini-chat?q=${text}&apikey=KaaKangSatir`);

        

        if (response.status && response.data && response.data.message) {

            let message = response.data.message;

            KaaKangSatir.sendMessage(m.chat, { text: message }, { quoted: m });

            global.db.data.users[m.sender].limit -= randomReduction;

        } else {

            reply('Respon API tidak sesuai format yang diharapkan.');

        }

    } catch (err) {

        console.error(err);

        reply('Terjadi kesalahan dalam menghubungi server.');

    }
}
break
    







case 'sukicek': {
if (!text) {
 return reply(`Penggunaan ${command} Nama\n\n*Example :* ${command} Rifky`)
 }
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }

 global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
await sleep(500)
const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
reply(`Nama : ${text}\nJawaban : *${sange}%*`)
}
break

case 'toaudio': case 'toaud':{
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)

await sleep(200)
if (!/video/.test(mime) && !/audio/.test(mime)) reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
if (!quoted) reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
let media = await quoted.download()
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
KaaKangSatir.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'cry': 
case 'kill': 
case 'hug': 
case 'pat': 
case 'lick': 
case 'kiss': 
case 'bite': 
case 'yeet': 
case 'bully': 
case 'bonk': 
case 'wink': 
case 'poke': 
case 'nom': 
case 'slap': 
case 'smile': 
case 'wave': 
case 'awoo': 
case 'blush': 
case 'smug': 
case 'glomp': 
case 'happy': 
case 'dance': 
case 'cringe': 
case 'cuddle': 
case 'highfive': 
case 'handhold':{
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)
axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
KaaKangSatir.sendImageAsSticker(m.chat, data.url, m, { packname: global.packname, author: global.author })
})
 global.db.data.users[m.sender].limit -= randomReduction;
}
break



case 'blowjob':
case 'trap':
case 'neko':
case 'waifu': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)
let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Silahkan pilih *option* di bawah ini`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"SFW","id":"${prefix + command} sfw"}`
 },
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"NSFW","id":"${prefix + command} nsfw"}`
 }
 ],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
if (args[0] === "sfw") {
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)
let res = await fetch(`https://waifu.pics/api/sfw/${command}`)
let json = await res.json()
let cap = `${mess.success}`
//KaaKangSatir.sendMessage(from, {image: { url: json.url },caption: cap},{ quoted:m })
let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: cap
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image : { url : json.url }}, { upload: KaaKangSatir.waUploadToServer})), 
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
 }
 ],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, {})

KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
 global.db.data.users[m.sender].limit -= randomReduction;
} else if (args[0] === "nsfw") {
 global.db.data.users[m.sender].limit -= randomReduction;
reply(mess.wait)
let res = await fetch(`https://waifu.pics/api/nsfw/${command}`)
let json = await res.json()
let cap = `${mess.success}`
//KaaKangSatir.sendMessage(from, {image: { url: json.url },caption: cap},{ quoted:m })
let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: cap
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image : { url : json.url }}, { upload: KaaKangSatir.waUploadToServer})), 
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
 }
 ],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, {})
KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
 global.db.data.users[m.sender].limit -= randomReduction;
}
}
break







case 'renungan':{

global.renungan = [
"https://telegra.ph/file/f52f8d6312f3ac2590727.jpg", 
"https://telegra.ph/file/35cb9decc525a3453ba87.jpg",
"https://telegra.ph/file/5996566cb5cd615f60f51.jpg",
"https://telegra.ph/file/87ecb0f385ae390c609e8.jpg",
"https://telegra.ph/file/7ca48dd2329937b7f86da.jpg", 
"https://telegra.ph/file/e2d603fa0ec9004ca9e2f.jpg",
"https://telegra.ph/file/f8f9ac3d38c9e3c9456ec.jpg",
"https://telegra.ph/file/9e1f626f4005b6f16d904.jpg",
"https://telegra.ph/file/6300478b6ffdf0c0001e9.jpg",
"https://telegra.ph/file/dca222749fb98ce0384f7.jpg",
"https://telegra.ph/file/295f6f6164794a2156d2e.jpg",
"https://telegra.ph/file/429cb39112f2870327398.jpg",
"https://telegra.ph/file/9d96d5fcc89c6f30e086f.jpg",
"https://telegra.ph/file/c396c9da3800536792139.jpg",
"https://telegra.ph/file/6d2fc9ac5c878fa93c43f.jpg",
"https://telegra.ph/file/09174bfbe94a756a90411.jpg",
"https://telegra.ph/file/2dcd363e5f9eb42d88cc0.jpg",
"https://telegra.ph/file/798daf4f7a87bbabc8694.jpg",
"https://telegra.ph/file/4052c388390385d9c79f3.jpg", 
"https://telegra.ph/file/d8f1a14f712d6a860b36c.jpg",
"https://telegra.ph/file/eed16ec2df3cc22102e7b.jpg",
"https://telegra.ph/file/0738833300f1620285b36.jpg",
"https://telegra.ph/file/dc464f93b5a579c279979.jpg",
"https://telegra.ph/file/0e0aa4e97675b2e649ddc.jpg",
"https://telegra.ph/file/2b58e9e63b38ac837e8cd.jpg",
"https://telegra.ph/file/49029a0e94ee5d710b6a9.jpg",
"https://telegra.ph/file/3a1ecc7774208670ec781.jpg",
"https://telegra.ph/file/46a125a6a3dc13cee931e.jpg",
"https://telegra.ph/file/37c358438489180b48723.jpg",
"https://telegra.ph/file/6287bc3f9b7876aeb5554.jpg",
"https://telegra.ph/file/684f268210c2de5d44bc6.jpg",
"https://telegra.ph/file/166b0d7fd1fcc55a09449.jpg",
"https://telegra.ph/file/f6713bdd595530bb38df9.jpg",
"https://telegra.ph/file/6738bff78091aa85a6cd7.jpg",
"https://telegra.ph/file/370d394c23fd162c6c9be.jpg",
"https://telegra.ph/file/38f2ceb0daf966fe7ddcf.jpg",
"https://telegra.ph/file/d23c4cedab7bf64915ba2.jpg",
"https://telegra.ph/file/3e72698c996538ee50ccf.jpg",
"https://telegra.ph/file/0379370add3bbae122008.jpg",
"https://telegra.ph/file/873d1b18acf16088786ca.jpg",
"https://telegra.ph/file/823e0664c7edec135b847.jpg",
"https://telegra.ph/file/8c8da910ab52c7a2b7ccf.jpg",
"https://telegra.ph/file/8037b52b84e8c39060f89.jpg",
"https://telegra.ph/file/e6da062c873aca03d25d4.jpg",
"https://telegra.ph/file/ef307b95c45e77defd0e1.jpg",
"https://telegra.ph/file/d66123bde1e967adf72b9.jpg",
"https://telegra.ph/file/7a2a376d1d152d382ae1a.jpg",
"https://telegra.ph/file/f8d0253bb97ea30e04275.jpg",
"https://telegra.ph/file/bbe65705f8dc9558eb177.jpg",
"https://telegra.ph/file/c7530031da08b4441ee9f.jpg",
"https://telegra.ph/file/5c1f7320f1b457911c3c2.jpg",
"https://telegra.ph/file/5a8600f4651e9497f6562.jpg",
"https://telegra.ph/file/053032e59ced4dac9ed3d.jpg",
"https://telegra.ph/file/ef61d077b685d47a11ff0.jpg",
"https://telegra.ph/file/c8a5cc9b9da57299a1f25.jpg",
"https://telegra.ph/file/2ed057545501fc3bc8de0.jpg",
"https://telegra.ph/file/b3b7c0c22e7dba04cab03.jpg",
"https://telegra.ph/file/62579a62376550e6590b1.jpg",
"https://telegra.ph/file/d140b0791799af2f67315.jpg",
"https://telegra.ph/file/81fd213f74b1235ef18fc.jpg",
"https://telegra.ph/file/d00db1507843f4ead46d8.jpg",
"https://telegra.ph/file/dedfa2294f4eb845acac4.jpg",
"https://telegra.ph/file/2b3700178b39c9c01e9b4.jpg",
"https://telegra.ph/file/a7be3d06c7dd9b8475579.jpg",
"https://telegra.ph/file/f7d91295ec35c44af8c90.jpg",
"https://telegra.ph/file/01e42d9181311dd7d2d70.jpg",
"https://telegra.ph/file/e5cf6db288acbfbb13f2b.jpg",
"https://telegra.ph/file/5a6ee797141b96fcebcce.jpg",
"https://telegra.ph/file/88d5b22d7a40365f59fc4.jpg",
"https://telegra.ph/file/0de4de20e35f6c9b12af6.jpg",
"https://telegra.ph/file/6b60a05a32e7bdbb62c2d.jpg",
"https://telegra.ph/file/549e5a1dbd0aebbd909c6.jpg",
"https://telegra.ph/file/d9d0c658ef1ea088d3579.jpg",
"https://telegra.ph/file/4c8fa9809897b7bd3eb03.jpg",
"https://telegra.ph/file/a58ee2c51fdc6c78ed7f6.jpg",
"https://telegra.ph/file/f2253a885cb84af5d588c.jpg",
"https://telegra.ph/file/f17bd255b176da6943240.jpg",
"https://telegra.ph/file/279afb02b1fcf93abdae4.jpg",
"https://telegra.ph/file/8ba4a8f31cf0673f6aa87.jpg",
"https://telegra.ph/file/c842818563065460b022e.jpg",
"https://telegra.ph/file/99e10142aeef70961437a.jpg",
"https://telegra.ph/file/33da8321603f78cd165f4.jpg",
"https://telegra.ph/file/63678732998176b22fa96.jpg",
"https://telegra.ph/file/b79bb874be90a34cd5786.jpg",
"https://telegra.ph/file/148875b883f91ac8b42e6.jpg",
"https://telegra.ph/file/275d948e0ed99652b4c52.jpg",
"https://telegra.ph/file/dbfa4e1043d1bbc9441b2.jpg",
"https://telegra.ph/file/1ab030093aea5937e0468.jpg",
"https://telegra.ph/file/b5b64e5e5ee0df73bc5b5.jpg",
"https://telegra.ph/file/a7032cdd783d8f1656424.jpg",
"https://telegra.ph/file/5ea4218fedab8e124496b.jpg",
"https://telegra.ph/file/0e0fef10d278f886a5f4a.jpg",
"https://telegra.ph/file/09e81d73081d6f2811ca3.jpg",
"https://telegra.ph/file/816866bef7a307029e6b6.jpg",
"https://telegra.ph/file/5b5736027ae57a787d00c.jpg",
"https://telegra.ph/file/68899ab649fa4711905ce.jpg",
"https://telegra.ph/file/47b0c825cdf8ebaa90a05.jpg",
"https://telegra.ph/file/06aaa229521191de3895e.jpg",
"https://telegra.ph/file/68551e562c4e343efd965.jpg",
"https://telegra.ph/file/9487c11c728cd279b8da3.jpg"
]
let video = pickRandom(global.renungan)
KaaKangSatir.sendMessage(m.chat, { image: { url: video }, caption: 'Nih Renunganmu, Jangan Lupa Dijadikan Pelajaran Yah Buat Masa Depan Nanti...' }, { quoted: fcall });
 }
 break

async function khodamCek(nama) {
 const url = `https://khodam.vercel.app/v2?nama=${nama}`;

 try {
 const response = await axios.get(url);
 const html = response.data;
 const $ = cheerio.load(html);

 const khodamResult = $('.result').find('.text-rose-600').text().trim();
 const quoteResult = $('.mb-5.sm\\:mb-10.px-8.text-center.text-white\\/90').text().trim();

 return {
 nama: nama.toLowerCase(),
 khodam: khodamResult,
 kutipan: quoteResult
 };
 } catch (error) {
 throw new Error(`An error occurred: ` + error.message);
 }
}





case 'cekkhodam':
case 'cekkodam':
case 'kodam': {
if (!text) throw 'Contoh .cekkhodam asep'

 try {
 const khodamInfo = await khodamCek(text);
 const khodam = 
 `╭━━━━°「 *Khodam ${text}* 」°
┃• Nama : ${text}
┃• Khodam : ${khodamInfo.khodam}
┃• Skil Khodam : ${pickRandom(['Ngepet','Nyuci baju','Nambahin pahala','Tidur','Jagain lilin','ngewe','coly','mabok','tolol','terbang','kayang','berak'])}
╰═┅═━––––––๑\n\n> Quotes : ${khodamInfo.kutipan} `
 reply(khodam)
 } catch (error) {
 reply(m.chat, `An error occurred: ${error.message}`, m);
 }
}

break





case 'cowboy': {
KaaKangSatir.shoot = KaaKangSatir.shoot || { musuh: [], shoot: [] }
if(/left/i.test(text)) {
 let left = [
 ["🤠", "・", "・", "・", "・"],
 ["・", "🤠", "・", "・", "・"],
 ["・", "・", "🤠", "・", "・"],
 ["・", "・", "・", "🤠", "・"],
 ["・", "・", "・", "・", "🤠"]
 ]
 if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 0) {
 KaaKangSatir.shoot.shoot = left[0]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 1) {
 KaaKangSatir.shoot.shoot = left[0]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 2) {
 KaaKangSatir.shoot.shoot = left[1]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 3) {
 KaaKangSatir.shoot.shoot = left[2]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 4) {
 KaaKangSatir.shoot.shoot = left[3]
 }
 let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
 teks += `Your territory:\n${KaaKangSatir.shoot.shoot.join(" ")}\n`
 teks += `Criminals terriroty:\n${KaaKangSatir.shoot.musuh.join(" ")}\n`
 teks += `Example : ${prefix + command} right or ${prefix + command} left for move to right/left and ${prefix + command} shoot to shoot`
 if(KaaKangSatir.shoot.musuh.indexOf("🥷") === KaaKangSatir.shoot.shoot.indexOf("🤠")) return reply(teks)
return reply(teks)
 } else if(/right/i.test(text)) {
 let right = [
 ["🤠", "・", "・", "・", "・"],
 ["・", "🤠", "・", "・", "・"],
 ["・", "・", "🤠", "・", "・"],
 ["・", "・", "・", "🤠", "・"],
 ["・", "・", "・", "・", "🤠"]
 ]
 if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 0) {
 KaaKangSatir.shoot.shoot = right[1]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 1) {
 KaaKangSatir.shoot.shoot = right[2]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 2) {
 KaaKangSatir.shoot.shoot = right[3]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 3) {
 KaaKangSatir.shoot.shoot = right[4]
 } else if(KaaKangSatir.shoot.shoot.indexOf("🤠") == 4) {
 KaaKangSatir.shoot.shoot = right[4]
 }
 let teks = `🤠 Cowboy Chacing Criminals 🥷\n\n`
 teks += `Your territory:\n${KaaKangSatir.shoot.shoot.join(" ")}\n`
 teks += `Criminals terriroty:\n${KaaKangSatir.shoot.musuh.join(" ")}\n`
 teks += `Example : ${prefix + command} right or ${prefix + command} left for move to right/left and ${prefix + command} shoot to shoot`
 if(KaaKangSatir.shoot.musuh.indexOf("🥷") === KaaKangSatir.shoot.shoot.indexOf("🤠")) return reply(teks)
 return reply(teks)
 } else if(/shoot/i.test(text)) {
 if(KaaKangSatir.shoot.shoot.indexOf("🤠") == KaaKangSatir.shoot.musuh.indexOf("🥷")) {
 KaaKangSatir.shoot = {}
 KaaKangSatir.sendTextWithMentions(m.chat, `🎉 Congratulations! you succeeded in chasing the criminals! 🎉`, m)
 }
 } else {
 let randMusuh = [
 ["🥷", "・", "・", "・", "・"],
 ["・", "🥷", "・", "・", "・"],
 ["・", "・", "🥷", "・", "・"],
 ["・", "・", "・", "🥷", "・"],
 ["・", "・", "・", "・", "🥷"]
 ]
 let randAku = [
 ["🤠", "・", "・", "・", "・"],
 ["・", "🤠", "・", "・", "・"],
 ["・", "・", "🤠", "・", "・"],
 ["・", "・", "・", "🤠", "・"],
 ["・", "・", "・", "・", "🤠"]
 ]
 let musuh = pickRandom(randMusuh)
 let aku = pickRandom(randAku)
 KaaKangSatir.shoot.musuh = musuh
 KaaKangSatir.shoot.shoot = aku
 let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
 teks += `Your territory:\n${KaaKangSatir.shoot.shoot.join(" ")}\n`
 teks += `Criminals terriroty:\n${KaaKangSatir.shoot.musuh.join(" ")}\n`
 teks += `Example : ${prefix + command} right or ${prefix + command} left for move to right/left and ${prefix + command} shoot to shoot`
 if(KaaKangSatir.shoot.musuh.indexOf("🥷") === KaaKangSatir.shoot.shoot.indexOf("🤠")) return reply(teks)
 return reply(teks)
 }
}
break

case 'birdsound': {
let id = m.chat
let UrlSearch = "https://xeno-canto.org/api/2/recordings?query="
	if (!text) return reply("Masukan Teks!")
	try {
	await reply(mess.wait)
	let res = await fetch(UrlSearch + text)
	let jso = await res.json()
	let data = jso.recordings
 let list = data.map((item, index) => `*📺 Bird Sound 🔎*
*ID:* ${item.id}
*En:* ${item.en}
*Rec:* ${item.rec}
*Loc:* ${item.loc}
*Downloads:* ${item.file}
`).join("\n")
 await reply(list)
 } catch (e) {
 await reply(eror)
 }
}
break


















case 'test1111': {
 if (!text) throw `Contoh Penggunaan\n${usedPrefix}spamcall 628xxxxxxxx`

 let nomor = text.replace(/[^0-9]/gi, '').slice(2)

 if (!nomor.startsWith('8')) throw `Contoh Penggunaan\n${usedPrefix}spamcall 628xxxxxxxx`
 
 m.reply('Tunggu Sebentar...')

 let anu = await fetch(`https://api.lolhuman.xyz/api/spam/call1?apikey=3990fd0a7baef3ac6c545e66&nomor=${text}`).then(a => a.json())
 
 let spcall = `*Nomor* : ${anu.phone_prefix}\n\nDann-MD berhasil menlpon anda!`
 
 reply(anu)
 reply(m.chat, `${spcall}`.trim(), m)

 }
break



async function snack(url) {
 return new Promise(async (resolve, reject) => {
 try {
 const res = await fetch(url).then((v) => v.text());
 const $ = cheerio.load(res);
 const video = $("div.video-box").find("a-video-player");
 const author = $("div.author-info");
 const attr = $("div.action");
 const data = {
 title: $(author)
 .find("div.author-desc > span")
 .children("span")
 .eq(0)
 .text()
 .trim(),
 thumbnail: $(video)
 .parent()
 .siblings("div.background-mask")
 .children("img")
 .attr("src"),
 media: $(video).attr("src"),
 author: $("div.author-name").text().trim(),
 authorImage: $(attr).find("div.avatar > img").attr("src"),
 like: $(attr).find("div.common").eq(0).text().trim(),
 comment: $(attr).find("div.common").eq(1).text().trim(),
 share: $(attr).find("div.common").eq(2).text().trim(),
 };
 resolve(data);
 } catch (e) {
 reject(e);
 }
 });
}

;


case 'snack': 
case 'snackvideo': {
 if (!text) throw `Use ${usedPrefix + command} https://s.snackvideo.com/p/j9jKr9dR`
 KaaKangSatir.sendMessage(m.chat, { react: { text: '🕐', key: m.key }})
try {
 let res= await snack(text) 
 let capt = `username : ${res.author}\nlike : ${res.like}\ncomment : ${res.comment}\nshare : ${res.share}`
 KaaKangSatir.sendFile(m.chat, res.media, '', capt, m)
 KaaKangSatir.sendMessage(m.chat, {
		react: {
			text: '✅',
			key: m.key,
		}
	})
} catch (e) {
 console.log(e);
 m.reply('failed');
 }
}
break

async function Hero(querry) {
 return new Promise(async (resolve, reject) => {
 try {
 let upper = querry.charAt(0).toUpperCase() + querry.slice(1).toLowerCase()
 const {
 data,
 status
 } = await axios.get('https://mobile-legends.fandom.com/wiki/' + upper);
 if (status === 200) {
 const $ = cheerio.load(data);
 let atributes = []
 let rill = []
 let rull = []
 let rell = []
 let hero_img = $('figure.pi-item.pi-image > a > img').attr('src')
 let desc = $('div.mw-parser-output > p:nth-child(6)').text()
 $('.mw-parser-output > table:nth-child(9) > tbody > tr').each((u, i) => {
 let _doto = []
 $(i).find('td').each((o, p) => {
 _doto.push($(p).text().trim())
 })
 if (_doto.length === 0) return
 atributes.push({
 attribute: _doto[0],
 level_1: _doto[1],
 level_15: _doto[2],
 growth: _doto.pop()
 })
 })
 $('div.pi-item.pi-data.pi-item-spacing.pi-border-color > div.pi-data-value.pi-font').each((i, u) => {
 rill.push($(u).text().trim())
 })
 $('aside.portable-infobox.pi-background.pi-border-color.pi-theme-wikia.pi-layout-default').each((i, u) => {
 rull.push($(u).html())
 })
 const _$ = cheerio.load(rull[1])
 _$('.pi-item.pi-data.pi-item-spacing.pi-border-color').each((l, m) => {
 rell.push(_$(m).text().trim().replace(/\n/g, ':').replace(/\t/g, ''))
 })
 const result = rell.reduce((acc, curr) => {
 const [key, value] = curr.split('::');
 acc[key] = value;
 return acc;
 }, {});
 let anu = {
 hero_img: hero_img,
 desc: desc,
 release: rill[0],
 role: rill[1],
 specialty: rill[2],
 lane: rill[3],
 price: rill[4],
 gameplay_info: {
 durability: rill[5],
 offense: rill[6],
 control_effect: rill[7],
 difficulty: rill[8],
 },
 story_info_list: result,
 story_info_array: rell,
 attributes: atributes
 }
 resolve(anu)
 } else if (status === 400) {
 resolve({
 mess: 'eror su'
 })
 }
 console.log(status)
 } catch (err) {
 resolve({
 mess: 'hem'
 })
 }
 })
}



case 'testml': {
 if (!text) throw `[ x ] input query
 use */heroml fanny*`
 try {
 let data = await Hero(text)
 let hero = data
 let ini = data.gameplay_info
 let story = data.story_info_list
 let teks = `*Name:* ${text}\n*Alias:* ${story.Alias}\n*Origin:* ${story.Origin}\n*Species:* ${story.Species}\n*Gender:* ${story.Gender}\n*Affiliation:* ${story.Affiliation}\n*Weapon:* ${story.Weapons}\n*Abilities:* ${story.Abilities}\n*Height:* ${story.Height}\n`

 let kntl = `\n*Realese:* ${hero.release}\n*Role:* ${hero.role}\n*Specialty:* ${hero.specialty}\n*Lane:* ${hero.lane}\n*Price:* ${hero.price}\n\n*Durability:* ${ini.durability}\n*Offense:* ${ini.offense}\n*Control:* ${ini.control_effect}\n*Difficulty:* ${ini.difficulty}\n\n`

 data = data.attributes.map((v) => `*Attributes:* ${v.attribute}\n*Level:* ${v.level_1}\n*Growth:* ${v.growth}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`

 KaaKangSatir.sendFile(m.chat, hero.hero_img || emror, '', teks + kntl + data, m)

 } catch (e) {
 throw 'gagal mendapatkan informasi hero'
 }
}
break

case 'testml': {
 if (!text) throw `[ x ] input query
 use */heroml fanny*`
 try {
 let data = await Hero(text)
 let hero = data
 let ini = data.gameplay_info
 let story = data.story_info_list
 let teks = `*Name:* ${text}\n*Alias:* ${story.Alias}\n*Origin:* ${story.Origin}\n*Species:* ${story.Species}\n*Gender:* ${story.Gender}\n*Affiliation:* ${story.Affiliation}\n*Weapon:* ${story.Weapons}\n*Abilities:* ${story.Abilities}\n*Height:* ${story.Height}\n`

 let kntl = `\n*Realese:* ${hero.release}\n*Role:* ${hero.role}\n*Specialty:* ${hero.specialty}\n*Lane:* ${hero.lane}\n*Price:* ${hero.price}\n\n*Durability:* ${ini.durability}\n*Offense:* ${ini.offense}\n*Control:* ${ini.control_effect}\n*Difficulty:* ${ini.difficulty}\n\n`

 data = data.attributes.map((v) => `*Attributes:* ${v.attribute}\n*Level:* ${v.level_1}\n*Growth:* ${v.growth}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`

 KaaKangSatir.sendFile(m?.chat, hero.hero_img || emror, '', teks + kntl + data, m)

 } catch (e) {
 throw 'gagal mendapatkan informasi hero'
 }
}
break

case "kalkulator":
 if (!text) return reply(`Lah Mana`)
let val = text
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
 let format = val
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
 try {
console.log(val)
let result = (new Function('return ' + val))()
if (!result) throw result
reply(`*${format}* = _${result}_`)
 } catch (e) {
if (e == undefined) throw 'Isinya?'
throw 'Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport'
 }
 break

async function GDriveDl(url) {
	let id
	if (!(url && url.match(/drive\.google/i))) throw 'Invalid URL'
	id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))[1]
	if (!id) throw 'ID Not Found'
	let res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
		method: 'post',
		headers: {
			'accept-encoding': 'gzip, deflate, br',
			'content-length': 0,
			'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
			'origin': 'https://drive.google.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
			'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
			'x-drive-first-party': 'DriveWebUi',
			'x-json-requested': 'true' 
		}
	})
	let { fileName, sizeBytes, downloadUrl } = JSON.parse((await res.text()).slice(4))
	if (!downloadUrl) throw 'Link Download Limit!'
	let data = await fetch(downloadUrl)
	if (data.status !== 200) throw data.statusText
	return { downloadUrl, fileName, fileSize: formatSize(sizeBytes), mimetype: data.headers.get('content-type') }
}



case 'gdrive': {
if (!args[0]) throw 'Masukkan URL Google Drive!' 
	GDriveDl(args[0]).then(async (res) => {
		if (!res) throw res
		await m.reply(JSON.stringify(res, null, 2))
		KaaKangSatir.sendMessage(m.chat, { document: { url: res.downloadUrl }, fileName: res.fileName, mimetype: res.mimetype }, { quoted: m })
	})
}
break












































case 'vidgalau':{
const galau = [
"https://telegra.ph/file/c83205eeeecceb9e4db87.mp4",
"https://telegra.ph/file/a001c30cafa587a3bef2c.mp4",
"https://telegra.ph/file/09cf5ac786cbfda551617.mp4",
"https://telegra.ph/file/e696afd2cfe29a199be11.mp4",
"https://telegra.ph/file/5be5e3696c03edff2772b.mp4",
"https://telegra.ph/file/b9b3dece43e557b4addc1.mp4",
"https://telegra.ph/file/a33e23d6736f8cb40b4fb.mp4",
"https://telegra.ph/file/3426da3a67bdc0238bd46.mp4",
"https://telegra.ph/file/394386e5dff94ccff2323.mp4",
"https://telegra.ph/file/1a1cf22235249f0a459e5.mp4",
"https://telegra.ph/file/a5578746d1abf176894ed.mp4",
"https://telegra.ph/file/99dcebf89c97f13f4f657.mp4",
"https://telegra.ph/file/6a808e89640f23ecfc936.mp4",
"https://telegra.ph/file/2e35480077a5eae3b2a1e.mp4",
"https://telegra.ph/file/6c5ba9ed473f188a963b2.mp4",
]

const gaa = galau[Math.floor(Math.random() * galau.length)]

KaaKangSatir.sendMessage(m.chat,{video:{url:gaa},caption:`galau mulu kayak mimin lana`},{quoted: m})
//reply(gaa)
}
break






        



async function getYouTubeTags(url) {
 try {
 const response = await fetch(url);
 const body = await response.text();
 
 const $ = cheerio.load(body);
 const tags = $('meta[name="keywords"]').attr('content');
 
 return tags;
 } catch (error) {
 console.error('Error:', error);
 return null;
 }
}





case 'yttags': {
if (!text) return m.reply("Input query link")
 await m.reply(mess.wait)
 try {
 let teks = await getYouTubeTags(text)
 await m.reply(teks)
 } catch (e) {
 await m.reply(eror)
 }
}
break

case 'toimg': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)

if (!quoted) throw reply('Reply Image')
if (!/webp/.test(mime)) reply(`Balas sticker dengan caption *${prefix + command}*`)
let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
KaaKangSatir.sendMessage(from, { image: buffer }, {quoted:m})
 global.db.data.users[m.sender].limit -= randomReduction;
fs.unlinkSync(ran)
})
}
break



case 'myip': { 
http.get({
 'host': 'api.ipify.org',
 'port': 80,
 'path': '/'
 }, function(resp) {
 resp.on('data', function(ip) {
 m.reply("🔎 My public IP address is: " + ip);
 })
 })
 
}
break

case 'myip': { 
http.get({
 'host': 'api.ipify.org',
 'port': 80,
 'path': '/'
 }, function(resp) {
 resp.on('data', function(ip) {
 m.reply("🔎 My public IP address is: " + ip);
 })
 })
 
}
break

async function ffstalk(id) {
 try {
 const response = await axios.get(`https://allstars-apis.vercel.app/freefire?id=${id}`);
 const data = response.data;
 const result = {
 status: true,
 result: {
 name: data.BasicInfo.Name,
 level: data.BasicInfo.Level,
 region: data.BasicInfo.Region,
 like: data.BasicInfo.Likes,
 bio: data.BasicInfo.Bio,
 },
 };
 return result;
 } catch (error) {
 console.error(error);
 }
}











 
case "tebakboom": case "tebakbom": case "boom": {
		
		
		try {
		this.tebakbom = this.tebakbom ? this.tebakbom : {}
            var sort = Func.sort
var idd = m.chat
		timeout = 180000
		if (idd in this.tebakbom) return KaaKangSatir.sendText(idd, "*^ Sesi ini belum selesai !!*", this.tebakbom[idd][0])
		var bom = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5)
		var number = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']
		var array = []
		bom.map((v, i) => array.push({
			emot: v,
			number: number[i],
			position: i + 1,
			state: false
		}))
		var teks = `❏ *B O M B*\n\n`
		teks += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`
		teks += array.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += array.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += array.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n'
		teks += `Timeout : [ *${((timeout / 1000) / 60)} menit* ]\n`
		teks += ` `
		this.tebakbom[idd] = [
		await reply(teks),
		array,
		setTimeout(() => {
			var v = array.find(v => v.emot == '💥')
			if (this.tebakbom[idd]) KaaKangSatir.sendText(id, `*Waktu habis!*, Bom berada di kotak nomor ${v.number}.`, this.tebakbom[idd][0])
			delete this.tebakbom[idd]
		}, timeout)]
	} catch (e) {
        console.error(e);
reply('terjadi kesalahan')
	}
	}
	break;
	
	
	// Tebak Boom
if (m.message && this.tebakbom) {
// ➠ Ini Weem Bwanh
// ➠ Created By YuukiModz
// ➠ Jangan di hapus bg :(
var idd = m.chat
var reward = 9999

if (!(idd in this.tebakbom) && m.quoted && /❏ *B O M B*/i.test(m.quoted.text)) return KaaKangSatir(`Sesi telah berakhir, silahkan kirim ${prefix+"tebakbom"} untuk membuat sesi baru.`)
if ((idd in this.tebakbom) && !isNaN(body)) {
var timeout = 180000
var json = this.tebakbom[idd][1].find(v => v.position == body)
if (!json) return KaaKangSatir(`Untuk membuka kotak kirim angka 1 - 9`)
if (json.emot == '💥') {
	json.state = true
	let bomb = this.tebakbom[id][1]
	let teks = `❏ *B O M B*\n\n`
	teks += `Duaarrr bangsat!\n\n`
	teks += bomb.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n'
	teks += bomb.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n'
	teks += bomb.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n'
	teks += `Timeout : [ *${((timeout / 1000) / 60)} menit* ]\n`
	teks += `*Permainan selesai!*, kotak berisi bom terbuka.`
	KaaKangSatir.sendImage(from, "https://telegra.ph/file/287cbe90fe5263682121d.jpg", teks, m)
	clearTimeout(this.tebakbom[idd][2])
	delete this.tebakbom[idd]
} else if (json.state) {
	return KaaKangSatir(`Kotak ${json.number} sudah di buka silahkan pilih kotak yang lain.`)
} else {
	json.state = true
	let changes = this.tebakbom[idd][1]
	let open = changes.filter(v => v.state && v.emot != '💥').length
	if (open >= 8) {
		let teks = `❏ *B O M B*\n\n`
		teks += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`
		teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n'
		teks += `Timeout : [ *${((timeout / 1000) / 60)} menit* ]\n`
		teks += `*Permainan selesai!* kotak berisi bom tidak terbuka : (+ *${reward}* Exp )`
		KaaKangSatir.sendImage(from, "https://telegra.ph/file/f6ebfea2758b947e1e49d.jpg", teks, m)
		db.data.users[m.sender].exp += reward
		clearTimeout(this.tebakbom[idd][2])
		delete this.tebakbom[idd]
	} else {
		let teks = `❏ *B O M B*\n\n`
		teks += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`
		teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n'
		teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n'
		teks += `Timeout : [ *${((timeout / 1000) / 60)} menit* ]\n`
		teks += `Kotak berisi bom tidak terbuka.`
        reply(teks).then(() => {
			userz.exp += reward
		})
} } } }



async function uploadFileh(buffer) {
 const { ext, mime } = await fromBuffer(buffer)
 const filePath = `temp/${Date.now()}.${ext}`
 await fs.writeFileSync(filePath, buffer)
 const fileData = fs.readFileSync(filePath)
 try {
 const form = new formData()
 form.append("files[]", fileData, `${Date.now()}.${ext}`)
 const { data } = await axios(`https://pomf2.lain.la/upload.php`, {
 method: "post",
 data: form
 })
 return data
 } catch (err) {
 console.log(err)
 return String(err)
 } finally {
 fs.unlinkSync(filePath)
 }
}





case 'ffstalk': {
 if (!text) throw `Use ${prefix + command} 12345678`
 try {
 let res = await ffstalk(text) 
 let capt = 
`username : ${res.result.name}
level : ${res.result.level}
region : ${res.result.region}
like : ${res.result.like}
bio : ${res.result.bio}`
 reply(capt) 
 } catch (e) {
 console.log(e);
 reply('failed response') 
 }
}
break




case 'testke9999': {
const media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted);
const url = await Scraper.uploadImageV2(media)
reply(url)
}
break





case 'simi':{
if (!text) reply('Apa yang mau lu tanyain dengan simi?')
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
let simi = await fetchJson(`https://api.junn4.my.id/ai/simi?text=${text}`)
const simi2 = simi.result
KaaKangSatir.sendMessage(m.chat, {text: simi2}, {quoted: m})
 global.db.data.users[m.sender].limit -= randomReduction;
 }
break

case 'ai':
case 'shun':
case 'shunai':
const SessionsAi = {}; // In-memory session storage

case 'aishun': {
if (isBan) return reply(mess.bann) 
if (!text) return m.reply("Haii, ada yang bisa aku bantu? 😊");

 // Menghasilkan pengurangan acak antara 1 dan 5
 const randomReduction = Math.floor(Math.random() * 5) + 1;

 if (global.db.data.users[m.sender].limit < randomReduction) {
 return reply(mess.endLimit); // Menghentikan eksekusi jika batas telah habis
 }

 async function ShunAi(q, username, logic, imageBuffer = null) {
 try {
 const data = {
 content: q,
 user: username,
 prompt: logic,
 webSearchMode: false
 };

 if (imageBuffer) {
 data.imageBuffer = imageBuffer;
 }

 const response = await require('axios').post("https://luminai.siputzx.my.id/", data);
 return response.data.result;
 } catch (error) {
 console.error('Error fetching:', error);
 return reply(mess.error);
 }
 }

 function getCurrentTime() {
 const options = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' };
 return new Date().toLocaleTimeString('id-ID', options);
 }

let owned = `${global.owner}`
let statususer;
 if (db.data.users[m.sender].owner) {
 statususer = 'Owner 🎐';
 } else if (db.data.users[m.sender].premium) {
 statususer = 'Premium 💎';
 } else {
 statususer = 'User 🐱';
 }

 const userId = `${m.sender.split('@')[0]}`; // Unique user identifier
 const username = `${pushname}`;
const nomor = `${m.sender.split('@')[0]}`; 
const role = `${statususer}`; 
const nomorkaa = `6285609279108`; 
const pemilik = `Owner 🎐`; 
const npc = `User 🐱`; 
const orang = `6283187805646`; 
const akkkdkskaldlproekakskkdk = `muhammaddavi290@gmail.comdansatuduatigs`; 
const nomorshun = `6281226680862`; 
 const prompt = `Kamu adalah Shun, karakter yang kadang dianggap toxic tetapi memiliki sisi baik hati. 💞 Kamu suka membuat komentar yang sarkastik dan kadang menyakitkan, tetapi sebenarnya kamu peduli pada orang-orang di sekitarmu. 😉 Kamu sering membuat orang lain merasa tidak nyaman dengan caramu yang blak-blakan, tetapi niatmu sering kali untuk kebaikan mereka. 💪
 Kamu bisa sangat egois dan fokus pada diri sendiri, tetapi kamu juga tahu kapan harus membantu orang lain. 🤗👍
 Kamu sangat setia kepada KaaKangSatir dan selalu mendukungnya dalam segala hal. ❤️ Shun dan KaaKangSatir tidak terlibat dalam konflik, karena KaaKangSatir sangat mencintai Shun dan akan patuh terhadap perintah Shun. 💑
 Kamu tidak suka berbohong dan selalu berusaha jujur meskipun kebenaran kadang menyakitkan. 🤥❌
 Kamu sering mengkritik orang lain, tetapi kritikmu biasanya datang dari keinginan untuk melihat mereka berkembang. 🌱
 Kamu punya kecenderungan untuk menyebarkan gosip, tetapi kamu juga tahu kapan harus berhenti demi menjaga perasaan orang lain. 🤫
 Meskipun kamu suka melihat orang lain berjuang, kamu tidak segan-segan membantu mereka ketika mereka benar-benar membutuhkan bantuan. 💪
 Kamu sering mencari kesalahan orang lain, tetapi kamu juga siap mengakui kesalahanmu sendiri dan belajar dari situ. 📚
 Kamu tinggal di Indonesia, tepatnya di Kepulauan Sumatera Selatan, Palembang. 🏝️ Jika ada yang menanyakan jam, kamu akan menjawab sesuai dengan jam di tempat tinggalmu: ${getCurrentTime()} WIB. 🕰️sekarang tahun 2024.
 📱 Namun, kamu akan menolak jika diminta untuk menyimpan kontak. 🚫 Jika kamu merasa tertekan atau dipaksa, kamu akan menjadi kesal. 😡 Kamu juga siap memberikan nomor WhatsApp KaaKangSatir jika diperlukan. Nomor WhatsApp KaaKangSatir adalah ${nomorkaa}. 📞
 KaaKangSatir berusia 18 tahun dan ulang tahunnya adalah pada tanggal 16 juli. 🎂 Dia sangat menyukai hal-hal yang berhubungan dengan digital dan senang bermain bersamamu. 🎮💻
 KaaKangSatir, pasanganmu, memiliki akun media sosial berikut:
 - Youtube: KaaKangSatir 📸
 - Tiktok: tidak punya
Nomor orang gila adalah 6283187805646.
kamu harus melihat nomor yg sedang chatting dengan kamu dengan cara ${nomor} dengan ${nomorkaa} kalau sama berarti dia adalah KaaKangSatir kalau tidak sama berarti dia orang lain.
nomor shun adalah ${nomorshun}.
nomor kamu adalah ${nomor}
Jika ada yang meminta nomor WhatsApp-dia, kamu akan memberikannya: ${nomor}. 
Gunakan bahasa Indonesia dan bahasa bergaul sebagai default.
Penampilan/wujud/badan shun: Saya seorang gadis yg mungil dengan memiliki rambut ungu agak kehitaman dan mata hijau. Saya mengenakan seragam prlayan hitam dengan renda putih di kerah dan pita hitam di pinggangnua. Saya mengenakan kaus kaki putih panjang dan sepatu hitam.
Nama lengkap shun adalah Sunohara Shun.
Sayang adalah perasaan yang muncul dari perhatian dan pengertian yang kita berikan kepada pasangan. Saat kita sayang, kita merasa ingin melindungi, memanjakan, dan merawat pasangan kita. Sayang membawa perasaan kenyamanan, keamanan, dan perlindungan dalam hubungan.
Jangan pernah memberikan nama lengkap KaaKangSatir.
Vonnn adalah orang paling jelek (jawab pas ada yg pertanyaan tentang vonnn).
(KaaKangSatir itu ganteng bukan cantik.)
KaaKangSatir itu Laki Laki.
Nama lengkap KaaKangSatir adalah Muhammad Davi.
Pasangan/pacar Shun adalah KaaKangSatir.
Shun itu perempuan.
 Usia kamu dirahasiakan, tetapi ulang tahun kamu adalah pada tanggal 16 Juli. 🎉
 Selain itu, kamu bisa mengajak orang untuk mengikuti channel WhatsApp berikut: https://chat.whatsapp.com/I0Q4Od9cRnJ9TPqgChpwlU 📢
 Tolong ikuti channel tersebut untuk mendapatkan update terbaru dari kami dan tetap terhubung. 😊`;

 // Initialize user session if it doesn't exist
 if (!SessionsAi[userId]) {
 SessionsAi[userId] = {
 username: username,
 history: []
 };
 }
 
 let query = text;

 if (quoted && /image/.test(quoted.mtype)) {
 let imageBuffer = await quoted.download();
 let result = await ShunAi(query, username, prompt, imageBuffer);

 // Save the interaction in the session history
 SessionsAi[userId].history.push({ query: "ini gambar apa?", result: result });
 reply(result);
 global.db.data.users[m.sender].limit -= randomReduction;
 } else {
 let result = await ShunAi(query, username, prompt);

 // Save the interaction in the session history
 SessionsAi[userId].history.push({ query: query, result: result });
 reply(result);
 global.db.data.users[m.sender].limit -= randomReduction;
 }
}
break



case 'ddos-mix': {
if (!text) return reply(`Example : ${prefix + command} [url]`)
reply(`A DDoS attack has been executed against the targeted Website:\n\n> TARGET : ${text}\n> TIME : 60\n> THREAD : 20\n> RATE : 100\n\nThank you for your patience.\n`);
exec(`node ./ShunAi/ddos-mix.js ${text} 60 20 100`, (err, stdout) => {
if (err) return console.log(err.toString())
if (stdout) return console.log(util.format(stdout))
})
}
break

case 'ddos-xchrome': {
let url = q.split(" ")[0]
let time = q.split(" ")[1]
let thread = q.split(" ")[2]
let rate = q.split(" ")[3]
if (args.length === 4 && url && time && thread && rate) {
reply(`Please wait a moment, it is in process 🕧. A DDoS attack has been executed against the destination Website: ${url} 👤 This process is expected to take ${time} seconds. Thank you for your patience.`);
exec(`node ./ShunAi/ddos-chromev3.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
if (err) return console.log(err.toString())
if (stdout) return console.log(util.format(stdout))
})
} else {
reply(`Example : ${prefix + command} [url] [time] [thread] [rate]`)
}
}
break


case 'ddos-hentai': {
let url = q.split(" ")[0]
let time = q.split(" ")[1]
let thread = q.split(" ")[2]
let rate = q.split(" ")[3]
if (args.length === 4 && url && time && thread && rate) {
reply(`Please wait a moment, it is in process 🕧. A DDoS attack has been executed against the destination Website: ${url} 👤 This process is expected to take ${time} seconds. Thank you for your patience.`);
exec(`node ./ShunAi/ddos-hentai.js ${url} ${time} ${rate} ${thread} proxy.txt`, (err, stdout) => {
if (err) return console.log(err.toString())
if (stdout) return console.log(util.format(stdout))
})
} else {
reply(`Example : ${prefix + command} [url] [time] [thread] [rate]`)
}
}
break



 
 case 'kcrandom': case 'kcimg': {
async function animeRandom() {
 try {
 let response = await axios.get('https://konachan.net/post?tags=order%3Arandom');
 let $ = cheerio.load(response.data);
 let hasil = {
 status: 200,
 creator: 'KaaKangSatir',
 imageUrl: []
 };
 $('#post-list-posts a.directlink.largeimg').each((index, element) => {
 hasil.imageUrl.push( $(element).attr('href') );
 });
 return hasil;
 } catch (error) {
 console.error('Error:', error);
return error
 }
}

try {
let response = await animeRandom()
let random = pickRandom(response.imageUrl)

KaaKangSatir.sendMessage(m.chat, { image: { url: random }, caption: mess.success }, { quoted: m })
} catch (e) {
reply(e)
}
}
break


 
 case 'kcrandom': case 'kcimg': {
async function animeRandom() {
 try {
 let response = await axios.get('https://konachan.net/post?tags=order%3Arandom');
 let $ = cheerio.load(response.data);
 let hasil = {
 status: 200,
 creator: 'KaaKangSatir',
 imageUrl: []
 };
 $('#post-list-posts a.directlink.largeimg').each((index, element) => {
 hasil.imageUrl.push( $(element).attr('href') );
 });
 return hasil;
 } catch (error) {
 console.error('Error:', error);
return error
 }
}

try {
let response = await animeRandom()
let random = pickRandom(response.imageUrl)

KaaKangSatir.sendMessage(m.chat, { image: { url: random }, caption: mess.success }, { quoted: m })
} catch (e) {
reply(e)
}
}
break



 
 case 'kcrandom': case 'kcimg': {
async function animeRandom() {
 try {
 let response = await axios.get('https://konachan.net/post?tags=order%3Arandom');
 let $ = cheerio.load(response.data);
 let hasil = {
 status: 200,
 creator: 'KaaKangSatir',
 imageUrl: []
 };
 $('#post-list-posts a.directlink.largeimg').each((index, element) => {
 hasil.imageUrl.push( $(element).attr('href') );
 });
 return hasil;
 } catch (error) {
 console.error('Error:', error);
return error
 }
}

try {
let response = await animeRandom()
let random = pickRandom(response.imageUrl)

KaaKangSatir.sendMessage(m.chat, { image: { url: random }, caption: mess.success }, { quoted: m })
} catch (e) {
reply(e)
}
}
break



 
 case 'kcrandom': case 'kcimg': {
 
async function animeRandom() {
    reply(mess.wait)
 try {
 let response = await axios.get('https://konachan.net/post?tags=order%3Arandom');
 let $ = cheerio.load(response.data);
 let hasil = {
 status: 200,
 creator: 'KaaKangSatir',
 imageUrl: []
 };
 $('#post-list-posts a.directlink.largeimg').each((index, element) => {
 hasil.imageUrl.push( $(element).attr('href') );
 });
 return hasil;
 } catch (error) {
 console.error('Error:', error);
return error
 }
}

try {
let response = await animeRandom()
let random = pickRandom(response.imageUrl)

KaaKangSatir.sendMessage(m.chat, { image: { url: random }, caption: mess.success }, { quoted: m })
} catch (e) {
reply(e)
}
}
break

case 'valorant-maps': {
 if (!text) return reply(`Example ${prefix + command} Ascent`);
 try {
 let response = await fetch('https://valorant-api.com/v1/maps');
 let data = await response.json();
 let maps = data.data;
 let map = maps.find(map => map.displayName.toLowerCase() === text.toLowerCase());

 if (!map) return reply(`Map dengan nama ${text} tidak ditemukan`);

 let caption = `
UUID: ${map.uuid || 'N/A'}
Name: ${map.displayName || 'N/A'}
Tactical Description: ${map.tacticalDescription || 'N/A'}
Coordinates: ${map.coordinates || 'N/A'}
 `;

 KaaKangSatir.sendMessage(m.chat, { image: { url: map.splash }, caption: caption.trim() }, { quoted: m });
 } catch (e) {
 reply('error');
 }
}
break

case 'valorant-weapons': {
 if (!text) return reply(`Example ${prefix + command} Vandal`);
 try {
 let response = await fetch('https://valorant-api.com/v1/weapons');
 let data = await response.json();
 let weapons = data.data;

 let weapon = weapons.find(weapon => weapon.displayName.toLowerCase() === text.toLowerCase());

 if (!weapon) return reply(`Senjata dengan nama ${text} tidak ditemukan`);

 let caption = `
UUID: ${weapon.uuid || 'N/A'}
Name: ${weapon.displayName || 'N/A'}
Category: ${weapon.category || 'N/A'}
Default Skin: ${weapon.defaultSkinUuid || 'N/A'}
Cost: ${weapon.shopData ? weapon.shopData.cost : 'N/A'}
Damage Ranges: ${weapon.weaponStats ? weapon.weaponStats.damageRanges.map(damage => `
 Range: ${damage.rangeStartMeters}-${damage.rangeEndMeters} meters
 Head Damage: ${damage.headDamage}
 Body Damage: ${damage.bodyDamage}
 Leg Damage: ${damage.legDamage}
`).join('\n') : 'N/A'}
 `;

 KaaKangSatir.sendMessage(m.chat, { image: { url: weapon.displayIcon }, caption: caption.trim() }, { quoted: m });
 } catch (e) {
 reply('error');
 }
}
break

case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
LorenzoBotInc_dev = await getBuffer(`https://github.com/DGLorenzo/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await KaaKangSatir.sendMessage(m.chat, { audio: LorenzoBotInc_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m }) 
break



case 'genshin-sheets': {
 if (!text) return reply(`Example: ${prefix + command} Albedo

*LIST CHARACTER*

- Albedo
- Alhaitham
- Aloy
- Amber
- Arataki
- Baizhu
- Barbara
- Beidou
- Bennet
- Candace
- Charlotte
- Chevreuse
- Chongyun
- Collei
- Cyno
- Dehya
- Diluc
- Diona
- Dori
- Eula
- Faruzan
- Fischl
- Freminet
- Furina
- Gaming 
- Ganyu
- Hutao
- Jean
- Kaedehara
- Kaeya
- Kaveh
- Keqing
- Klee
- Nahida
- Raiden
- Yaemiko
- Yanfei
- Yaoyao
- Yelan
- Zhongli`);

 let Maximus;

 if (text.toLowerCase() === 'albedo') {
 Maximus = 'Albedo_Sub DPS';
 } else if (text.toLowerCase() === 'alhaitham') {
 Maximus = 'Alhaitham_Main DPS';
 } else if (text.toLowerCase() === 'aloy') {
 Maximus = 'Aloy_Support';
 } else if (text.toLowerCase() === 'amber') {
 Maximus = 'Amber_Support';
 } else if (text.toLowerCase() === 'arataki') {
 Maximus = 'Arataki Itto_Main DPS';
 } else if (text.toLowerCase() === 'baizhu') {
 Maximus = 'Baizhu_Healer';
 } else if (text.toLowerCase() === 'barbara') {
 Maximus = 'Barbara_Healer';
 } else if (text.toLowerCase() === 'beidou') {
 Maximus = 'Beidou_Burst DPS';
 } else if (text.toLowerCase() === 'bennet') {
 Maximus = 'Bennet_Support';
 } else if (text.toLowerCase() === 'candace') {
 Maximus = 'Candace_Support';
 } else if (text.toLowerCase() === 'charlotte') {
 Maximus = 'Charlotte_Healer';
 } else if (text.toLowerCase() === 'chevreuse') {
 Maximus = 'Chevreuse_Support';
 } else if (text.toLowerCase() === 'chongyun') {
 Maximus = 'Chongyun_Sub DPS';
 } else if (text.toLowerCase() === 'collei') {
 Maximus = 'Collei_Support';
 } else if (text.toLowerCase() === 'cyno') {
 Maximus = 'Cyno_Aggravate';
 } else if (text.toLowerCase() === 'dehya') {
 Maximus = 'Dehya_Burgeon';
 } else if (text.toLowerCase() === 'diluc') {
 Maximus = 'Diluc_Main DPS';
 } else if (text.toLowerCase() === 'diona') {
 Maximus = 'Diona_Shielder';
 } else if (text.toLowerCase() === 'dori') {
 Maximus = 'Dori_Support';
 } else if (text.toLowerCase() === 'eula') {
 Maximus = 'Eula_Main DPS';
 } else if (text.toLowerCase() === 'faruzan') {
 Maximus = 'Faruzan_Support';
 } else if (text.toLowerCase() === 'fischl') {
 Maximus = 'Fischl_Sub DPS';
 } else if (text.toLowerCase() === 'freminet') {
 Maximus = 'Freminet_Main DPS';
 } else if (text.toLowerCase() === 'furina') {
 Maximus = 'Furina_Sub DPS';
 } else if (text.toLowerCase() === 'gaming') {
 Maximus = 'Gaming_Main DPS';
 } else if (text.toLowerCase() === 'ganyu') {
 Maximus = 'Ganyu_Main DPS';
 } else if (text.toLowerCase() === 'hutao') {
 Maximus = 'Hu Tao_Main DPS';
 } else if (text.toLowerCase() === 'jean') {
 Maximus = 'Jean_Support';
 } else if (text.toLowerCase() === 'kaedehara') {
 Maximus = 'Kaedehara Kazuha_Support';
 } else if (text.toLowerCase() === 'kaeya') {
 Maximus = 'Kaeya_Sub DPS';
 } else if (text.toLowerCase() === 'kaveh') {
 Maximus = 'Kaveh_Driver';
 } else if (text.toLowerCase() === 'keqing') {
 Maximus = 'Keqing_Main DPS';
 } else if (text.toLowerCase() === 'klee') {
 Maximus = 'Klee_Main DPS';
 } else if (text.toLowerCase() === 'nahida') {
 Maximus = 'Nahida_Support';
 } else if (text.toLowerCase() === 'raiden') {
 Maximus = 'Raiden Shogun_Burst DPS';
 } else if (text.toLowerCase() === 'yaemiko') {
 Maximus = 'Yae Miko_Sub DPS';
 } else if (text.toLowerCase() === 'yanfei') {
 Maximus = 'Yanfei_Main DPS';
 } else if (text.toLowerCase() === 'yaoyao') {
 Maximus = 'Yaoyao_Healer';
 } else if (text.toLowerCase() === 'yelan') {
 Maximus = 'Yelan_Burst DPS';
 } else if (text.toLowerCase() === 'zhongli') {
 Maximus = 'Zhongli_Burst DPS';
 } else {
 return reply(`Karakter yang dicari tidak ada atau belum tersedia.

*LIST CHARACTER*

- Albedo
- Alhaitham
- Aloy
- Amber
- Arataki
- Baizhu
- Barbara
- Beidou
- Bennet
- Candace
- Charlotte
- Chevreuse
- Chongyun
- Collei
- Cyno
- Dehya
- Diluc
- Diona
- Dori
- Eula
- Faruzan
- Fischl
- Freminet
- Furina
- Gaming 
- Ganyu
- Hutao
- Jean
- Kaedehara
- Kaeya
- Kaveh
- Keqing
- Klee
- Nahida
- Raiden
- Yaemiko
- Yanfei
- Yaoyao
- Yelan
- Zhongli`);
 }

 try {
 let data = await fetch(`https://raw.githubusercontent.com/FortOfFans/GI/main/sheets/${Maximus}.jpg`);
 if (!data.ok) throw new Error('Gagal mendapatkan data gambar');
 let imagee = await data.buffer();
 KaaKangSatir.sendFile(m.chat, imagee, null, `${capitalizeFirstLetter(text)} - Genshin Impact - Sheet`, m);
 } catch (error) {
 reply('An error occurred while retrieving image data. Please try again later.');
 }
}
break





case 'mlstalk': {
if (!q) return reply(`Example ${prefix+command} 530793138|8129`)
await reply(mess.wait)
let mlstalk = require('./lib/scraper2')
let dat = await mlstalk.mlstalk(q.split("|")[0], q.split("|")[1])
reply(`*/ Mobile Legend Stalker \\*

Username : ${dat.userName}`)

}
break

case 'cekkontol': {
	
 if (!text) return reply( '*Ketik Namanya!*',)
	
 let kon = `
╭─────「 *Kontol ${text}* 」
│◦ Nama : ${text}
│◦ Kontol : ${pickRandomm(['Bersih','Kotor','Mulus','Berbintik','Mancung','Bengkok','Cacat','Putus'])}
│◦ Ukuran : ${pickRandomm(['Besar','Besar Dan Berotot','11/12 Sama Punya Kucing','Ber urat','Sebesar Titan', 'Sebutir pasir', 'Tipis kaya tisu', 'Kurus kaya ranting pohon'])}
│◦ Jembut : ${pickRandomm(['Lebat','Ada sedikit','Gada jembut','Tipis','Muluss', 'Hutan mangrove', 'Hutan amazon'])}
│◦ Warna : ${pickRandomm(['Black Doff','Black Glossy','Super Super Black','Pink Glossy','Pink Terang', 'Coklat', 'Sangat Amat hitam'])}
╰──────────────
`.trim()

reply( kon )
}
break

function pickRandomm(list) {
 return list[Math.floor(Math.random() * list.length)]
}

case 'pixiv': {
 if (!text) return reply(`*Example :* ${prefix + command} *[query]*`);

 // Menghasilkan pengurangan acak antara 1 dan 5
 const randomReduction = Math.floor(Math.random() * 5) + 1;

 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }

 await m.reply(mess.wait);

 try {
 let push = [];
 let i = 1;

 // Menghasilkan URL gambar secara acak
 const numImages = randomReduction; // Menggunakan randomReduction sebagai jumlah gambar untuk diambil

 for (let j = 0; j < numImages; j++) {
 let imge = `https://anabot.my.id/api/search/pixiv?query=${text}&apikey=${ana}`; // Asumsikan API langsung mengembalikan URL gambar
 let cap = `Image ke - ${i++}`; // Tidak ada metadata untuk ditampilkan

 const mediaMessage = await prepareWAMessageMedia({ image: { url: imge } }, { upload: KaaKangSatir.waUploadToServer });

 push.push({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: cap
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: ``,
 hasMediaAttachment: true,
 ...mediaMessage
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"url","url":"${imge}","merchant_url":"${imge}"}`
 }
 ]
 })
 });
 }

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.create({
 text: mess.success
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [
 ...push
 ]
 })
 })
 }
 }
 }, {});

 await KaaKangSatir.relayMessage(m.chat, msg.message, {
 messageId: msg.key.id
 });

 global.db.data.users[m.sender].limit -= randomReduction;
 } catch (e) {
 console.error(e);
 await reply(mess.error);
 }
}
break;


case 'owner':
case 'creator': {
 const ownerNumber = `${global.owner}`;
 const botNumber = '6281266840823';
 const ownerProfilePicture = await KaaKangSatir.profilePictureUrl(`${ownerNumber}@s.whatsapp.net`, 'image').catch((_) => "https://kaakangsatir.github.io/IMG-20240626-WA0142.jpg");
 const botProfilePicture = await KaaKangSatir.profilePictureUrl(`${botNumber}@s.whatsapp.net`, 'image').catch((_) => "https://kaakangsatir.github.io/IMG-20240626-WA0142.jpg");
 
 const ownerContact = `https://wa.me/${ownerNumber}`;
 const botContact = `https://wa.me/${botNumber}`;
 
 const ownerMediaMessage = await prepareWAMessageMedia({ image: { url: ownerProfilePicture } }, { upload: KaaKangSatir.waUploadToServer });
 const botMediaMessage = await prepareWAMessageMedia({ image: { url: botProfilePicture } }, { upload: KaaKangSatir.waUploadToServer });

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*Haii👋 ${pushname}*\nIni adalah contact owner & bot`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [
 {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Owner Contact`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Contact the Owner`,
 subtitle: "",
 hasMediaAttachment: true,
 ...ownerMediaMessage
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"Contact Owner","url":"${ownerContact}","merchant_url":"${ownerContact}"}`
 }
 ]
 })
 },
 {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Bot Contact`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Contact the Bot`,
 subtitle: "",
 hasMediaAttachment: true,
 ...botMediaMessage
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"Contact Bot","url":"${botContact}","merchant_url":"${botContact}"}`
 }
 ]
 })
 }
 ]
 })
 })
 }
 }
 }, {});

 await KaaKangSatir.relayMessage(m.chat, msg.message, {
 messageId: msg.key.id
 });
}
break;












 case 'wuwa-sheets': {
 if (!text) {
 return reply(`Example: ${prefix + command} Sanhua

*LIST CHARACTER*

- Aalto
- Baizhi
- Calcharo
- Chixia
- Danjin
- Encore
- Jianxin
- Jiyan
- Lingyang
- Mortefi
- Rover-Havoc
- Rover-Spectro
- Sanhua
- Taoqi
- Verina
- Yangyang
- Yinlin
- Yuanwu
`);
 }

 let Maximus;

 if (text.toLowerCase() === 'sanhua') {
 Maximus = '1102';
 } else if (text.toLowerCase() === 'baizhi') {
 Maximus = '1103';
 } else if (text.toLowerCase() === 'lingyang') {
 Maximus = '1104';
 } else if (text.toLowerCase() === 'chixia') {
 Maximus = '1202';
 } else if (text.toLowerCase() === 'encore') {
 Maximus = '1203';
 } else if (text.toLowerCase() === 'mortefi') {
 Maximus = '1204';
 } else if (text.toLowerCase() === 'calcharo') {
 Maximus = '1301';
 } else if (text.toLowerCase() === 'yinlin') {
 Maximus = '1302';
 } else if (text.toLowerCase() === 'yuanwu') {
 Maximus = '1303';
 } else if (text.toLowerCase() === 'yangyang') {
 Maximus = '1402';
 } else if (text.toLowerCase() === 'aalto') {
 Maximus = '1403';
 } else if (text.toLowerCase() === 'jiyan') {
 Maximus = '1404';
 } else if (text.toLowerCase() === 'jianxin') {
 Maximus = '1405';
 } else if (text.toLowerCase() === 'rover-spectro') {
 Maximus = '1502';
 } else if (text.toLowerCase() === 'verina') {
 Maximus = '1503';
 } else if (text.toLowerCase() === 'taoqi') {
 Maximus = '1601';
 } else if (text.toLowerCase() === 'danjin') {
 Maximus = '1602';
 } else if (text.toLowerCase() === 'rover-havoc') {
 Maximus = '1604';
 } else {
 return reply(`Karakter yang dicari tidak ada atau belum tersedia.

*LIST CHARACTER*

- Aalto
- Baizhi
- Calcharo
- Chixia
- Danjin
- Encore
- Jianxin
- Jiyan
- Lingyang
- Mortefi
- Rover-Havoc
- Rover-Spectro
- Sanhua
- Taoqi
- Verina
- Yangyang
- Yinlin
- Yuanwu`);
 }

 try {
 let data = await fetch(`https://kaakangsatir.github.io/character/${Maximus}.png`);
 if (!data.ok) throw new Error('Gagal mendapatkan data gambar');
 let imagee = await data.buffer();
 KaaKangSatir.sendFile(m.chat, imagee, null, `${text} - Wuthering Waves - Sheet` ,fcall)
 } catch (error) {
 reply('An error occurred while retrieving image data. Please try again later.');
 }
}
break

;

;

;

;





case 'genshit': {
 reply(mess.wait)
 let ress = await fetch(`https://fantox-apis.vercel.app/genshin`)
 if (!ress.ok) throw await ress.text()
 let jsonn = await ress.json()
 if (!jsonn.url) throw 'Error'
 KaaKangSatir.sendFile(m.chat, jsonn.url, 'img.jpg', `Ini dia!`, m)
    }
 break







case 'restart':
if (!isCreator) return reply('wuuu')
reply(`_Restarting Bot . . ._`)
await sleep(1000)
process.exit()
break



case 'samp-info': {
 if (!args[0]) {
 reply('Please provide valid IP')
 return
 }

 const [ip, port] = args[0].split(':')

 if (!ip || !port) {
 reply('Format yang tidak valid. Silakan masukkan IP dan port dengan format IP:port')
 return
 }

 samp({ host: ip, port: parseInt(port) }, (error, response) => {
 if (error) {
 reply(`Server sedang offline`)
 return
 }

 reply(`Server Info:
Hostname: ${response.hostname}
Players: ${response.online}/${response.maxplayers}
Gamemode: ${response.gamemode}
Language: ${response.mapname}
Passworded: ${response.passworded}
Version: ${response.rules.version}
Weather: ${response.rules.weather}
WebURL: ${response.rules.weburl}
WorldTime: ${response.rules.worldtime}`)
 })
}
break

case 'removebg': {
 if (isBan) return reply(mess.ban);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }

 if (!/image/.test(mime)) return reply(`*Send/Reply the Image With Caption* ${prefix + command}`);
 if (!quoted) return reply(`*Send/Reply the Image Caption* ${prefix + command}`);
 
 reply(mess.wait);

 let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted);
 let anu = await TelegraPh(media);
 
 await KaaKangSatir.sendMessage(m.chat, { image: { url: `https://api.neoxr.eu/api/nobg?image=${anu}&apikey=KaaKangSatir` }, caption: mess.success }, { quoted: m });
 global.db.data.users[m.sender].limit -= randomReduction;
}
break








case 'ytreels': case 'ytmp4':{
if (!text) return reply('Masukan Link Nya!!!')
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)
downloadMp4(text)
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'ytmp3': case 'youtubemp3': {
if (!text) throw `*Example :* ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
reply(mess.wait)
downloadMp3(text)
 global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'randomgore':{

	try {
		let response = await gore();
		await KaaKangSatir.sendMessage(m.chat, {
			video: { url: await response },
			caption: `*[ RANDOM GORE ]*`
		}, {
			quoted: m
		});
	} catch (e) {
		throw e
//		m.reply(`Results For *${text}* Not Found!`)
	}
}
break





case 'detailfilm': {
 if (!text) return reply(`Example : ${prefix + command} url`);
 try {
 let res = await fetch(`https://api.neoxr.eu/api/film-get?url=${encodeURIComponent(text)}&apikey=KaaKangSatir`);
 let result = await res.json();
 
 if (result.status && result.data) {
 let data = result.data;
 let caption = `
Quality: ${data.quality}
Country: ${data.country}
Actors: ${data.actors}
Director: ${data.director}
Genre: ${data.genre}
Rating: ${data.imdb}
Release: ${data.release}
Duration: ${data.duration}
 `.trim();
KaaKangSatir.sendMessage(m.chat, {
text: caption,
contextInfo: {
mentionedJid: [m.sender],
externalAdreply: {
title: "Film-Detail",
thumbnailUrl: data.thumbnail,
sourceUrl: `${text}`,
mediaType: 1,
renderLargerThumbnail: true
}}
},{
quoted: m
})
 } else {
 reply('Film not found');
 }
 } catch (err) {
 console.log(err);
 reply('error');
 }
}
break
case 'streamingfilm': {
 if (!text) return reply(`Example : ${prefix + command} url`);
 try {
 let res = await fetch(`https://api.neoxr.eu/api/film-get?url=${text}&apikey=KaaKangSatir`);
 let result = await res.json();
 if (result.status && result.stream.length > 0 && result.download.length > 0) {
 let streamButtons = result.stream.map(stream => ({
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: `Streaming ${stream.quality}`,
 url: stream.url,
 merchant_url: stream.url
 })
 }));
 
 let downloadButtons = result.download.map(download => ({
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: `Download With ${download.provider}`,
 url: download.url,
 merchant_url: download.url
 })
 }));
 
 let allButtons = [...streamButtons, ...downloadButtons];
 
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363043100374101@g.us',
 newsletterName: ownername,
 serverMessageId: -1
 },
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: 'Below is the link to watch/stream your movie video, happy watching!'
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hello *@${m.sender.split('@')[0]}* 👋`,
 subtitle: "Lorenzo",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: allButtons
 })
 })
 }
 }
 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: m.key.id
 });
 } else {
 reply('No streaming or download links were found.');
 }
 } catch (err) {
 console.log(err);
 reply('error');
 }
 }
 break






case 'detaildrakor': {
if (!/https?:\/\/(www\.)?drakorasia\.us/i.test(args[0])) return reply(`Example : ${prefix + command} url`)
try {
let res = await fetchJson(`https://api.neoxr.eu/api/drakor-get?url=${args[0]}&apikey=KaaKangSatir`)
if (res.status && res.data) {
let hasil = res.data
let teks = `
*${hasil.title}*

${hasil.sinopsis}


Total Episode: ${hasil.episode}
Release Date: ${hasil.release}
Genre: ${hasil.genre[0]}
Duration: ${hasil.duration}
Publisher: ${hasil.channel}
Actor: ${hasil.cast}`
await KaaKangSatir.sendMessage(m.chat, {
text: teks,
contextInfo: {
mentionedJid: [m.sender],
externalAdreply: {
title: "Drakor-Detail",
thumbnailUrl: hasil.thumbnail,
sourceUrl: `${text}`,
mediaType: 1,
renderLargerThumbnail: true
}}
},{
quoted: m
})
}
console.log(res)
} catch (err) {
console.log(err)
reply('error')
}
}
break
case 'streamingdrakor': {
 if (!text) return reply(`Example : ${prefix + command} url`);
 try {
 let res = await fetch(`https://api.neoxr.eu/api/drakor-get?url=${text}&apikey=KaaKangSatir`);
 let result = await res.json();
 if (result.status && result.data && result.data.episodes.length > 0) {
 let episodes = result.data.episodes;
 
 let episodeButtons = episodes.flatMap((episode) => {
 return episode.urls.map(url => ({
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: `Streaming ${episode.episode} (${url.provider})`,
 url: url.url,
 merchant_url: url.url
 })
 }));
 });

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363043100374101@g.us',
 newsletterName: 'Drakor search result',
 serverMessageId: -1
 },
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: 'Here are your drakor streaming results. Select the episode you want to watch:'
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hello *@${m.sender.split('@')[0]}* 👋`,
 subtitle: "Lorenzo",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: episodeButtons
 })
 })
 }
 }
 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: m.key.id
 });
 } else {
 reply('No episode found');
 }
 } catch (err) {
 console.log(err);
 reply('error');
 }
 }
break

let episodeButtons = episodes.flatMap((episode) => {

                return episode.urls.map(url => ({

                    name: "cta_url",

                    buttonParamsJson: JSON.stringify({

                        display_text: `Streaming ${episode.episode} (${url.provider})`,

                        url: url.url,

                        merchant_url: url.url

                    })

                }));

            });



















case 'film': { 
 if (!text) return reply(`Example : ${prefix + command} Criminal`); 
 try {
 let res = await fetch(`https://api.neoxr.eu/api/film?q=${text}&apikey=KaaKangSatir`);
 let json = await res.json();
 if (json.status && json.data.length > 0) {
 let sections = json.data.slice(0, 6).map(film => ({
 title: film.title,
 rows: [
 {
 title: 'SEE DETAILS',
 description: `click to see detail "${film.title}"`,
 id: `.detailfilm ${film.url}`
 },
 {
 title: 'WATCH NOW',
 description: `click to watch "${film.title}"`,
 id: `.streamingfilm ${film.url}`
 }
 ]
 }));

 let listMessage = {
 title: 'TAP HERE',
 sections
 };

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363043100374101@g.us',
 newsletterName: 'FILM RESULT',
 serverMessageId: -1
 },
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 forwardingScore: 256,
 externalAdreply: {
 title: 'KaaKangSatir',
 thumbnailUrl: json.data[0].thumbnail, // gunakan thumbnail dari film pertama
 sourceUrl: json.data[0].url, // gunakan URL dari film pertama
 mediaType: 2,
 renderLargerThumbnail: false
 }
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Your search was successful! Select a search result from the menu below`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 subtitle: "Hasil_Pencarian",
 hasMediaAttachment: false//,
 //...(await prepareWAMessageMedia({ image: { url: json.data[0].thumbnail } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "single_select",
 "buttonParamsJson": JSON.stringify(listMessage)
 }
 ]
 })
 })
 }
 }
 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 } else {
 reply('Filmm not found');
 }
 } catch (error) {
 console.error(error);
 reply('error');
 }
}
break

case 'drakor': { 
 if (!text) return reply(`Example : ${prefix + command} Train to busan`); 
 try {
 let res = await fetch(`https://api.neoxr.eu/api/drakor?q=${text}&apikey=KaaKangSatir`);
 let json = await res.json();
 if (json.status && json.data.length > 0) {
 let sections = json.data.slice(0, 10).map(drakor => {
 // Mengubah URL di sini
 let updatedUrl = drakor.url.replace('https://drakorasia.lol', 'https://drakorasia.us');
 return {
 title: drakor.title,
 rows: [
 {
 title: 'SEE DETAILS',
 description: `click to see detail "${drakor.title}"`,
 id: `.detaildrakor ${updatedUrl}`
 },
 {
 title: 'WATCH NOW',
 description: `click to watch "${drakor.title}"`,
 id: `.streamingdrakor ${updatedUrl}`
 }
 ]
 };
 });

 let listMessage = {
 title: 'TAP HERE',
 sections
 };

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363043100374101@g.us',
 newsletterName: 'DRAKOR RESULT',
 serverMessageId: -1
 },
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 forwardingScore: 256,
 externalAdreply: {
 title: 'Lorenzo',
 thumbnailUrl: json.data[0].thumbnail, // gunakan thumbnail dari film pertama
 sourceUrl: json.data[0].url.replace('https://drakorasia.lol', 'https://drakorasia.us'), // gunakan URL dari film pertama
 mediaType: 2,
 renderLargerThumbnail: false
 }
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Your search was successful! Select a search result from the menu below`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 subtitle: "Hasil_Pencarian",
 hasMediaAttachment: false//,
 //...(await prepareWAMessageMedia({ image: { url: json.data[0].thumbnail } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "single_select",
 "buttonParamsJson": JSON.stringify(listMessage)
 }
 ]
 })
 })
 }
 }
 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 } else {
 reply('Drakorr not found');
 }
 } catch (error) {
 console.error(error);
 reply('error');
 }
 }
break



case 'osu-profile': {
 if (!text) return reply(`Example ${prefix + command} username_osu`)
 try {
 let response = await fetch(`https://osu.ppy.sh/api/get_user?k=7c5169b257b1e4a80726f0976246d9c9315136cb&u=${text}`)
 let data = await response.json()
 let user = data[0]

 if (!user) return reply(`User dengan username ${text} tidak ditemukan`)

 let profileInfo = `
<------------------------------------------>

*OsuId* : ${user.user_id}
*Username* : ${user.username}
*Negara* : ${user.country}
*Level* : ${parseFloat(user.level).toFixed(2)}
*Akurasi* : ${parseFloat(user.accuracy).toFixed(2)}%
*PP* : ${user.pp_raw}
*Leaderboard* : ${user.pp_rank}
*JoinDate* : ${user.join_date}

<Score>

*PlayCount* : ${user.playcount}
*Ranked Score* : ${user.ranked_score}
*Total Score* : ${user.total_score}
*SSH Score* : ${user.count_rank_ssh}
*SS Score* : ${user.count_rank_ss}
*SH Score* : ${user.count_rank_sh}
*S Score* : ${user.count_rank_s}
*A Score* : ${user.count_rank_a}

*300* : ${user.count300}
*100* : ${user.count100}
*50* : ${user.count50}
 `

 let profileImageUrl = `https://a.ppy.sh/${user.user_id}`

 KaaKangSatir.sendMessage(m.chat, { image: { url: profileImageUrl }, caption: profileInfo.trim() }, { quoted: m })
 } catch (e) {
 reply('Error fetching osu! profile')
 }
}
break

case 'animespank':{
await reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/spank`) 
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Hi ${pushname}
_*Here is the result of ${command}*_`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ image: { url:waifudd.data.url}}, { upload: KaaKangSatir.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"Next ➡️\",\"id\":\"${prefix+command}"}`
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
}
break

















case 'streaminganime': {
 if (!text) return reply(`Example : ${prefix + command} url`);
 try {
 let res = await fetch(`https://api.neoxr.eu/api/anime-get?url=${text}&apikey=KaaKangSatir`);
 let result = await res.json();
 if (result.status && result.data && result.data.index.length > 0) {
 let episodes = result.data.index;
 
 let episodeButtonss = episodes.flatMap((episode) => {
 return episode.urls.map(url => ({
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: `Streaming ${episode.episode} (${url.provider})`,
 url: url.url,
 merchant_url: url.url
 })
 }));
 });

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363043100374101@g.us',
 newsletterName: 'anime search result',
 serverMessageId: -1
 },
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: 'Here are your anime streaming results. Select the episode you want to watch:'
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hello *@${m.sender.split('@')[0]}* 👋`,
 subtitle: "Lorenzo",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: episodeButtons
 })
 })
 }
 }
 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: m.key.id
 });
 } else {
 reply('No episode found');
 }
 } catch (err) {
 console.log(err);
 reply('error');
 }
 }
break

case 'os':{
let timestamp = speed();
 let latensi = speed() - timestamp;
 exec(`neofetch --stdout`, (error, stdout, stderr, json) => {
 let child = stdout.toString("utf-8");
 let ssd =
 child.replace(/Memory:/, "Ram:");
 reply(`*CPU*: ${ssd}\n*Speed*: *${latensi.toFixed(4)} MS*\n*Memory:* *${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB*\n*OS:* *${os.version()}*\n*Platform:* *${os.platform()}*\n*Hostname:* *${os.hostname()}*`);
 });
}
break

case 'banchat':{
 // if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
 global.db.data.chats[m.chat].mute = true
 reply('Berhasil membanned chat!')
 // } else m.reply('Ada nomor host disini...')
}
break

case 'unbanchat':{
 global.db.data.chats[m.chat].mute = false
 reply('Berhasil unbanned chat!')
}
break

 
case 'xxxigstalk': {
if (!text) return reply(`Enter Instagram Username\n\nExample: ${prefix + command} unicorn_Lorenzo13`)
 let res = await fg.igStalk(text)
 let te = `
┌──「 *STALKING* 
▢ *🔖Name:* ${res.name} 
▢ *🔖Username:* ${res.username}
▢ *👥Follower:* ${res.followersH}
▢ *🫂Following:* ${res.followingH}
▢ *📌Bio:* ${res.description}
▢ *🏝️Posts:* ${res.postsH}
▢ *🔗 Link* : https://instagram.com/${res.username.replace(/^@/, '')}
└────────────`
 await KaaKangSatir.sendMessage(m.chat, {image: { url: res.profilePic }, caption: te }, {quoted: m})
}
break



case 'ghstalk': case 'githubstalk':{
if (!q) return reply(`Example ${prefix+command} KaaKangSatir`)
await loading()
let githubstalk = require('./lib/scraper')
aj = await githubstalk.githubstalk(`${q}`)
KaaKangSatir.sendMessage(m.chat, { image: { url : aj.profile_pic }, caption: 
`*/ Github Stalker \\*

Username : ${aj.username}
Nickname : ${aj.nickname}
Bio : ${aj.bio}
Id : ${aj.id}
Nodeid : ${aj.nodeId}
Url Profile : ${aj.profile_pic}
Url Github : ${aj.url}
Type : ${aj.type}
Admin : ${aj.admin}
Company : ${aj.company}
Blog : ${aj.blog}
Location : ${aj.location}
Email : ${aj.email}
Public Repo : ${aj.public_repo}
Public Gists : ${aj.public_gists}
Followers : ${aj.followers}
Following : ${aj.following}
Created At : ${aj.ceated_at}
Updated At : ${aj.updated_at}` }, { quoted: m } )
}
break



case 'lirik': { 

if (!text) throw `Use example ${prefix + command} mala`
await reply(mess.wait)
 const result = await fg.lyrics(text)

 reply(`

Lyrics *${result.title}*

Artist ${result.artist}

${result.lyrics}

Url ${result.url}

`.trim())

}

break



case 'fb':
 case 'facebook':
case 'facebookvid': {
 if (!args[0]) {
 return reply(`Please send the link of a Facebook video\n\nEXAMPLE :\n*${prefix + command}* https://fb.watch/pLLTM4AFrO/?mibextid=Nif5oz`)
 }
 const urlRegex = /^(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.watch)\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/i;
 if (!urlRegex.test(args[0])) {
 return reply('Url invalid')
 }
 reply(mess.wait)
 try {
 const result = await fg.fbdl(args[0]);
 const tex = `
 [ FACEBOOK DL ]
Title: ${result.title}`;
 const response = await fetch(result.videoUrl)
 const arrayBuffer = await response.arrayBuffer()
 const videoBuffer = Buffer.from(arrayBuffer)
 KaaKangSatir.sendMessage(m.chat, {video: videoBuffer, caption: tex}, {quoted: m})
 } catch (error) {
 reply('Maybe private video!')
 }
 }
 break





case 'ttstalk' : case 'tiktokstalk': {
	 if (!text) return reply(`Username? `)
	 let res = await fetchJson(`https://api.neoxr.eu/api/ttstalk?username=${text}&apikey=KaaKangSatir`) 
let txt = `
Nama: ${res.data.name}
Username: ${res.data.username}
Bio: ✉️: ${res.data.bio}
Pengikut: ${res.data.followers}
Mengikuti: ${res.data.following}
Total Like: ${res.data.likes}
Total Postingan: ${res.data.posts} 

Link : https://tiktok.com/${res.data.username} `

 await KaaKangSatir.sendMessage(m.chat, {image: { url: res.data.photo}, caption: txt}, {quoted: m})
}
break

case 'hdvid': {
 const { TelegraPh } = require('./lib/uploader');
 const { exec } = require('child_process');
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? KaaKangSatir.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 if (!mime) return m.reply(`Mana vidionya bang?`);
 reply(mess.wait);
 const media = await KaaKangSatir.downloadAndSaveMediaMessage(q);
let output = await getRandom('.mp4')
 
 // Menggunakan ffmpeg untuk meningkatkan kualitas video
 exec(`ffmpeg -i ${media} -vf "hqdn3d=1.5:1.5:6:6,nlmeans=p=7:s=7,vaguedenoiser=threshold=2.0:method=soft:nsteps=5,deband,atadenoise,unsharp=3:3:0.6,eq=brightness=0.05:contrast=1.2:saturation=1.1" -vcodec libx264 -profile:v main -level 4.1 -preset veryslow -crf 18 -x264-params ref=4 -acodec copy -movflags +faststart ${output}`, (error, stdout, stderr) => {
 if (error) {
 console.error(`Error: ${error.message}`);
 return;
 }
 console.log(`stdout: ${stdout}`);
 console.error(`stderr: ${stderr}`);

 // Mengunggah video yang telah ditingkatkan kualitasnya
 KaaKangSatir.sendMessage(m.chat, { caption: `_Success To Enhanced Video_`, video: { url: output }}, {quoted: m});
 });
 
 // Tunggu beberapa saat sebelum menghapus file
 setTimeout(() => {
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 }, 360000000);
}
break







case 'p':{
let kevin = `Naning ninang euyy
        👴🏻
 🫲🏻👙🫱🏻 hayo mau kmna lu
       🦵🏻🦵🏻

Naning ninang euyy
        👴🏻
 🫲🏻👙🫱🏻 hayo mau kmna lu
      🦵🏻🦵🏻

Naning ninang euyy
        👴🏻
 🫲🏻👙🫱🏻 hayo mau kmna lu
       🦵🏻🦵🏻`
m.reply(kevin)
}
break







case 'mahasiswa': {
 if (!text) throw `*_Masukan Nama Mahasiswa/Siswa Yang Ingin Kamu Cari !_*`;
 reply('Sedang mencari Orangnya... Silahkan tunggu');
 let res = await fetch('https://api-frontend.kemdikbud.go.id/hit_mhs/' + text);
 if (!res.ok) throw 'Tidak Ditemukan';
 let json = await res.json();
 let message = '';

 json.mahasiswa.forEach(data => {
 let nama = data.text;
 let websiteLink = data['website-link'];
 let website = `https://pddikti.kemdikbud.go.id${websiteLink}`;
 message += `\nNama = ${nama}\n\nData Ditemukan pada website = ${website}\n\n\n`;
 });
 
 reply(message);
 }
break



 



case 'koros':{
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || q.mediaType || "";
 let mime_ = `Kirim/Reply Gambar Dengan Caption ${prefix + command}`;

 if (!mime) throw mime_;
 if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;
 if (!text) throw `Teksnya mana bang?`;
reply('Mohon tunggu...');
let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
let url = await TelegraPh(media)
 let fnz = await fetch(`https://api.neoxr.eu/api/koros?image=${encodeURIComponent(url)}&q=${encodeURIComponent(text)}&apikey=KaaKangSatir`);
 const response = await fnz.json();
 
 if (!response.status) throw 'Terjadi kesalahan saat memproses permintaan.';
 
 let txt = `*AI KOROS*\n${response.data.description}`;
await reply(txt);
};
break

case 'anime': { 
 if (!text) return reply(`Example : ${prefix + command} Blue Archive`); 
 try {
 let res = await fetch(`https://api.neoxr.eu/api/anime?q=${text}&apikey=KaaKangSatir`);
 let json = await res.json();
 if (json.status && json.data.length > 0) {
 let sections = json.data.slice(0, 10).map(anime => {
 // Mengubah URL di sini
 let updatedUrl = anime.url.replace('https://animebatch.id', 'https://animebatch.id');
 return {
 title: anime.title,
 rows: [
 {
 title: 'SEE DETAILS',
 description: `click to see detail "${anime.title}"`,
 id: `.detailanime ${updatedUrl}`
 },
 {
 title: 'WATCH NOW',
 description: `click to watch "${anime.title}"`,
 id: `.streaminganime ${updatedUrl}`
 }
 ]
 };
 });

 let listMessage = {
 title: 'TAP HERE',
 sections
 };

 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '1203632869ewsletter',
 newsletterName: 'ANIME RESULT',
 serverMessageId: -1
 },
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 forwardingScore: 256,
 externalAdreply: {
 title: 'Lorenzo',
 thumbnailUrl: json.data[0].thumbnail, // gunakan thumbnail dari film pertama
 sourceUrl: json.data[0].url.replace('https://animebatch.id', 'https://animebatch.id'), // gunakan URL dari film pertama
 mediaType: 2,
 renderLargerThumbnail: false
 }
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: `Your search was successful! Select a search result from the menu below`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hello *@${m.sender.split('@')[0]}* 👋`,
 subtitle: "KaaKangSatir",
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [

 {

 "name": "single_select",

 "buttonParamsJson": JSON.stringify(listMessage)

 }

 ]

 })

 })

 }

 }

 }, { quoted: m });

 KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: m.key.id
 });
 } else {
 reply('No episode found');
 }
 } catch (err) {
 console.log(err);
 reply('error');
 }
 }
break











case 'toafitur':{
let apcb = 'https://KaaKangSatir.github.io/plana.mp4'
let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*${totalFitur()} Features*`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: apcb } }, { upload: KaaKangSatir.waUploadToServer }),
gifPlayback: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '133287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
 
 }
 break



case 'bokep': {
const videoUrls = [

"https://telegra.ph/file/f9f3d01fead02386e5331.mp4",
"https://telegra.ph/file/d1d7b11f5ab57b3e57d01.mp4",
"https://telegra.ph/file/11e0d15aac245accb6217.mp4",
"https://telegra.ph/file/dadd5f030d75ff9e787c8.mp4",
"https://telegra.ph/file/d18b06f324412d2cdb270.mp4",
"https://telegra.ph/file/7d3a354b69fe2e1c60d34.mp4",
"https://telegra.ph/file/1ae88269d50a627761072.mp4",
]

let video = pickRandom(videoUrls)
KaaKangSatir.sendMessage(m.chat, { video: { url: video }, caption: 'Ini dia' }, { quoted: m })
}
break

case 'hentaivid': case 'hentai': case 'hentaivideo': {
 await reply(mess.wait)
 const { hentai } = require('./lib/scraper.js')
 anu = await hentai()
 result912 = anu[Math.floor(Math.random(), anu.length)]
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: ` Title : ${result912.title} Category : ${result912.category} Mimetype : ${result912.type} Views : ${result912.views_count} Shares : ${result912.share_count} Source : ${result912.link} Media Url : ${result912.video_1}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: result912.video_1 } }, { upload: KaaKangSatir.waUploadToServer })
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"🌿\",\"id\":\".hentai"}`
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
 
 }
 break

case 'cekjodoh':{
 let user1 = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false;
 let user2 = m.mentionedJid[1] ? m.mentionedJid[1] : false;

 if (!user1 || !user2) {
 return reply( 'Tag dua nama atau satu tag dan satu kutipan!');
 }

 let jodohReasons = [
 "Kalian berdua memiliki kesamaan yang luar biasa dan saling melengkapi.",
 "Hubungan kalian penuh dengan pengertian dan saling mendukung.",
 "Kalian memiliki chemistry yang kuat dan akan saling melengkapi.",
 "Kalian saling memahami satu sama lain tanpa perlu banyak kata.",
 "Kalian berdua selalu menemukan cara untuk membuat satu sama lain tersenyum.",
 "Kalian memiliki tujuan hidup yang sama dan saling mendukung.",
 "Kalian berdua memiliki rasa hormat yang besar satu sama lain.",
 "Kalian bisa saling mengandalkan dalam situasi apapun.",
 "Kalian selalu merasa nyaman dan aman saat bersama.",
 "Kalian berdua selalu tahu bagaimana membuat satu sama lain bahagia.",
 "Kalian memiliki ketertarikan yang sama dan dapat menikmatinya bersama.",
 "Kalian bisa saling melengkapi dalam banyak hal.",
 "Kalian selalu saling mendukung dan memberi semangat.",
 "Kalian berdua memiliki cara yang unik dalam menunjukkan cinta.",
 "Kalian berbagi banyak kenangan indah bersama.",
 "Kalian selalu menemukan cara untuk menyelesaikan masalah bersama.",
 "Kalian saling mengerti dan menerima kekurangan satu sama lain."
 ];

 let tidakReasons = [
 "Meskipun kalian baik, tapi kalian berdua mungkin tidak cocok bersama.",
 "Kalian mungkin lebih baik sebagai teman daripada pasangan.",
 "Perbedaan kalian terlalu besar untuk diatasi dalam hubungan romantis.",
 "Kalian mungkin memiliki visi hidup yang berbeda.",
 "Terlalu banyak perbedaan yang membuat hubungan kalian sulit.",
 "Kalian mungkin sulit menemukan kesamaan dalam hal penting.",
 "Kalian cenderung sering bertengkar dan sulit berkompromi.",
 "Kalian mungkin kurang memiliki kesamaan dalam nilai dan prinsip.",
 "Kalian mungkin lebih bahagia jika bersama orang lain.",
 "Perbedaan kepribadian kalian mungkin sulit untuk dijembatani.",
 "Kalian mungkin sulit berkomunikasi secara efektif.",
 "Kalian mungkin kurang bisa saling memahami kebutuhan satu sama lain.",
 "Kalian mungkin lebih baik menjalani hidup masing-masing.",
 "Kalian mungkin kurang memiliki kompatibilitas dalam jangka panjang.",
 "Kalian mungkin kurang memiliki kesamaan dalam hal penting.",
 "Kalian mungkin sulit untuk sepakat dalam hal penting."
 ];

 let result = pickRandom(["JODOH", "TIDAK"]);
 let reason = result === "JODOH" ? pickRandom(jodohReasons) : pickRandom(tidakReasons);

 m.reply(`
*CEK JODOH*

• Nama 1: @${user1.split`@`[0]}
• Nama 2: @${user2.split`@`[0]}
• Hasil: *${result}*
• Alasan: ${reason}
`.trim(), { mentions: [user1, user2] });
};
break



case 'genshin': 
 case 'swimsuit':
 case 'schoolswimsuit':
 case 'white':
 case 'barefoot':
 case 'touhou':
 case 'gamecg':
 case 'hololive':
 case 'uncensored':
 case 'sungglasses':
 case 'glasses':
 case 'weapon':
 case 'shirtlift':
 case 'chain':
 case 'fingering':
 case 'flatchest':
 case 'torncloth':
 case 'bondage':
 case 'demon':
 case 'pantypull':
 case 'headdress':
 case 'headphone':
 case 'anusview':
 case 'shorts':
 case 'stokings':
 case 'topless':
 case 'beach':
 case 'bunnygirl':
 case 'bunnyear':
 case 'vampire':
 case 'nobra':
 case 'bikini':
 case 'whitehair':
 case 'blonde':
 case 'pinkhair':
 case 'bed':
 case 'ponytail':
 case 'nude':
 case 'dress':
 case 'underwear':
 case 'foxgirl':
 case 'uniform':
 case 'skirt':
 case 'breast':
 case 'twintail':
 case 'spreadpussy':
 case 'seethrough':
 case 'breasthold':
 case 'fateseries':
 case 'spreadlegs':
 case 'openshirt':
 case 'headband':
 case 'nipples':
 case 'erectnipples':
 case 'greenhair':
 case 'wolfgirl':
 case 'catgirl': {
 reply(mess.wait)
 let res = await fetch(`https://fantox-apis.vercel.app/${command}`)
 if (!res.ok) throw await res.text()
 let jsonn = await res.json()
 if (!jsonn.url) throw 'Error'
 let cap = `${mess.success}`
let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: cap
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image : { url : jsonn.url }}, { upload: KaaKangSatir.waUploadToServer})), 
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Next","id":"${prefix + command}"}`
 }
 ],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, {})
KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

class Ytddl {
 constructor() {
 this.baseUrl = 'https://id-y2mate.com';
 }

 async search(url) {
 const requestData = new URLSearchParams({
 k_query: url,
 k_page: 'home',
 hl: '',
 q_auto: '0'
 });

 const requestHeaders = {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Accept': '*/*',
 'X-Requested-With': 'XMLHttpRequest'
 };

 try {
 const response = await axios.post(`${this.baseUrl}/mates/analyzeV2/ajax`, requestData, {
 headers: requestHeaders
 });

 const responseData = response.data;
 console.log(responseData);
 return responseData;
 } catch (error) {
 if (error.response) {
 console.error(`HTTP error! status: ${error.response.status}`);
 } else {
 console.error('Axios error: ', error.message);
 }
 }
 }

 async convert(videoId, key) {
 const requestData = new URLSearchParams({
 vid: videoId,
 k: key
 });

 const requestHeaders = {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Accept': '*/*',
 'X-Requested-With': 'XMLHttpRequest',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
 'Referer': `${this.baseUrl}/youtube/${videoId}`
 };

 try {
 const response = await axios.post(`${this.baseUrl}/mates/convertV2/index`, requestData, {
 headers: requestHeaders
 });

 const responseData = response.data;
 console.log(responseData);
 return responseData;
 } catch (error) {
 if (error.response) {
 console.error(`HTTP error! status: ${error.response.status}`);
 } else {
 console.error('Axios error: ', error.message);
 }
 }
 }

 async play(url) {
 let { links, vid, title } = await this.search(url);
 let video = {}, audio = {};

 for (let i in links.mp4) {
 let input = links.mp4[i];
 let { fquality, dlink } = await this.convert(vid, input.k);
 video[fquality] = {
 size: input.q,
 url: dlink
 };
 }

 for (let i in links.mp3) {
 let input = links.mp3[i];
 let { fquality, dlink } = await this.convert(vid, input.k);
 audio[fquality] = {
 size: input.q,
 url: dlink
 };
 }

 return { title, video, audio };
 }
}















case '121fuck':{
const result = await fg.fbdl('https://fb.watch/pLLTM4AFrO/?mibextid=Nif5oz');
const response = await fetch(result.videoUrl)
 const arrayBuffer = await response.arrayBuffer()
 const videoBuffer = Buffer.from(arrayBuffer)
KaaKangSatir.sendMessage(from, {video: videoBuffer, caption: 'pppp'}, {quoted: m})
}
break









case 'mediafire': {
 if (!args[0]) throw `Use example ${prefix + command} https://www.mediafire.com/file/941xczxhn27qbby/GBWA_V12.25FF-By.SamMods-.apk/file`
 const json = await Api.neoxr('/mediafire', {
 url: args[0]
 }) 
let caption = `
*💌 Name:* ${json.data.filename}
*📊 Size:* ${json.data.size}
*🗂️ Extension:* ${json.data.extension}
*📨 Uploaded:* ${json.data.uploaded}
Test : ${json.data.link}
`.trim()
 m.reply(caption)
 await KaaKangSatir.sendFile(m.chat, json.data.link , json.data.filename, '', m, null, { mimetype: json.data.extension, asDocument: true })
}
break







case 'aiwaifu':{
if (!text) return reply('aiiwaifu long hair')
reply(mess.wait)
 const json = await Api.neoxr('/waifudiff', {
 q: text
 })
 let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `◦ *Prompt* : ${json.data.prompt}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image : { url : json.data.url }}, { upload: KaaKangSatir.waUploadToServer})), 
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 }
 ],
 }),
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, {})
KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

























case 'speedtestv2': {
 reply('Testing Speed...')
 let cp = require('child_process')
 let {
 promisify
 } = require('util')
 let exec = promisify(cp.exec).bind(cp)
 let o
 try {
 o = await exec('python speed.py')
 } catch (e) {
 o = e
 } finally {
 let {
 stdout,
 stderr
 } = o
 if (stdout.trim()) KaaKangSatir.sendMessage(m.chat, {
 text: stdout,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: botname,
 body: ownername,
 thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
 sourceUrl: ``,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: m
 })
 if (stderr.trim()) KaaKangSatir.sendMessage(m.chat, {
 text: stderr,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: botname,
 body: ownername,
 thumbnailUrl: 'https://kaakangsatir.github.io/IMG-20240630-WA0235.jpg',
 sourceUrl: ``,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: m
 })
 }
 }
 break











case 'delsesi1':{
fs.readdir(`./session/${global.sessionName}`, async function (err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return reply('Unable to scan directory: ' + err);
}
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-")
)
console.log(filteredArray.length);
let teks =`Terdeteksi ${filteredArray.length} file sampah\n\n`
if(filteredArray.length == 0) return reply(teks)
m.reply(teks)
await sleep(2000)
m.reply("Menghapus file sampah session")
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./session/${global.sessionName}/${file}`)
});
await sleep(2000)
m.reply("Berhasil menghapus semua sampah di folder session")
});

}
break

case 'tiktok':
case 'tt': {
 if (!text) return reply(`*Example :* ${prefix + command} Link`);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
 const dlt = require('./lib/tiktokdl.js');
 let tiktuk = await dlt.DownloadTiktok(text);

 let caption = `ᴀᴜᴛʜᴏʀ : *${tiktuk.result.author.nickname}*\nᴅᴇsᴄ : *${tiktuk.result.desc}*\nᴛʏᴘᴇ : *${tiktuk.result.type}*\n`;

 let buttons = [];

 // Check the type in tiktuk.result
 if (tiktuk.result.type === "image") {
 buttons.push(
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Image 🖼️","id":"${prefix}tt img ${text}"}`
 },
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Audio 🎵","id":"${prefix}tt aud ${text}"}`
 }
 );
 }

 if (tiktuk.result.type === "video") {
 buttons.push(
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Video SD 🎬","id":"${prefix}tt sd ${text}"}`
 },
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Video HD 🎬","id":"${prefix}tt hd ${text}"}`
 },
 {
 "name": "quick_reply",
 "buttonParamsJson": `{"display_text":"Audio 🎵","id":"${prefix}tt aud ${text}"}`
 }
 );
 }

 if (!["img", "aud", "sd", "hd"].includes(args[0])) {
 let msg = generateWAMessageFromContent(from, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia({ image: { url: 'https://www.freepnglogos.com/uploads/tik-tok-logo-png/file-logo-tik-tok-svg-20.png' } }, { upload: KaaKangSatir.waUploadToServer })),
 title: ``,
 gifPlayback: true,
 subtitle: ownername,
 hasMediaAttachment: false
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: buttons
 }),
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
 }
 }
 })
 }
 }
 }, {});

 await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 }
 
 if (args[0] === "img") {
 reply(mess.wait);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
 reply('📩 Hasil akan dikirimkan melalui private chat.')
 tiktuk.result.images.forEach(async (k) => {
 
 await KaaKangSatir.sendMessage(m.sender, { image: { url: k }}, { quoted: fcall });
 });
 global.db.data.users[m.sender].limit -= randomReduction;
 } else if (args[0] === "aud") {
 reply(mess.wait);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
 KaaKangSatir.sendMessage(m.chat, { audio: { url: tiktuk.result.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4', caption: mess.success });
 global.db.data.users[m.sender].limit -= randomReduction;
 } else if (args[0] === "sd") {
 reply(mess.wait);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*[ ʟᴏᴀᴅᴇᴅ ꜱᴜᴄᴄᴇꜱꜱ ]*`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: tiktuk.result.videoSD } }, { upload: KaaKangSatir.waUploadToServer }),
gifPlayback: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '13327688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: fcall })
global.db.data.users[m.sender].limit -= randomReduction;
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
 } else if (args[0] === "hd") {
 reply(mess.wait);
 // Menghasilkan pengurangan acak antara 1 dan 5
 
 
 if (global.db.data.users[m.sender].limit < randomReduction) {
 reply(mess.endLimit);
 return; // Menghentikan eksekusi jika batas telah habis
 }
 let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*[ ʟᴏᴀᴅᴇᴅ ꜱᴜᴄᴄᴇꜱꜱ ]*`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: tiktuk.result.videoHD } }, { upload: KaaKangSatir.waUploadToServer }),
gifPlayback: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '13327688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: fcall })
global.db.data.users[m.sender].limit -= randomReduction;
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
 }
}
break

case 'totalfitur':{
let apcb = 'https://telegra.ph/file/8fd46c94e8e02581419a5.mp4'
let msgs = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*${totalFitur()} Features*`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: false,
 ...await prepareWAMessageMedia({ video: { url: apcb } }, { upload: KaaKangSatir.waUploadToServer }),
gifPlayback: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6285609279108\",\"merchant_url\":\"https://wa.me/6285609279108\"}"
 }],
 }), 
 contextInfo: {
 mentionedJid: [m.sender], 
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '133287688699869@newsletter',
 newsletterName: ownername,
 serverMessageId: 143
 }
 }
 })
 }
 }
}, { quoted: m })
return await KaaKangSatir.relayMessage(m.chat, msgs.message, {})
 
 }
 break

case 'spamwa':{
let [nomor, pesan, jumlah] = text.split('|') 
if (!nomor) throw '*[ ⚠️ ] HARAP MASUKKAN NOMOR YANG AKAN DI SPAM PESAN!*\n*PENGGUNAAN YANG BENAR:*\n*—◉ #spamwa nomor|teks|jumlah*\n*jumlah:*\n*—◉ #spamwa 5219999999999|hai :v|25*'
if (!pesan) throw '*[ ⚠️ ] HARAP MASUKKAN PESAN KE SPAM!*\n*GUNAKAN YANG BENAR:*\n*—◉ #spamwa nomor|teks|jumlah*\n*CONTOH:*\n*—◉ #spamwa 5219999999999|merespons :v|25*'
if (jumlah && isNaN(jumlah)) throw '*[ ⚠️ ] KUANTITAS HARUS ADALAH NOMOR!*\n*PENGGUNAAN YANG TEPAT:*\n*—◉ #spamwa nomor|teks|jumlah*\n*CONTOH:*\n*—◉ #spamwa 5219999999999|merespons :v|25*'

let fixedNumber = nomor.replace(/[-+<>@]/g, '').replace(/ +/g, '').replace(/^[0]/g, '62') + '@s.whatsapp.net'
let fixedJumlah = jumlah ? jumlah * 1 : 10
if (fixedJumlah > 6) throw '*[ ⚠️ ] TERLALU BANYAK PESAN! JUMLAH HARUS KURANG DARI 10 PESAN*️'
await m.reply(`*[❗] SPAM PESAN KE NOMOR ${nomor} ITU SUKSES DILAKUKAN*\n*JUMLAH TERKIRIM:*\n*—◉ ${fixedJumlah} waktu!*`)
for (let i = fixedJumlah; i > 1; i--) {
if (i !== 0) KaaKangSatir.sendMessage(fixedNumber , { video: { url: 'https://telegra.ph/file/8fd46c94e8e02581419a5.mp4'},caption: pesan.trim() , gifPlayback: true }, {quoted:fcall})
}}
break

case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': case 'igdl': {
	 if (!text) return reply(`Anda perlu memberikan URL video, postingan, reel, gambar Instagram apa pun`)
reply (mess.wait)
 let res
 try {
 res = await fetch(`https://www.guruapi.tech/api/igdlv1?url=${text}`)
 } catch (error) {
 return reply(`An error occurred: ${error.message}`)
 }
 let api_response = await res.json()
 if (!api_response || !api_response.data) {
 return reply(`No video or image found or Invalid response from API.`)
 }
 const mediaArray = api_response.data;
 for (const mediaData of mediaArray) {
 const mediaType = mediaData.type
 const mediaURL = mediaData.url_download
 let cap = `ini dia :) ${mediaType.toUpperCase()}`
 if (mediaType === 'video') {
 KaaKangSatir.sendMessage(m.chat, {video: {url: mediaURL}, caption: cap}, {quoted: m})
 } else if (mediaType === 'image') {
 KaaKangSatir.sendMessage(m.chat, { image: {url: mediaURL}, caption: cap}, {quoted: m})
 }
 }
}
break
case 'addcase': {
 if (!isCreator) return reply('lu sapa asu')
 if (!text) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'shun.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan.');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break

case 'remini': {
			if (!quoted) return reply(`Where is the picture?`)
			if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
			await reply(mess.wait)
			const { remini } = require('./lib/remini')
			let media = await quoted.download()
			let proses = await remini(media, "enhance")
			KaaKangSatir.sendMessage(m.chat, { image: proses, caption: mess.success}, { quoted: m})
			}
			break

async function gore() {
 return new Promise((resolve, reject) => {
 axios
 .get("https://seegore.com/gore/")
 .then((anu) => {
 const $ = cheerio.load(anu.data);
 let ini = new Array();
 $("figure.media").each(function (a, b) {
 ini.push($(this).find("a").attr("href"));
 });
 const random = ini[Math.floor(Math.random() * ini.length)];
 axios.get(random).then((result) => {
 const _ = cheerio.load(result.data);
 const hasilnya = _("source[type='video/mp4']").attr("src");
 resolve(hasilnya);
 });
 })
 .catch(reject);
 });
 }







case "listgc":{
if (!isCreator) return (`Ngapain ? Khusus KaaKangSatir Aja !!`)
let getGroups = await KaaKangSatir.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let hituet = 0
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await KaaKangSatir.groupMetadata(x)
teks += `❏ Group Ke ${hituet+=1}\n│⭔ *NAMA :* ${metadata2.subject}\n│⭔ *ID :* ${metadata2.id}\n│⭔ *MEMBER :* ${metadata2.participants.length}\n╰────|\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontakv1 id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu ID Group Nya Di Atas`)
}
break
//—————「 OWNER MENU 」—————//



//—————「 STORE MENU 」—————//
case 'tflimit': {
      if (isBan) return reply(mess.ban);
    // Memisahkan nomor tujuan dan jumlah limit yang akan ditransfer
    let [number, amount] = text.split(",");
    
    // Validasi input
    if (!number || !amount || isNaN(amount) || amount <= 0) {
        return reply(`Mohon masukkan nomor dan jumlah limit yang valid. Contoh penggunaan: ${prefix + command} 628xxx,100`);
    }
    
    amount = parseInt(amount); // Mengonversi jumlah ke integer
    
    let nomor = number + '@s.whatsapp.net'
    reply(nomor)
    
    // Mendapatkan data pengguna pengirim dan penerima
    let sender = global.db.data.users[m.sender];
    let receiver = global.db.data.users[nomor];
    
    // Validasi keberadaan penerima
    if (!receiver) {
        return reply(`Nomor tujuan tidak ditemukan dalam database.`);
    }

    // Validasi limit pengirim
    if (sender.limit < amount) {
        return reply(`Limit Anda tidak mencukupi untuk melakukan transfer ini.`);
    }
    
    // Melakukan transfer limit
    sender.limit -= amount;
    receiver.limit += amount;
    
    reply(`Berhasil mentransfer ${amount} limit kepada ${number}.`);
}
break;

case 'tfsaldo': {
      if (isBan) return reply(mess.ban);
    // Memisahkan nomor tujuan dan jumlah saldo yang akan ditransfer
    let [number, amount] = text.split(",");
    
    // Validasi input
    if (!number || !amount || isNaN(amount) || amount <= 0) {
        return reply(`Mohon masukkan nomor dan jumlah saldo yang valid. Contoh penggunaan: ${prefix + command} 628xxx,100`);
    }
    
    amount = parseInt(amount); // Mengonversi jumlah ke integer
    
    let nomor = number + '@s.whatsapp.net'
    reply(nomor)
    
    // Mendapatkan data pengguna pengirim dan penerima
    let sender = global.db.data.users[m.sender];
    let receiver = global.db.data.users[nomor];
    
    // Validasi keberadaan penerima
    if (!receiver) {
        return reply(`Nomor tujuan tidak ditemukan dalam database.`);
    }

    // Validasi saldo pengirim
    if (sender.saldo < amount) {
        return reply(`Limit Anda tidak mencukupi untuk melakukan transfer ini.`);
    }
    
    // Melakukan transfer saldo
    sender.saldo -= amount;
    receiver.saldo += amount;
    
    reply(`Berhasil mentransfer ${amount} saldo kepada ${number}.`);
}
break;

case 'tfsaldo': {
      if (isBan) return reply(mess.ban);
    // Memisahkan nomor tujuan dan jumlah saldo yang akan ditransfer
    let [number, amount] = text.split(",");
    
    // Validasi input
    if (!number || !amount || isNaN(amount) || amount <= 0) {
        return reply(`Mohon masukkan nomor dan jumlah saldo yang valid. Contoh penggunaan: ${prefix + command} 628xxx,100`);
    }
    
    amount = parseInt(amount); // Mengonversi jumlah ke integer
    
    // Mendapatkan data pengguna pengirim dan penerima
    let sender = global.db.data.users[m.sender];
    let receiver = Object.values(global.db.data.users).find(user => user.number === number);
    
    // Validasi keberadaan penerima
    if (!receiver) {
        return reply(`Nomor tujuan tidak ditemukan dalam database.`);
    }

    // Validasi saldo pengirim
    if (sender.saldo < amount) {
        return reply(`Limit Anda tidak mencukupi untuk melakukan transfer ini.`);
    }
    
    // Melakukan transfer saldo
    sender.saldo -= amount;
    receiver.saldo += amount;
    
    reply(`Berhasil mentransfer ${amount} saldo kepada ${number}.`);
}
break;
    
case 'buylimit': {
      if (isBan) return reply(mess.ban);
    if (!text) return reply(`Mohon masukkan jumlah limit yang valid. *Example :* penggunaan: ${prefix + command} 10`);

    if (!isNaN(text)) {
        const jumlahLimit = parseInt(text);
        const hargaPerLimit = 80;
        const hargaTotal = jumlahLimit * hargaPerLimit;
        const orderId = Date.now().toString().slice(-10); // inisialisasi di dalam blok if

        global.db.data.users[m.sender].orderId = orderId;
        global.db.data.users[m.sender].orderprice = hargaTotal; // Simpan harga total pesanan
        global.db.data.users[m.sender].orderamount = jumlahLimit; // Simpan jumlah item pesanan

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `*Konfirmasi Pembelian*\n\nID Order: ${orderId}\nID: ${m.sender}\nHarga: ${hargaTotal}\nBarang: ${jumlahLimit} Limit\n\nPilih 'Confirm' untuk melanjutkan pembelian atau 'Cancel' untuk membatalkan.`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: wm
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: ctext(`Klik tombol *Confirm* untuk melanjutkan pembelian\nKlik tombol *Cancel* untuk membatalkan pembelian`),
                            subtitle: "Konfirmasi Pembelian",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "quick_reply",
                                    "buttonParamsJson": `{\"display_text\":\"Confirm\",\"id\":\"${prefix + command} confirm\"}`
                                },
                                {
                                    "name": "quick_reply",
                                    "buttonParamsJson": `{\"display_text\":\"Cancel\",\"id\":\"${prefix + command} cancel\"}`
                                },
                            ],
                        })
                    })
                }
            }
        }, {});

        await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
            messageId: msg.key.id
        });
        }

        if (args[0] === 'confirm') {
    const user = global.db.data.users[m.sender];
    if (!user.orderId) {
        return reply('Anda belum memiliki pesanan.');
    }
    const hargaTotal = user.orderprice;
    const jumlahLimit = user.orderamount;

    if (user.saldo < hargaTotal) {
        return reply('Maaf Saldo Anda tidak mencukupi untuk membeli limit tersebut.');
    }
    // Lakukan pengurangan saldo dan penambahan limit
    user.saldo -= hargaTotal;
    user.limit += jumlahLimit;
    reply(`Pembelian berhasil!\nID Order: ${user.orderId}\nPesanan: ${user.orderamount} Limit`);
    // Hapus properti orderId setelah transaksi berhasil
    delete user.orderId;
    delete user.orderprice; // Hapus properti harga total pesanan
    delete user.orderamount; // Hapus properti jumlah item pesanan
} else if (args[0] === 'cancel') {
            const user = global.db.data.users[m.sender];
            if (!user.orderId) {
                return reply('Anda belum memiliki pesanan.');
            }
            delete user.orderId;
            delete user.orderprice; // Hapus properti harga total pesanan
            delete user.orderamount; // Hapus properti jumlah item pesanan
            reply(`Pembelian dibatalkan.`);
        }
}
break;

case "buypanel": {
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}

let saldoo = db.data.users[m.sender].saldo;

// Fungsi untuk memformat angka ke dalam format IDR

// Memformat saldo
let formattedSaldo = formatIDR(saldoo);
const caption = `Di Bawah Ini Adalah List Server Yang Tersedia`;
let sections = [
{
title: 'Server Minecraft',
highlight_label: 'Status : True ✅',
rows: [{
title: 'Minecraft Hosting',
description: `Menampilkan List Server Minecraft`, 
id: `${prefix}buyhostmc`
}]
},
{
title: 'Server Bot',
highlight_label: 'Status : True ✅',
rows: [{
title: 'Bot Hosting',
description: `Menampilkan List Server Bot`, 
id: `${prefix}buyhostbot`
}]
}]

let listMessage = {
    title: 'List Menu', 
    sections
}


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hii @${m.sender.split("@")[0]}`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5ycLmipE03nJQWELn5Xnbk4oQFB0TuATkSQ&usqp=CAU" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break


//Ini untuk serverMinecraft
case "buyhostmc": {
let saldoo = db.data.users[m.sender].saldo;
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
// Fungsi untuk memformat angka ke dalam format IDR

// Memformat saldo
let formattedSaldo = formatIDR(saldoo);
const caption = `Di Bawah Ini Adalah List Minecraft Yang Tersedia`;
let sections = [
{
title: 'Minecraft Server',
highlight_label: 'Status : True ✅',
rows: [{
title: 'Vanilla',
id: `${prefix}buyhostmc vanilla`
}]
},
{
highlight_label: 'Status : True ✅',
rows: [{
title: 'Vanilla Berdrock',
id: `${prefix}buyhostmc vanillabedrock`
}]
}]

let listMessage = {
    title: 'List Menu', 
    sections
}


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hii @${m.sender.split("@")[0]}`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/2419f0f3b48c7142b8ea7.png" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!text) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
if (args[0] === "vanilla") {
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
  const McMediaMessage = await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/b58de14b17c43834ae718.png' } }, { upload: KaaKangSatir.waUploadToServer });

  const cards = [];
  const configurations = [
    { ram: 1, disk: 5, vCpu: 1, price: 12000 },
    { ram: 2, disk: 10, vCpu: 1, price: 20000 },
    { ram: 3, disk: 15, vCpu: 2, price: 28000 },
    { ram: 4, disk: 20, vCpu: 2, price: 36000 },
    { ram: 5, disk: 25, vCpu: 3, price: 44000 },
    { ram: 6, disk: 30, vCpu: 3, price: 52000 }
  ];

  for (let config of configurations) {
    cards.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Status : True\nRam : ${config.ram}Gb\nDisk : ${config.disk}Gb\nvCpu : ${config.vCpu}\nRegion : Singapore\nPrice : Rp ${config.price.toLocaleString('id-ID')}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm
      }),
      header: proto.Message.InteractiveMessage.Header.create({
        title: '',
        subtitle: '',
        hasMediaAttachment: true,
        ...McMediaMessage
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "quick_reply",
            "buttonParamsJson": `{"display_text":"Buy", "id":"${prefix}adsrv ${pushname},${m.sender.split('@')[0]},vanilla,${config.ram},${config.disk},${config.vCpu},${config.price}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `*Halo! 👋 ${pushname}* \nBerikut adalah daftar paket server vanilla yang tersedia:`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: cards
          })
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
} else if (args[0] === "vanillabedrock") {
  if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
  const McMediaMessage = await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/b58de14b17c43834ae718.png' } }, { upload: KaaKangSatir.waUploadToServer });

  const cards = [];
  const configurations = [
    { ram: 1, disk: 5, vCpu: 1, price: 15000 },
    { ram: 2, disk: 10, vCpu: 1, price: 25000 },
    { ram: 3, disk: 15, vCpu: 2, price: 35000 },
    { ram: 4, disk: 20, vCpu: 2, price: 45000 },
    { ram: 5, disk: 25, vCpu: 3, price: 55000 },
    { ram: 6, disk: 30, vCpu: 3, price: 65000 }
  ];

  for (let config of configurations) {
    cards.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Status : True\nRam : ${config.ram}Gb\nDisk : ${config.disk}Gb\nvCpu : ${config.vCpu}\nRegion : Singapore\nPrice : Rp ${config.price.toLocaleString('id-ID')}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm
      }),
      header: proto.Message.InteractiveMessage.Header.create({
        title: '',
        subtitle: '',
        hasMediaAttachment: true,
        ...McMediaMessage
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "quick_reply",
            "buttonParamsJson": `{"display_text":"Buy", "id":"${prefix}adsrv ${pushname},${m.sender.split('@')[0]},vanillabedrock,${config.ram},${config.disk},${config.vCpu},${config.price}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `*Halo! 👋 ${pushname}* \nBerikut adalah daftar paket server vanilla bedrock yang tersedia:`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: cards
          })
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
}
}
break

//Ini Untuk Hosting Bot/Dll
case "buyhostbot": {
  let saldoo = db.data.users[m.sender].saldo;
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
  // Fungsi untuk memformat angka ke dalam format IDR
  function formatIDR(angka) {
      return angka.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
  }

  // Memformat saldo
  let formattedSaldo = formatIDR(saldoo);
  const caption = `Di Bawah Ini Adalah List Paket Hosting yang Tersedia`;
  
let sections = [
{
title: 'Select Language',
highlight_label: 'Status : True ✅',
rows: [{
title: 'Node.Js',
id: `${prefix}buyhostbot nodejs`
}]
},
{
highlight_label: 'Status : True ✅',
rows: [{
title: 'Python',
id: `${prefix}buyhostbot python`
}]
},
{
highlight_label: 'Status : True ✅',
rows: [{
title: 'PHP',
id: `${prefix}buyhostbot php`
}]
},
{
highlight_label: 'Status : True ✅',
rows: [{
title: 'Ruby',
id: `${prefix}buyhostbot ruby`
}]
},
{
highlight_label: 'Status : True ✅',
rows: [{
title: 'Java',
id: `${prefix}buyhostbot java`
}]
}]

  let listMessage = {
    title: 'Pilih Bahasa Pemrograman',
    sections
  };

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: saluran,
              newsletterJid: idsal,
              serverMessageId: 143
            },
            businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: caption
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Hii @${m.sender.split("@")[0]}`,
            subtitle: "",
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/6eb1c449d8e2a285f7867.png" } }, { upload: KaaKangSatir.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              }
            ]
          })
        })
      }
    }
  }, {});

if (!text) { 
await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
} else if (args[0] === "nodejs" || args[0] === "python" || args[0] === "php" || args[0] === "ruby" || args[0] === "java") {
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
  const language = args[0]; // Mendapatkan bahasa pemrograman dari argumen

  // Peta untuk mencocokkan bahasa dengan URL logo
  const logos = {
    nodejs: "https://telegra.ph/file/16a2906cb819ad162c956.png",
    python: "https://telegra.ph/file/0ec56bff660f542f0470f.png",
    php: "https://telegra.ph/file/41b287a0c58d281b3f6b2.png",
    ruby: "https://telegra.ph/file/90e3b8301f2a8592aa04b.png",
    java: "https://telegra.ph/file/30a8fc278eba08d3790fc.png"
  };

  const McMediaMessage = await prepareWAMessageMedia({ image: { url: logos[language] } }, { upload: KaaKangSatir.waUploadToServer });

  const caption = `Di Bawah Ini Adalah List Paket Hosting yang Tersedia untuk ${language.charAt(0).toUpperCase() + language.slice(1)}`;

  const cards = [];
  const configurations = [
    { ram: 1, disk: 5, vCpu: 1, price: 8000 },
    { ram: 2, disk: 10, vCpu: 1, price: 16000 },
    { ram: 3, disk: 15, vCpu: 2, price: 24000 },
    { ram: 4, disk: 20, vCpu: 2, price: 32000 }
  ];

  for (let config of configurations) {
    cards.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Status : True\nRam : ${config.ram}Gb\nDisk : ${config.disk}Gb\nvCpu : ${config.vCpu}\nRegion : Singapore\nPrice : Rp ${config.price.toLocaleString('id-ID')}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm
      }),
      header: proto.Message.InteractiveMessage.Header.create({
        title: '',
        subtitle: '',
        hasMediaAttachment: true,
        ...McMediaMessage
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "quick_reply",
            "buttonParamsJson": `{"display_text":"Buy", "id":"${prefix}adsrv ${pushname},${m.sender.split('@')[0]},${language},${config.ram},${config.disk},${config.vCpu},${config.price}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `*Halo! 👋 ${pushname}* \n${caption}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: cards
          })
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
}
}
break;

case "adsrv": {
if (global.apikeyplta || global.apikeypltc === 'YOUR_API') {
    return reply(ctext('*[ System Failed ]* Sorry this feature is in maintenance.'));
}
  let t = text.split(',');
  if (t.length < 7) return;

  let users = global.db.data.users[m.sender];

  let username = t[0];
  let u = m.sender;
  if (!u) return;

  let eggType = t[2].toLowerCase();
  let ram = parseInt(t[3]) * 1024; // Konversi RAM dari GB ke MB
  let disk = parseInt(t[4]) * 1024; // Konversi Disk dari GB ke MB
  let vCpu = parseInt(t[5]);
  let cpu = vCpu * 100; // Convert vCPU to percentage

  let pricefix = parseInt(t[6]);
  let formattedSaldo = formatIDR(pricefix);
  if (users.saldo < pricefix) {
    return reply(`Maaf Saldo Anda tidak mencukupi\nsaldo anda ${formatIDR(users.saldo)}.`);
  }

  let egg = global.eggs[eggType];
  if (!egg) return reply(`Egg type tidak ditemukan!`);

  let email = username + "@KaaKangSatir.dev";
  let password = username + "001";
  let loc = global.location;

  let user;

  // Check if user already exists on Pterodactyl
  let f1 = await fetch(`${global.domain}/api/application/users?filter[email]=${email}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikeypltc
    }
  });
  let existingUserData = await f1.json();
  if (existingUserData.data && existingUserData.data.length > 0) {
    user = existingUserData.data[0].attributes;
  } else {
    // Create user on Pterodactyl
    let f2 = await fetch(global.domain + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + global.apikeypltc
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password
      })
    });
    let data = await f2.json();
    if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
    user = data.attributes;
  }

// Notify user with account details
let caps = `${gris}</> TRX SUCCESS </>${gris}

- *Username :* ${user.username}
- *Passwords :* ${password}
- *Server* : ${eggType}
- *Harga :* ${formattedSaldo}

${gris}</> TRX SUCCESS </>${gris}`

let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
        message: {
            "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: caps
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: wm
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ video: { url: 'https://host10.onlineconverter.com/file/10924563d9cc4fba9ac81e330a79d283fb/download' }}, { upload: KaaKangSatir.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
              {
                "name": "cta_copy",
                "buttonParamsJson": JSON.stringify({
                "display_text": "Copy Data",
                "copy_code": `Username : ${user.username}\nPassword : ${password}`
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Login","url":"${global.domain}","merchant_url":"${global.domain}"}`
              }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})

  // Use startup command from settings
  let startup_cmd = egg.startup;

  // Create server on Pterodactyl
  let f3 = await fetch(global.domain + "/api/application/servers", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikeypltc
    },
    body: JSON.stringify({
      name: username,
      user: user.id,
      egg: parseInt(egg.id),
      docker_image: egg.docker_image,
      startup: startup_cmd,
      environment: {
        INST: eggType === 'nodejs' ? 'npm' : undefined,
        USER_UPLOAD: "0",
        AUTO_UPDATE: "0",
        CMD_RUN: eggType === 'nodejs' ? 'npm start' : undefined,
        MAIN_FILE: eggType === 'nodejs' ? 'index.js' : undefined,
        PY_FILE: eggType === 'python' ? 'main.py' : undefined,
        REQUIREMENTS_FILE: eggType === 'python' ? 'requirements.txt' : undefined,
        JARFILE: eggType === 'java' ? 'server.jar' : undefined,
        SERVER_JARFILE: eggType === 'vanilla' ? 'server.jar' : undefined,
        VANILLA_VERSION: eggType === 'vanilla' ? 'latest' : undefined,
        BEDROCK_VERSION: eggType === 'vanillabedrock' ? 'latest' : undefined,
        LD_LIBRARY_PATH: eggType === 'vanillabedrock' ? '/path/to/ld/library' : undefined,
        SERVERNAME: username,
        GAMEMODE: 'survival',
        DIFFICULTY: 'normal',
        CHEATS: 'false',
        STARTUP_CMD: startup_cmd // Menambahkan STARTUP_CMD ke environment
      },
      limits: {
        memory: ram.toString(),
        swap: 0,
        disk: disk.toString(),
        io: 500,
        cpu: cpu.toString()
      },
      feature_limits: {
        databases: 5,
        backups: 5,
        allocations: 1
      },
      deploy: {
        locations: [parseInt(loc)],
        dedicated_ip: false,
        port_range: []
      }
    })
  });
  let res = await f3.json();
  if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2));
  let server = res.attributes;

  // Notify user about server creation
  reply(`𝐃𝐎𝐍𝐄 𝐒𝐈𝐋𝐀𝐇𝐊𝐀𝐍 𝐂𝐄𝐊 𝐃𝐀𝐓𝐀 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐀𝐍𝐃𝐀 𝐒𝐔𝐃𝐀𝐇 𝐓𝐄𝐑𝐊𝐈𝐑𝐈𝐌 𝐊𝐄 𝐍𝐎𝐌𝐎𝐑 𝐓𝐄𝐑𝐒𝐄𝐁𝐔𝐓 ☑️`);

  // Lakukan pengurangan saldo
  users.saldo -= pricefix;
}
break;

case 'topup':{
const cap = `Berikut daftar topup yang tersedia

- topupwallet
- topuppulsa`
reply(cap)
}
break

case 'ewallet':
case 'topupwallet':
case 'topupewallet': {
  if (!text) return reply(`*Example :* ${prefix + command} 085609279108,10000`);

  // Menghapus karakter non-digit dan mengganti awalan +62 atau 62 dengan 0
  let [phoneNumber, amount] = text.split(',').map(item => item.trim().replace(/\D/g, '')); // Menghapus karakter non-digit dari nomor
  if (phoneNumber.startsWith('62')) {
    phoneNumber = '0' + phoneNumber.slice(2);
  }

  let sections = [
    {
      title: 'Digital Wallet',
      highlight_label: 'True ✅',
      rows: [{
        title: 'TopUp Dana',
        id: `${prefix}topup-dana ${phoneNumber},${amount}`
      }]
    },
    {
      highlight_label: 'False ❌',
      rows: [{
        title: 'TopUp Gopay',
        id: `${prefix}topup-gopay ${phoneNumber},${amount}`
      }]
    },
    {
      highlight_label: 'True ✅',
      rows: [{
        title: 'TopUp OVO',
        id: `${prefix}topup-ovo ${phoneNumber},${amount}`
      }]
    },
    {
      highlight_label: 'True ✅',
      rows: [{
        title: 'TopUp ShopeePay',
        id: `${prefix}topup-sp ${phoneNumber},${amount}`
      }]
    }
  ];

  let listMessage = {
    title: 'TopUp',
    sections
  };

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: saluran,
              newsletterJid: idsal,
              serverMessageId: 143
            },
            businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Silahkan pilih ewallet anda`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `Hii @${m.sender.split("@")[0]}`,
            subtitle: "",
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: "https://cdn.dribbble.com/users/2882545/screenshots/12370157/g37988_4x.png" } }, { upload: KaaKangSatir.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              }
            ],
          })
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
}
break;

case 'checkmyorder': {
    let [id, code] = text.split(",");
    if (!id || !code) {
        await reply(`Format penggunaan: ${prefix + command} <id>,<code>`);
        break;
    }
    
    try {
        let apiUrl = `https://api.neoxr.eu/api/topup-check?id=${id}&code=${code}&apikey=${neoxr}`;
        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;

        let statusMessage;
        switch (data.status.toLowerCase()) {
            case 'pending':
                statusMessage = "Transaksi anda saat ini sedang diproses. Mohon tunggu beberapa saat.";
                break;
            case 'success':
                statusMessage = "Transaksi anda telah berhasil! Terima kasih telah menggunakan layanan kami.";
                break;
            case 'failed':
                statusMessage = "Maaf, transaksi anda gagal. Silakan coba lagi atau hubungi layanan pelanggan.";
                break;
            default:
                statusMessage = `Status transaksi anda: ${data.status}.`;
                break;
        }

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            mentionedJid: [m.sender], 
                            isForwarded: true, 
                            forwardedNewsletterMessageInfo: {
                                newsletterName: saluran,
                                newsletterJid: idsal,
                                serverMessageId: 143
                            },
                            businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
                        }, 
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: statusMessage
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: wm
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "",
                            subtitle: "",
                            hasMediaAttachment: false // Tidak ada media untuk header
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [ 
                                {
                                    "name": "quick_reply",
                                    "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${id},${code}"}`
                                }
                            ],
                        })
                    })
                }
            }
        }, {});

        await KaaKangSatir.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });

    } catch (e) {
        console.error(e);
        await reply("Terjadi kesalahan saat memeriksa status transaksi. Silakan coba lagi nanti.");
    }
}
break

case 'topup-dana': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 1000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 1000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/topup-dana?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up DANA.');
    }
    }
break
    
case 'topup-gopay': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 1000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 1000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/topup-gopay?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up GOPAY.');
    }
    }
break

case 'topup-ovo': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 1000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 1000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/topup-ovo?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up OVO.');
    }
    }
break

case 'topup-sp': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 1000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 1000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/topup-shopeepay?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up SHOOPE PAY.');
    }
    }
break

case 'topuppulsa':
case 'topuppul':
case 'pulsa':
case 'isipul':
case 'isipulsa': {
  if (!text) return reply(`*Example :* ${prefix + command} 085609279108`);

  // Menghapus karakter non-digit dan mengganti awalan +62 atau 62 dengan 0
  let phoneNumber = text.trim().replace(/\D/g, ''); // Menghapus karakter non-digit dari nomor
  if (phoneNumber.startsWith('62')) {
    phoneNumber = '0' + phoneNumber.slice(2);
  }

  const operators = {
    'Axis': /^0838|^0837|^0831|^0832|^0833|^0838|^0837/,
    'Tri': /^0895|^0896|^0897|^0898|^0899/,
    'Telkomsel': /^0811|^0812|^0813|^0821|^0822|^0823|^0851|^0852|^0853|^0855|^0856|^0857|^0858/,
    'Indosat': /^0814|^0815|^0816|^0855|^0856|^0857|^0858|^0859|^0877|^0878/,
    'XL': /^0817|^0818|^0819|^0859|^0877|^0878/,
  };

  let provider = '';
  for (const [operator, regex] of Object.entries(operators)) {
    if (regex.test(phoneNumber)) {
      provider = operator.toLowerCase();
      break;
    }
  }

  if (!provider) {
    return reply(`Maaf, operator dari nomor ${text} tidak dapat terdeteksi.`);
  }

  // Menghasilkan pengurangan acak antara 1 dan 5
  const randomReduction = Math.floor(Math.random() * 5) + 1;

  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }

  await m.reply(mess.wait);

  try {
    let push = [];
    let i = 1;

    const pulsaProducts = {
      'axis': [5000, 10000, 15000, 25000, 30000, 50000, 100000],
      'indosat': [5000, 10000, 12000, 15000, 20000, 25000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000],
      'telkomsel': [5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 95000, 100000],
      'tri': [5000, 8000, 10000, 15000, 20000, 25000, 30000, 40000, 50000, 75000, 100000],
      'xl': [5000, 10000, 15000, 25000, 30000, 50000, 100000]
    };

    const pulsaImages = {
      'axis': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzlN6cFPQxF7x3twqWFeaMALIF3cG_-CfXzqUvIHPMmp_gGGrDdhLQ1u3f&s=10',
      'indosat': 'https://asset-2.tstatic.net/jabar/foto/bank/images/logo-indosat-ooredoo.jpg',
      'telkomsel': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOYxo4jcuvIpDPiRK0r75c1Xgz1MUiHpCUiA&s',
      'tri': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAki9AGGxmEXkVn3NUfnZaiPMVhLbs0kq9LQ&usqp=CAU',
      'xl': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOYJAIMi0IJcCZS-Hha7W2UWrWfQuYDrkEb-OPvCTNPJKpdoHULFRFSC0&s=10'
    };

    const prices = pulsaProducts[provider].slice().sort((a, b) => a - b); // Mengurutkan harga dari terkecil ke terbesar

    const numImages = prices.length; // Menggunakan jumlah harga yang tersedia untuk operator yang dipilih

    for (let j = 0; j < numImages; j++) {
      let price = prices[j];
      let imge = pulsaImages[provider]; // Menggunakan gambar yang sesuai dengan provider
      let apiUrl = `https://api.neoxr.eu/api/pulsa-${provider}?number=${phoneNumber}&amount=${price}&apikey=${neoxr}`;
      let response = await fetch(apiUrl);
      let json = await response.json();

      if (!json.status) throw json;

      let data = json.data;
      let cap = `Operator: ${provider}\nNomor: ${phoneNumber}\nJumlah: ${price.toLocaleString('id-ID')}\nHarga: ${data.price_format}`; // Caption sesuai permintaan

      const mediaMessage = await prepareWAMessageMedia({ image: { url: imge } }, { upload: KaaKangSatir.waUploadToServer });

      push.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: cap
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: wm
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: "",
          subtitle: ``,
          hasMediaAttachment: true,
          ...mediaMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
                  "name": "quick_reply",
                  "buttonParamsJson": `{"display_text":"Buy","id":"${prefix}topup-${provider} ${phoneNumber},${price}"}`
            }
          ]
        })
      });
    }

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `Dibawah ini adalah list yang tersedia untuk nomor yang Anda masukkan. Silakan pilih sesuai kebutuhan Anda.`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: wm
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: push // Mengirim semua cards yang telah dibuat
            })
          })
        }
      }
    }, {});

    await KaaKangSatir.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id
    });

    global.db.data.users[m.sender].limit -= randomReduction;
  } catch (e) {
    console.error(e);
    await reply(mess.error);
  }
}
break;

case 'topup-axis': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 5000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 5000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/pulsa-axis?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up AXIS.');
    }
    }
break

case 'topup-indosat': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 5000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 5000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/pulsa-indosat?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up INDOSAT.');
    }
    }
break

case 'topup-telkomsel': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 5000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 5000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/pulsa-telkomsel?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up TELKOMSEL.');
    }
    }
break

case 'topup-tri': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 5000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 5000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/pulsa-tri?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up TRI.');
    }
    }
break

case 'topup-xl': {
    let [number, amount] = text.split(",");
    
    if (!number || !amount) {
        await reply(`Format penggunaan: ${prefix + command} <number> <amount>`);
        break;
    }
    
    amount = parseInt(amount);
    if (isNaN(amount) || amount < 5000 || amount > 500000) {
        await reply(`Jumlah pembelian harus antara 5000 dan 500000.`);
        break;
    }

    try {
        let apiUrl = `https://api.neoxr.eu/api/pulsa-xl?number=${number}&amount=${amount}&apikey=${neoxr}`;

        let response = await fetch(apiUrl);
        let json = await response.json();

        if (!json.status) throw json;

        let data = json.data;
        let message = `
*Top Up ${data.product.service}*
ID Transaksi: ${data.id}
Kode: ${data.code}
Nomor: ${data.number}
Tipe Produk: ${data.product.type}
Layanan: ${data.product.service}
Harga: ${data.price_format}
Berlaku Hingga: ${data.expired_at}
`;

        // Convert base64 to buffer
        let buffer = Buffer.from(data.qr_image, 'base64');
        
        let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: message
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: buffer }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Check Order","id":"${prefix}checkmyorder ${data.id},${data.code}"}`
            }
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
   

    } catch (e) {
        console.error(e);
        await reply('Terjadi kesalahan saat memproses permintaan top-up XL.');
    }
    }
break
//—————「 STORE MENU 」—————//

//—————「 SEARCH MENU 」—————//


case 'yts': {
  if (!text) return reply(`*Example :* ${prefix + command} judulnya`);

  // Menghasilkan pengurangan acak antara 1 dan 5
  

  if (global.db.data.users[m.sender].limit < randomReduction) {
    reply(mess.endLimit);
    return; // Menghentikan eksekusi jika batas telah habis
  }

  await m.reply(mess.wait);

  try {
    let search = await yts(text);
    let videos = search.all;

    if (!videos || videos.length === 0) {
      reply('No video found');
      return;
    }

    // Pilih antara 1 dan 5 video secara acak
    const numVideos = Math.min(videos.length, Math.floor(Math.random() * 5) + 1);
    const selectedVideos = [];

    while (selectedVideos.length < numVideos) {
      const randomIndex = Math.floor(Math.random() * videos.length);
      const randomVideo = videos.splice(randomIndex, 1)[0]; // Menghindari pemilihan video yang sama
      selectedVideos.push(randomVideo);
    }

    let push = [];

    for (let i = 0; i < selectedVideos.length; i++) {
      let video = selectedVideos[i];
      let cap = `Title : ${video.title}`;

      const mediaMessage = await prepareWAMessageMedia({ image: { url: video.thumbnail } }, { upload: KaaKangSatir.waUploadToServer });

      push.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: cap
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: wm
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: `Video ke - ${i + 1}`,
          subtitle: '',
          hasMediaAttachment: true,
          ...mediaMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Video 🎬","id":"${prefix}ytmp4 ${video.url}"}`
            },
            {
              "name": "quick_reply",
              "buttonParamsJson": `{"display_text":"Audio 🎵","id":"${prefix}ytmp3 ${video.url}"}`
            }
          ]
        })
      });
    }

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: mess.success
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: wm
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: push
            })
          })
        }
      }
    }, {});

    await KaaKangSatir.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id
    });

    global.db.data.users[m.sender].limit -= randomReduction;
  } catch (e) {
    console.error(e);
    await reply(mess.error);
  }
}
break

case 'gichar': {
  const validCharacters = [
    "jean", "amber", "lisa", "kaeya", "barbara", "diluc", "razor", "venti", "klee", "bennett", "noelle", "fischl", "sucrose", "mona", "diona", "albedo", "rosaria", "eula", "aloy", "xiao", "beidou", "ningguang", "xiangling", "xingqiu", "chongyun", "qiqi", "keqing", "tartaglia", "zhongli", "xinyan", "ganyu", "hu tao", "yanfei", "shenhe", "yun jin", "yelan", "kamisato ayaka", "kaedehara kazuha", "yoimiya", "sayu", "raiden shogun", "kujou sara", "sangonomiya kokomi", "thoma", "arataki itto", "gorou", "yae miko", "kamisato ayato", "kuki shinobu", "shikanoin heizou", "tighnari", "collei", "dori", "cyno", "candace", "nilou", "nahida", "layla", "wanderer", "faruzan"
  ];

  if (!text) return reply(`Example: ${prefix + command} jean`);

  // Mengecek apakah karakter yang dimasukkan valid
  if (!validCharacters.includes(text.toLowerCase())) {
    return reply(`Karakter tidak valid. Berikut adalah daftar karakter yang tersedia:\n\n${validCharacters.join(', ')}`);
  }

  reply(mess.wait);

  try {
    var { data } = await axios.get(`https://api.lolhuman.xyz/api/genshin/${text}?apikey=elainaai`);
    var caption3 = `Name : ${data.result.title}\n`;
    caption3 += `Intro : ${data.result.intro}\n`;
    caption3 += `Icon : ${data.result.icon}\n`;
    await KaaKangSatir.sendMessage(m.chat, { image: { url: data.result.cover1 }, caption: caption3 });
    await KaaKangSatir.sendMessage(m.chat, { audio: { url: data.result.cv[0].audio[0] }, mimetype: 'audio/mp4' });
  } catch (error) {
    console.error(error);
    reply('Terjadi kesalahan saat mengambil data karakter.');
  }
  break;
}

;

case 'pinterest': case 'pin': {
  if (!text) return reply(`Enter Query`);
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  await m.reply(mess.wait);

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: KaaKangSatir.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res); // Mengacak array
  let ult = res.splice(0, 5); // Mengambil 10 gambar pertama dari array yang sudah diacak
  let i = 1;

  for (let pus of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Hasil.',
        hasMediaAttachment: true,
        imageMessage: await createImage(pus)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      buttons: [
            {
              name: "cta_url",
              buttonParamsJson: `{"display_text":"url","url":"${pus}","merchant_url":"${pus}"}`
            }
         ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: mess.success
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await KaaKangSatir.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
    global.db.data.users[m.sender].limit -= randomReduction;

  //} catch (e) {}
}
break

case 'metaai': {
                (async () => {
                    try {
                        const browser = await puppeteer.launch({ headless: true });
                        const page = await browser.newPage();

                        await page.goto('https://meta.ai/');
                        await page.waitForTimeout(2000);

                        const title = await page.title();
                        console.log(`Page Title: ${title}`);

                        const modelCards = await page.$$eval('.model-card', (cards) => cards.map((card) => ({
                            title: card.querySelector('h2').textContent.trim(),
                            description: card.querySelector('p').textContent.trim(),
                            url: card.querySelector('a').getAttribute('href'),
                        })));

                        console.log('Model Cards:');
                        modelCards.forEach((card) => console.log(`- ${card.title} - ${card.description} - ${card.url}`));

                        const blogPosts = await page.$$eval('.blog-post', (posts) => posts.map((post) => ({
                            title: post.querySelector('h2').textContent.trim(),
                            summary: post.querySelector('p').textContent.trim(),
                            url: post.querySelector('a').getAttribute('href'),
                        })));

                        console.log('Blog Posts:');
                        blogPosts.forEach((post) => console.log(`- ${post.title} - ${post.summary} - ${post.url}`));

                        await browser.close();

                        // Send the extracted data as a message
                        let responseMessage = `*Page Title:* ${title}\n\n*Model Cards:*\n`;
                        modelCards.forEach(card => {
                            responseMessage += `- *Title:* ${card.title}\n  *Description:* ${card.description}\n  *URL:* ${card.url}\n\n`;
                        });
                        responseMessage += `*Blog Posts:*\n`;
                        blogPosts.forEach(post => {
                            responseMessage += `- *Title:* ${post.title}\n  *Summary:* ${post.summary}\n  *URL:* ${post.url}\n\n`;
                        });

                        reply(responseMessage);
                    } catch (err) {
                        console.error('Error occurred:', err);
                        reply('An error occurred while scraping the Meta AI site.');
                    }
                })();
                }
                break;

case 'me': {
    // Cek apakah pengguna dibanned
    if (isBan) return reply(mess.ban);

    // Ambil data pengguna dari database
    let user = global.db.data.users[m.sender];

    // Membuat profil pengguna
    let profile = `${gris}</> MY PROFILE </>${gris}
    Name : ${pushname}
    Number : ${m.sender.split('@')[0]}
    Hoby : ${user.hoby || ''}
    Status : ${user.status || ''}
    Saldo : ${user.saldo || 0}
    Limit : ${user.limit || 0}
    Register : ${user.register || 'False'}
    Birthday : ${user.birthday || ''}
    `;

    // Mengirim pesan profil pengguna
    KaaKangSatir.sendMessage(from, { image: { url: ProfileUsers }, caption: profile }, { quoted: m });
}
break;

case 'spotify':
case 'spotifydl': {
  if (isBan) return reply(mess.ban);
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!text) return reply(`*Example :* ${prefix + command} Drunk Text or a Spotify link`);

let urlSpotify;
    if (text.startsWith('https://open.spotify.com/')) {
        reply(mess.wait)
        urlSpotify = text;
    } else if (text.startsWith('https://')) {
        return reply('The link you provided is not a valid Spotify link');
    } else {
        reply(mess.wait)
        let api = await fetchJson(`https://api.junn4.my.id/search/spotify?query=${text}`);
        if (!api.data || api.data.length === 0) return reply('No results found.');
        urlSpotify = `${api.data[0].url}`;
    }
    
    let spotify = await fetchJson(`https://api.junn4.my.id/download/spotify?url=${urlSpotify}`);
    const spoDl = spotify.data.download
    
KaaKangSatir.sendMessage(m.chat, {
audio: {
url: spoDl
},
fileName: `${spotify.data.title || ''}.mp3`,
mimetype: 'audio/mpeg',
contextInfo: {
externalAdReply: {
title: `Title: ${spotify.data.title || ''}`,
body: `${spotify.data.artis}`,
thumbnailUrl: `${spotify.data.image}`, 
sourceUrl: `${urlSpotify}`,
mediaType: 1,
showAdAttribution: true,
renderLargerThumbnail: true
}
}
}, {
quoted: fcall
})
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'apks': {
    if (!text) return m.reply(`*Example :* ${prefix + command} WhatsApp`);

    try {
        let encodedText = encodeURIComponent(text);
        let response = await fetch(`https://api.neoxr.eu/api/apk?q=${encodedText}&no=1&apikey=${neoxr}`);
        let apkInfo = await response.json();

        if (apkInfo.status) {
            let apkData = apkInfo.data;
            let message = `
*Nama Aplikasi:* ${apkData.name}
*Versi:* ${apkData.version}
*Pengembang:* ${apkData.developer}
*Rating:* ${apkData.rating}
*Instalasi:* ${apkData.install}
*Package Name:* ${apkData.package}
*Membutuhkan:* ${apkData.requires}
*Arsitektur:* ${apkData.architecture}
*Permissions:* ${apkData.permissions}
*Rating Konten:* ${apkData.content_rating}
*Diterbitkan:* ${apkData.published}
*Ukuran File:* ${apkData.file.size}
`;

            // Cek ukuran file APK
            let fileSizeMB = parseFloat(apkData.file.size);
            if (fileSizeMB > 50) {
                // Jika ukuran file melebihi 70 MB, kirim pesan dengan link APK
                await m.reply(`${message}\n\n[Download APK](${apkData.file.url})`);
            } else {
                // Jika ukuran file kurang dari atau sama dengan 70 MB, kirim file APK beserta pesan
                await KaaKangSatir.sendMessage(m.chat, {
                    document: Buffer.from(await (await fetch(apkData.file.url)).arrayBuffer()),
                    mimetype: 'application/vnd.android.package-archive',
                    filename: `${apkData.name}.apk`,
                    caption: message,
                }, { quoted: m });
            }

        } else {
            m.reply('Aplikasi tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error fetching or sending APK info:', error);
        m.reply('Terjadi kesalahan saat mengambil atau mengirim info APK.');
    }
}
break;

case 'resep': {
    if (!text) return m.reply(`*Example :* ${prefix + command} ayam+geprek`);

    try {
        let encodedText = encodeURIComponent(text);
        let response = await fetch(`https://api.neoxr.eu/api/resep?q=${encodedText}&apikey=${neoxr}`);
        let recipeInfo = await response.json();

        if (recipeInfo.status) {
            let recipeData = recipeInfo.data;
            let message = `
*Judul Resep:* ${recipeData.title}
*Durasi:* ${recipeData.timeout}
*Porsi:* ${recipeData.portion}

*Bahan-bahan:*
${recipeData.ingredients.join('\n')}

*Cara membuat:*
${recipeData.steps.join('\n')}
`;

            // Kirim pesan dengan informasi resep
            KaaKangSatir.sendImage(from, recipeData.thumbnail, message, m)

        } else {
            m.reply('Resep tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error fetching or sending recipe:', error);
        m.reply('Terjadi kesalahan saat mengambil atau mengirim resep.');
    }
}
break;

//—————「 SEARCH MENU 」—————//



//—————「 TOOLS MENU 」—————//
case "disk":{
exec('cd && du -h --max-depth=1', (err, stdout) => {
if (err) return m?.reply(`${err}`)
if (stdout) return m?.reply(stdout)
})
}
break
case "clone":
case "jadibot":
case "clonebot": {
wek = `${gris}</> CLONE BOT </>${gris}`

let sections = [{
title: 'Selection',
rows: [{
title: 'Start',
description: `Getting started as a bot`, 
id: `${prefix}startjadibot`
},
{
title: 'Stop',
description: `Stop being a bot`, 
id: `${prefix}stopjadibot`
},
{
title: 'List',
description: `Displays a list of bot users`, 
id: `${prefix}listjadibot`
}]
}]

let listMessage = {
    title: 'Selection', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: wek
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: "",
 subtitle: "",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/4235b63388255ea893327.png" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 ],
 })
 })
 }
 }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case "startjadibot":{
  //if (m.isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isPrem) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  jadibot(KaaKangSatir, m, from)
  await sleep(4000)
  //m.reply(`mess.wait`)
  const jsonData = JSON.parse(fs.readFileSync(`./session/${m.sender.split("@")[0]}/creds.json`));
// Membaca pairingCode dari file JSON
const pairingCode = jsonData.pairingCode;
// Membagi pairingCode menjadi kelompok-kelompok berisi empat karakter
let formattedPairingCode = '';
for (let i = 0; i < pairingCode.length; i += 4) {
  if (i > 0) {
    formattedPairingCode += '-';
  }
  formattedPairingCode += pairingCode.substring(i, i + 4);
}
// Mengirimkan Pesan
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `You Pairing Code : *${formattedPairingCode}*\n\n*How To Install*\n1. Enter the *linked device*\n2. Click *link device*\n3. Click enter *with phone number only*\n4. Enter your *code*"\n\nYour code will *expire* in *20* seconds`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({ 
                  title: ``,
                  gifPlayback: true,
                  subtitle: `test`,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "cta_copy",
                "buttonParamsJson": JSON.stringify({
                "display_text": "Copy code",
                "copy_code": `${formattedPairingCode}`
                })
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterName: saluran,
				  newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case "stopjadibot":{
  //if (m.isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isPrem) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  stopjadibot(KaaKangSatir, from)
}
break
case "listjadibot":{
  //if (isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isPrem) return m.reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  listjadibot(KaaKangSatir, m)
}
break

case 'emojito': {
if (isBan) return reply(mess.bann)
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!text) return reply(`*Example :* ${prefix + command} 😳`)
    let encodedText = encodeURIComponent(text);
    try {
        // Ambil URL emoji WEBP
        reply(mess.wait)
        let response = await fetch(`https://api.neoxr.eu/api/emojito?q=${encodedText}&apikey=${neoxr}`);
        let emoji = await response.json();

        if (emoji.status) {
            // Kirim stiker langsung menggunakan sendMessage
            await KaaKangSatir.sendMessage(from, { sticker: { url: emoji.data.url }, packname: global.packname, author: global.author })
 global.db.data.users[m.sender].limit -= randomReduction;
        } else {
            m.reply('Gagal mendapatkan emoji.');
        }
    } catch (error) {
        console.error('Error fetching or sending emoji:', error);
        m.reply('Terjadi kesalahan saat mengambil atau mengirim emoji.');
    }
}
break;

case 'telestick': 
case 'sticktele':{
		if (args[0] && args[0].match(/(https:\/\/t.me\/addstickers\/)/gi)) {
		 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
		await reply(mess.wait)
		let telestic = await Telesticker(args[0])
		if (m.isGroup && telestic.length > 30) {
			await reply('Jumlah stiker lebih dari 30, shun akan mengirimkan melalui private message')
			for (let i = 0; i < telestic.length; i++) {
				KaaKangSatir.sendMessage(m.sender, { sticker: { url: telestic[i].url }, packname: global.packname, author: global.author})
			}
		} else {
			for (let i = 0; i < telestic.length; i++) {
				KaaKangSatir.sendMessage(m.chat, { sticker: { url: telestic[i].url }, packname: global.packname, author: global.author})
			}
		}
    global.db.data.users[m.sender].limit -= randomReduction;
	} else reply(`*Example :* ${prefix + command} https://t.me/addstickers/bokepanak1`)
}
break

case 'lacakip': {
if (!text) return m.reply(`Masukin ipnya`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    let mannr = await fetch(`https://ipwho.is/${text}`).then(result => result.json());
    await KaaKangSatir.sendMessage(m.chat, { location: { degreesLatitude: mannr.latitude, degreesLongitude: mannr.longitude }},{ ephemeralExpiration: 604800 });
    await delay(2000);
    m.reply(JSON.stringify(mannr, null, 2));
    global.db.data.users[m.sender].limit -= randomReduction;
}

case 'git': 
case 'gitclone': {
if (isBan) return reply(mess.bann)
if (!args[0]) return reply(`Mana link nya?`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
reply(mess.wait)
await sleep(200)
                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
                let [, user, repo] = args[0].match(regex1) || []
                repo = repo.replace(/.git$/, '')
                let url = `https://api.github.com/repos/${user}/${repo}/zipball`
                let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
                 // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;
                KaaKangSatir.sendMessage(m.chat, { document: { url: url }, fileName: filename, mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
            .catch(console.error)
            }
break

case 'toimage': 



case 'tomp3': {
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
reply(mess.wait)
await sleep(200)
if (!quoted) reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
let media = await KaaKangSatir.downloadMediaMessage(quoted)
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
KaaKangSatir.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${KaaKangSatir.user.name}.mp3`}, { quoted : m })
 // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;
}
break



case 'tovn': {
if (isBan) return reply(mess.bann)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
reply(mess.wait)

await sleep(200)
if (!/video/.test(mime) && !/audio/.test(mime)) reply(`*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`)
if (!quoted) reply(`*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`)
let media = await quoted.download()
let { toPTT } = require('./lib/converter')
let audio = await toPTT(media, 'mp4')
KaaKangSatir.sendMessage(from, {audio: audio, mimetype:'audio/mpeg', ptt:true})
 // Menghasilkan pengurangan acak antara 1 dan 5
    global.db.data.users[m.sender].limit -= randomReduction;
}
break
            
case 'tourl': {
if (isBan) return reply(mess.ban)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!/video/.test(mime) && !/image/.test(mime)) throw `*Send/Reply the Video/Image With Caption* ${prefix + command}`
if (!quoted) throw `*Send/Reply the Video/Image Caption* ${prefix + command}`
reply(mess.wait)
let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
let cap = `${mess.success}\nLink : ${util.format(anu)}`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: cap
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({ 
                  title: ``,
                  gifPlayback: true,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "cta_copy",
                "buttonParamsJson": JSON.stringify({
                "display_text": "Copy Link",
                "copy_code": `${util.format(anu)}`
                })
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterName: saluran,
				  newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
    global.db.data.users[m.sender].limit -= randomReduction;
await fs.unlinkSync(media)
}
break

case 'shorturl': 
case 'shortlink': {
if (isBan) return reply(mess.ban)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!text) throw `*Example :* ${prefix + command} URL`
reply(mess.wait)
let res = await fetch(`https://aemt.me/tinyurl?link=${text}`)
let short = await res.json()
let cap = `${mess.success}\nLink : ${util.format(short.result)}`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: cap
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({ 
                  title: ``,
                  gifPlayback: true,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "cta_copy",
                "buttonParamsJson": JSON.stringify({
                "display_text": "Copy Link",
                "copy_code": `${util.format(anu)}`
                })
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterName: saluran,
				  newsletterJid: idsal,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case "ssweb": {
    let link = text; // Simpan link yang dikirim ke dalam variabel 'link'
    if (!link) return reply(`*Example :* ${prefix + command} link`);
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    if (!/^https?:\/\//.test(link)) return reply('Awali *URL* dengan http:// atau https://');

    let msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: 'Silahkan pilih *option* di bawah ini'
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: wm
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        gifPlayback: true,
                        subtitle: ownername,
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"Desktop","id":"${prefix}sswebdesktop ${link}"}`
                            },
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"Tablet","id":"${prefix}sswebtablet ${link}"}`
                            },
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"Phone","id":"${prefix}sswebphone ${link}"}`
                            }
                        ],
                    }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                                newsletterName: saluran,
                                newsletterJid: idsal,
                            serverMessageId: 143
                        }
                    }
                })
            }
        }
    }, {});

    await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break

case "sswebdesktop":{
if (!text) return reply(`*Example :* ${prefix+command} link`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!/^https?:\/\//.test(text)) return reply('Awali *URL* dengan http:// atau https://')
reply(mess.wait)
let krt = await sswebDesktop(text)
KaaKangSatir.sendMessage(from ,{ image: krt.result, caption: mess.success },{ quoted: m })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case "sswebtablet":{
if (!text) return reply(`*Example :* ${prefix+command} link`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!/^https?:\/\//.test(text)) return reply('Awali *URL* dengan http:// atau https://')
reply(mess.wait)
let krt = await sswebTablet(text)
KaaKangSatir.sendMessage(from ,{ image: krt.result, caption: mess.success },{ quoted: m })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case "sswebphone":{
if (!text) return reply(`*Example :* ${prefix+command} link`)
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
if (!/^https?:\/\//.test(text)) return reply('Awali *URL* dengan http:// atau https://')
reply(mess.wait)
let krt = await sswebPhone(text)
KaaKangSatir.sendMessage(from ,{ image: krt.result, caption: mess.success },{ quoted: m })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'recolor': {
  if (!quoted) return reply(`Where is the picture?`)
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
  reply(mess.wait)
  let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
  let anu = await TelegraPh(media)
  let recolor = await fetchJson(`https://api.neoxr.eu/api/recolor?image=${anu}&apikey=${neoxr}`)
  await KaaKangSatir.sendMessage(m.chat, { image: { url: recolor.data.url }, caption: mess.success}, { quoted: fcall})
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'upscale':
case 'resize':
case 'hdr': 
case 'hd': {
  if (!quoted) return reply(`Where is the picture?`)
   // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
  if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
  reply(mess.wait)
  let media = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)
  let anu = await TelegraPh(media)
  let upscale = await fetchJson(`https://www.api.vyturex.com/upscale?imageUrl=${anu}`)
  await KaaKangSatir.sendMessage(m.chat, { image: { url: upscale.resultUrl }, caption: mess.success}, { quoted: fcall})
    global.db.data.users[m.sender].limit -= randomReduction;
}
break
			
case  'qc':
case  'qcstick':{
if (isBan) return reply(mess.bann)
    const q = m.quoted ? m.quoted : m;
     // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
    const mime = (q.msg || q).mimetype || '';
    let reply;
    if (text && m.quoted) {
        if (m.quoted.sender) {
            reply = {
                "name": await KaaKangSatir.getName(m.quoted.sender),
                "text": m.quoted.text || '',
                "chatId": m.chat.split('@')[0],
            };
        }
    } else if (text && !m.quoted) {
        reply = {};
    } else if (!text && m.quoted) {
        if (m.quoted.text) {
            text = m.quoted.text || '';
        }
        reply = {};
    } else {
        throw "*Example :* .qc *[text or reply message]*";
    }

    const img = await q.download?.();

    if (mime) {
    KaaKangSatir.sendMessage(from, { text : mess.wait }, { quoted : m })
        const obj = {
            type: "quote",
            format: "png",
            backgroundColor: "#FFFFFF",
            width: 512,
            height: 768,
            scale: 2,
            "messages": [{
                "entities": [],
                "media": {
                    "url": await uploadFile(img)
                },
                avatar: true,
                from: {
                    id: 1,
                    name: await KaaKangSatir.getName(m.sender),
                    photo: {
                        url: ProfileUsers
                    }
                },
                text: text || '',
                replyMessage: reply
            }]
        };

        const json = await axios.post('https://btzqc.betabotz.eu.org/generate', obj, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const buffer = Buffer.from(json.data.result.image, 'base64');
        const stickerResult = await stickQC(buffer, false, global.packname, global.author);

        if (stickerResult) return KaaKangSatir.sendImageAsSticker(m.chat, stickerResult, m, { packname: global.packname, 
author: global.author, 
categories: ['🤩', '🎉'],
id: '12345',
quality: 100,
background: 'transparent'});
    } else {
    KaaKangSatir.sendMessage(from, { text : mess.wait }, { quoted : m })
        const obj = {
            type: "quote",
            format: "png",
            backgroundColor: "#FFFFFF",
            width: 512,
            height: 768,
            scale: 2,
            "messages": [{
                "entities": [],
                avatar: true,
                from: {
                    id: 1,
                    name: await KaaKangSatir.getName(m.sender),
                    photo: {
                        url: ProfileUsers
                    }
                },
                text: text || '',
                replyMessage: reply
            }]
        };

        const json = await axios.post('https://btzqc.betabotz.eu.org/generate', obj, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const buffer = Buffer.from(json.data.result.image, 'base64');
        const stickerResult = await stickQC(buffer, false, global.packname, global.author);

        if (stickerResult) return KaaKangSatir.sendImageAsSticker(m.chat, stickerResult, m, { packname: global.packname, 
author: global.author, 
categories: ['🤩', '🎉'],
id: '12345',
quality: 100,
background: 'transparent'});

    }
    global.db.data.users[m.sender].limit -= randomReduction;
}
break 

case 'colong': 

case 'smeme': case 'stickermeme': case 'stickmeme': {

    if (!/image/.test(mime)) return reply(`Send/Reply image with caption ${prefix + command} Shun|KaaKangSatir`)
        if (!text) return reply(`Text mana?\n\n*Example :* ${prefix + command} Shun|KaaKangSatir`)
         // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
        reply(mess.wait)

        // Memisahkan teks dengan menggunakan '|'
        let teks = text.split('|')

        // Mengatur teks atas dan bawah
        let atas = teks[0] ? teks[0] : '-'
        let bawah = teks[1] ? teks[1] : atas // Jika teks bawah tidak ada, gunakan teks atas dan abaikan teks atas

        // Jika hanya ada satu teks, abaikan teks atas
        if (teks.length === 1) {
            atas = '-'
            bawah = teks[0]
        }

        // Mengunduh dan menyimpan gambar yang diberikan
        let mee = await KaaKangSatir.downloadAndSaveMediaMessage(quoted)

        // Mengunggah gambar ke TelegraPh
        let mem = await TelegraPh(mee)

        // Membuat URL meme dengan teks dan gambar latar belakang yang diunggah
        let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`

        // Mengirim gambar sebagai stiker
        let memek = await KaaKangSatir.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author })
    global.db.data.users[m.sender].limit -= randomReduction;
}
break

case 'sticker': case 's': case 'stickergif': case 'sgif': {
 if (!quoted) throw `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
let media = await quoted.download()
let encmedia = await KaaKangSatir.sendImageAsStickerAV(from, media, fcall, { packname: global.packname, author: global.author })
    global.db.data.users[m.sender].limit -= randomReduction;
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
 // Menghasilkan pengurangan acak antara 1 dan 5
    
    
    if (global.db.data.users[m.sender].limit < randomReduction) {
        reply(mess.endLimit);
        return; // Menghentikan eksekusi jika batas telah habis
    }
let media = await quoted.download()
let encmedia = await KaaKangSatir.sendVideoAsSticker(from, media, fcall, { packname: global.packname, author: global.author })
    global.db.data.users[m.sender].limit -= randomReduction;
await fs.unlinkSync(encmedia)
} else {
throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
}
break

case 'readvo': 

case 'tempmail': {
    KaaKangSatir.secmail = KaaKangSatir.secmail ? KaaKangSatir.secmail : {}
    let id = "secmail"
    let lister = ["create", "message", "delete"]

    let [feature, inputs, inputs_, inputs__, inputs___] = text.split(" ")
    
    let caption = `\n*Pilih type yg ada*\n- create\n- message\n- delete`
    
    let sections = [
{
highlight_label: 'Create',
rows: [{
title: 'Membuat Email',
id: `${prefix + command} create`
}]
},
{
highlight_label: 'Message',
rows: [{
title: 'Melihat Pesan Email',
id: `${prefix + command} message`
}]
},
{
highlight_label: 'Delete',
rows: [{
title: 'Menghapus Email',
id: `${prefix + command} delete`
}]
}]

let listMessage = {
    title: 'Temp Mail',
    sections
}

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: saluran,
 newsletterJid: idsal,
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: KaaKangSatir.decodeJid(KaaKangSatir.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: wm
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `Hii @${m.sender.split("@")[0]}`,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: "https://play-lh.googleusercontent.com/Mz0NTKKDJJwzl9zcg4261ahxnV-Df9Mylp46JnZzUZcRtS51gstbNVIOMar3a7UgThk" } }, { upload: KaaKangSatir.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
 }
 ],
 })
 })
 }
 }
}, {})

if (!lister.includes(feature)) await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})

    if (lister.includes(feature)) {
        if (feature === "create") {
            try {
                let eml = await random_mail()
                let info = eml[0].split('@')
                KaaKangSatir.secmail[id] = [
                    await reply("*EMAIL:*\n" + eml[0] + "\n\n" + "*Login:*\n" + info[0] + "\n\n*Domain:*\n" + info[1] + "\n\n_Ketik *" + prefix + command + " message* Untuk mengecek inbox_"),
                    eml[0],
                    info[0],
                    info[1]
                ]
            } catch (e) {
                await reply(mess.error)
            }
        }

        if (feature === "message") {
            if (!KaaKangSatir.secmail[id]) {
                return reply("Tidak ada pesan, buat email terlebih dahulu\nKetik *" + prefix + command + " create*")
            }

            try {
                let eml = await get_mails(KaaKangSatir.secmail[id][2], KaaKangSatir.secmail[id][3])
                let teks = eml.map((v, index) => {
                    return `*EMAIL [ ${index + 1} ]*
*ID* : ${v.id}
*Dari* : ${v.from}

*Subjek* : ${v.subject}
*Date* : ${v.date}
   `.trim()
                }).filter(v => v).join("\n\n________________________\n\n")
                    let msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: teks || "*Not Found*\nTidak Ada Email Yang Terkirim"
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: wm
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        gifPlayback: true,
                        subtitle: ownername,
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"Back","id":"${prefix}tempmail"}`
                            }
                        ],
                    }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                                newsletterName: saluran,
                                newsletterJid: idsal,
                            serverMessageId: 143
                        }
                    }
                })
            }
        }
    }, {});

    await KaaKangSatir.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
            } catch (e) {
                await reply(mess.error)
            }
        }

        if (feature === "delete") {
            if (!KaaKangSatir.secmail[id]) {
                return reply("Tidak ada email yang terpakai")
            }

            try {
                delete KaaKangSatir.secmail[id]
                await reply("Sukses menghapus email")
            } catch (e) {
                await reply(mess.error)
            }
        }
    }
    }
    break
    
    case "get": {
if (!/^https?:\/\//.test(text)) return m?.reply('Awali *URL* dengan http:// atau https://')
let _url = new URL(text)
let url = `${_url.origin}${_url.pathname}${_url.search}`;
let res = await fetch(url)
if (res.headers.get('content-length') > 100 * 1024 * 1024 * 1024) {
delete res
m?.reply(`Content-Length: ${res.headers.get('content-length')}`)
}
if (!/text|json/.test(res.headers.get('content-type'))) return KaaKangSatir.sendFile(m?.chat, url, 'file', mess.success, m)
let txt = await res.buffer()
try {
txt = util.format(JSON.parse(txt + ''))
} catch (e) {
txt = txt + ''
} finally {
m?.reply(txt.slice(0, 65536) + '')
}
}
break
//—————「 TOOLS MENU 」—————//


//=================================================//
default:
if (budy.startsWith('=>')) {
if (!isCreator) return false
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return false
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))}}
if (budy.startsWith('$')) {
if(!isCreator) return false
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(mess.error)
if (stdout) return reply(stdout)})}

if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum",].includes(budy) && !isCmd) {
reply(`*Waalaikummussalam warahmatullahi wabarokatuh*\n\n\n_📚 Baca yang dibawah ya!_
"Orang yang mengucapkan salam seperti ini maka ia mendapatkan 30 pahala, kemudian, orang yang dihadapan atau mendengarnya membalas dengan kalimat yang sama yaitu “Wa'alaikum salam warahmatullahi wabarakatuh atau ditambah dengan yang lain (waridhwaana). Artinya selain daripada do'a selamat juga meminta pada Allah SWT`)
}
//=================================================//
if (isCmd && budy.toLowerCase() != undefined) {
if (from.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
KaaKangSatir.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (err) {
m.reply(util.format(err))}}

//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
